# FF-OpenHermes — 产品需求文档（PRD）

> 版本：v0.1（初稿）· 日期：2026-04-29
> 一句话：**对话即学习** —— 一个能聊天、能自主写技能、能在使用中不断改进自己的 Agent 教学项目。
>
> 灵感来源：Hermes Agent（Nous Research, 2026）的闭环学习循环（Closed Learning Loop）
> 工程基座：mini-OpenClaw（runtime）+ fufan-cc-flow（UI 范式）+ case-07/08（skill 引擎原理）

---

## 1. 项目定位

### 1.1 核心理念

> **Agent = Model + Harness**（Mitchell Hashimoto, 2026）

FF-OpenHermes 把 Hermes Agent 的核心创新——**闭环学习循环**——做成一个最小可教学的 Web 产品。

```
Solve  →  Document  →  Retrieve  →  Improve  →  Repeat
解决   →  记录      →  检索       →  改进     →  重复
```

不做：分布式训练 / GPU / multi-agent / 真实 RL fine-tune。
专做：把 5 步 self-improvement loop 用一个能聊天、能跑工具的 Web 应用讲清楚。

### 1.2 与已有项目的关系

| 已有项目 | 角色 | 复用粒度 |
|---|---|---|
| **mini-OpenClaw** | Agent 运行时基座 | `graph/agent.py`、`tools/*`、`prompt_builder.py` 直接迁移并改造 |
| **fufan-cc-flow** | UI 范式参考 | 三栏布局、ToolCallCard、ThoughtChain、SSE 事件协议设计 |
| **case-07 Skill Distiller** | 技能生成引擎原型 | Zod schema → Pydantic；五幕动效 → 对话流内 SkillEventCard |
| **case-08 Skill Evolver** | 技能强化引擎原型 | Actor + Curator 两段式 prompt → Python middleware；diff 渲染 → EvolutionLog |
| **case-09 Harness Diagnostics** | 可选 trace 诊断 | P2 阶段集成，给 Session History 加"诊断"按钮 |

### 1.3 与 mini-OpenClaw 的差异

| 维度 | mini-OpenClaw | FF-OpenHermes |
|---|---|---|
| 系统提示层 | SOUL + IDENTITY + USER + AGENTS（4 件套）| **SOUL + MEMORY + SKILLS_SNAPSHOT**（更聚焦） |
| 状态管理 | 手写 JSON 会话文件 | **LangGraph SqliteSaver Checkpointer** |
| 记忆模型 | MEMORY.md + 可选 RAG | **三层记忆**：Frozen Prompt（L1）+ Skills（L2）+ Session History（L3） |
| 技能来源 | 人工编写为主 | **Agent 自主生成 + 人工编写** |
| 技能进化 | 静态 | **使用中自主强化，版本化记录** |
| 工作区粒度 | 全局共享一套 skills/memory | **Session 即工作区**（每个 session 自包含） |
| **绑定的项目目录** | 全局 cwd | **每个 session 绑定一个项目目录**（类 Claude Code project 模式）|
| 视觉主题 | 金色 / 古铜（温暖助手感）| **紫色 / 靛蓝**（科技进化感） |
| HIL 权限 | 黑名单拦截 | **PermissionModal 交互式确认**（移植自 fufan-cc-flow）|

---

## 2. 用户与场景

### 2.1 目标用户

| 用户类型 | 核心诉求 |
|---|---|
| AI 工程学员 / 课程学员 | 直观看见"自我进化"的 AI Agent 长什么样 |
| 研究 Agent 架构的开发者 | 一个最小可读的、闭环学习的参考实现 |
| 独立开发者 | 想给自己的项目加一个能学习用户偏好的 Agent |

### 2.2 核心使用场景

**场景 A · 第一次接触**
1. 用户点 "+ New Session"，弹窗里选/创建一个项目目录作为工作空间（如 `~/projects/scraper-demo`）
2. 进入会话，问"帮我抓取某网页表格并导出 Excel"，左侧栏底部已显示该目录的文件树
3. Agent 跑 5 个工具调用完成任务，所有 `terminal/python_repl/write_file` 默认 cwd 为该工作空间
3. 任务结束 2 秒后，对话流末尾出现 ⚡ Skill 自动生成卡片
4. 用户切到技能页，看到一个新的 `extract_web_table` 技能（带 🤖 标记）

**场景 B · 二次复用**
1. 用户在同一会话再问"帮我抓取另一个网站的数据表"
2. Agent 主动 `read_skill("extract_web_table")` 加载技能
3. 任务完成后，Agent 检测到本次发现了边缘情况，自动 patch SKILL.md 到 v1.1
4. 对话流末尾出现 ⚡ Skill 自主强化卡片，技能页演化日志多一条

**场景 C · 用户接管**
1. 用户在记忆页看到 MEMORY.md 容量到 80%，点 "AI 优化"
2. Agent 整合冗余条目，压缩到 50%
3. 用户在 SOUL.md 里加一行"回答时优先用中文"，保存
4. 下一轮对话立即生效

---

## 3. 四大核心功能

### 3.1 Agent 运行时（Runtime）

**目标**：流畅的对话 + 透明的工具调用 + 可控的中断与权限。

| 子功能 | P0/P1/P2 | 实现方式 |
|---|---|---|
| 流式对话（SSE）| P0 | LangChain `astream(stream_mode=["messages","updates"])` + `sse-starlette` |
| 工作空间绑定 | P0 | 每个 session `meta.json` 含 `workspace_path`；所有工具默认 cwd 指向该路径；左侧栏底部显示该目录文件树 |
| 工具调用可视化（ThoughtChain）| P0 | 复用 fufan-cc-flow ToolCallCard，事件 `tool_start / tool_end` |
| 思考过程展示 | P1 | 透传 LLM 的 thinking 内容（DeepSeek-R1 兼容，普通 deepseek-chat 跳过） |
| HIL 权限确认 | P0 | 复用 fufan-cc-flow PermissionModal，事件 `permission_request / permission_response` |
| 任务中断（Abort）| P0 | LangGraph 的 `astream` 可被 `asyncio.CancelledError` 中断 |
| 模型切换 | P1 | 顶部 Header 下拉，写入 `.env` 但仅当前会话生效 |
| Token 用量条 | P1 | `astream` 累积 usage_metadata，前端 ProgressBar |

**核心代码骨架**：

```python
# agent/agent_manager.py
from langchain.agents import create_agent
from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver

agent = create_agent(
    model=llm,
    tools=tools,
    prompt=system_prompt,            # 由 prompt_builder 按 session 拼接
    checkpointer=checkpointer,       # AsyncSqliteSaver, per-session state.db
    middleware=[SkillEngineMiddleware()],
)

async for mode, data in agent.astream(
    {"messages": [HumanMessage(content=user_input)]},
    config={"configurable": {"thread_id": session_id}},
    stream_mode=["messages", "updates"],
):
    yield translate_to_sse_event(mode, data)
```

### 3.2 持久记忆（三层记忆）

**目标**：让 Agent 能记住跨会话的人格、长期事实、历史对话。

```
┌─────────────────────────────────────────────────┐
│ Layer 1 · Frozen System Prompt（始终注入）      │
│   • SOUL.md   - 用户自定义 Agent 人格            │
│   • MEMORY.md - Agent 长期记忆（自主+人工）     │
├─────────────────────────────────────────────────┤
│ Layer 2 · Episodic Memory（按需加载）           │
│   • SKILLS_SNAPSHOT.md - 技能索引（Level 0）   │
│   • skills/{name}/SKILL.md - 完整技能（Level 1）│
├─────────────────────────────────────────────────┤
│ Layer 3 · Session Search（SQLite Checkpointer） │
│   • state.db - 完整对话状态                     │
│   • Memory 页 timeline 视图查看                 │
└─────────────────────────────────────────────────┘
```

| 子功能 | P0/P1/P2 | 实现方式 |
|---|---|---|
| SOUL.md 编辑器 | P0 | Monaco editor + token 容量条 |
| MEMORY.md 编辑器 | P0 | 同上 |
| `read_memory / write_memory` 工具 | P0 | 直接用 mini-OpenClaw 的 `read_file_tool` 改造 |
| Session History timeline | P0 | 解析 `state.db` checkpoint 转 turn 列表 |
| 定期自省（write to memory）| P1 | `before_model` middleware 每 N 轮注入"评估是否记忆"提示 |
| AI 优化记忆 | P1 | 单次 LLM 调用整合 MEMORY.md |
| 容量上限管理 | P2 | MEMORY.md 超 8K tokens 时让 Agent 自整合 |

### 3.3 Skill 自主生成（Generator）

**目标**：复杂任务结束后，Agent 后台异步把经验固化为 SKILL.md。

**触发条件**（默认）：
- 本轮工具调用次数 ≥ 3
- 且本轮没有用到任何已有技能
- 且 LLM 评估认为"值得"（输出非 `NO_SKILL`）

**生成流程**（`after_agent` middleware）：

```
Agent 完成回复
    ↓
后台 task：把当前轮 messages + tool_calls 喂给 generator LLM
    ↓ (复用 case-07 的 Zod schema 思想 → Pydantic)
LLM 输出结构化对象：{ signals[], clusters{}, skill: {name, description, body} }
    ↓
客户端 lint（kebab-case / 双焦点 / 长度）
    ↓ pass
原子写入 sessions/{sid}/skills/{name}/SKILL.md + HISTORY.md
    ↓
SSE 推送 skill_generated 事件
    ↓
前端：对话流末尾追加 ⚡ Skill Auto-Generated 卡片，导航红点提示
```

**关键设计**：
- **异步非阻塞**：用户已经看到 Agent 回复，技能生成是"彩蛋"
- **失败兜底**：生成失败静默记日志，不影响主流程
- **去重**：写入前检查目录冲突，让 LLM 重命名或追加 `_v2`
- **可配置阈值**：`SKILL_GEN_THRESHOLD=3` 写在 config 里
- **schema 严格性**：Pydantic 校验失败重试一次

**Pydantic schema 草案**：

```python
class GeneratedSkill(BaseModel):
    name: str = Field(..., max_length=64, regex=r"^[a-z][a-z0-9-]*$")
    description: str = Field(..., max_length=1024)  # 必须含触发关键词
    body: str = Field(..., max_length=10_000)        # 必须有 H1
    triggers: list[str] = Field(..., min_items=1, max_items=8)

class GeneratorOutput(BaseModel):
    decision: Literal["GENERATE", "NO_SKILL"]
    skill: GeneratedSkill | None = None
    reasoning: str
```

### 3.4 Skill 自主强化（Enhancer）

**目标**：使用过的技能在执行后做反思，自动 patch SKILL.md。

**触发条件**：本轮加载并使用了已有技能（通过 `read_skill` 工具调用检测）。

**强化流程**（同样 `after_agent` middleware，分支不同）：

```
Agent 完成回复，本轮用了 weather_query 技能
    ↓
后台 task：把 (skill_content, execution_trace) 喂给 enhancer LLM
    ↓ (复用 case-08 的 Actor + Curator 思路)
Actor: 反思 — "技能步骤是否完全适用？发现了哪些新东西？"
    ↓
Curator: 提议修改 — 输出 added/removed/kept 三组规则
    ↓
应用 diff 到 SKILL.md，版本号 v1.0 → v1.1
    ↓
HISTORY.md 追加一行 "{timestamp} · v1.1 · 优化错误处理"
    ↓
SSE 推送 skill_enhanced 事件
    ↓
前端：对话流末尾 ⚡ Skill Enhanced 卡片，技能页演化日志多一条
```

**关键设计**：
- **保留版本历史**：每次 patch 在 HISTORY.md 记录，技能页右栏 EvolutionLog 展示
- **避免无意义更新**：Curator 输出 `NO_UPDATE` 时跳过
- **冲突保护**：用户可能正在编辑 SKILL.md，强化前先校验文件 mtime 没变
- **diff 可视化**：技能页支持点击 v1.0 vs v1.1 看行级 diff

---

## 4. 架构与技术栈

### 4.1 整体架构

```
┌────────────────────────────────────────────────────────┐
│  Browser · Next.js 14 + TypeScript + Tailwind          │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐                │
│  │ Chat 页  │ │ Memory 页│ │ Skills 页│                │
│  └──────────┘ └──────────┘ └──────────┘                │
│  顶部 SessionSelector（pivot）+ 左侧 NavSidebar         │
└────────────┬───────────────────────────────────────────┘
             │ HTTP REST + SSE 流式
             ▼
┌────────────────────────────────────────────────────────┐
│  FastAPI Backend · Python 3.10+                        │
│  ┌─ api/  · chat / sessions / memory / skills          │
│  ├─ agent/ · agent_manager / prompt_builder / middleware│
│  ├─ tools/ · 7 个工具（含 read_skill / read_memory）    │
│  ├─ skill_engine/ · generator + enhancer + scanner     │
│  └─ sessions/{sid}/ · 自包含工作区                     │
└────────────┬───────────────────────────────────────────┘
             │ LangChain 1.x
             ▼
┌────────────────────────────────────────────────────────┐
│  LLM · OpenRouter · deepseek/deepseek-chat-v3.1         │
└────────────────────────────────────────────────────────┘
```

### 4.2 技术栈确认表

| 层级 | 选型 | 备注 |
|---|---|---|
| **前端框架** | Next.js 14 (App Router) | 与 mini-OpenClaw 同栈 |
| **前端语言** | TypeScript（严格模式）| |
| **样式** | Tailwind CSS + CSS 自定义属性主题 | 紫色主题 |
| **代码编辑器** | Monaco Editor | SOUL/MEMORY/SKILL.md |
| **图标** | Lucide React | |
| **状态管理** | Zustand（按域拆分）| 借鉴 fufan-cc-flow 的 store 结构 |
| **后端框架** | FastAPI | 异步 + SSE |
| **Agent 框架** | **LangChain 1.x `create_agent`** | middleware 体系 |
| **底层图引擎** | LangGraph | `AsyncSqliteSaver` |
| **状态持久化** | SQLite（per-session state.db）| Layer 3 记忆 |
| **LLM Provider** | **OpenRouter** | 统一 key，规避 IP 封锁 |
| **默认模型** | `deepseek/deepseek-chat-v3.1` | 经验：anthropic/openai/google 在本环境 403 |
| **流式传输** | SSE（`sse-starlette`）| 单向，比 WebSocket 简单 |
| **结构化输出** | Pydantic + LangChain `with_structured_output` | 翻译 case-07 的 Zod schema |

### 4.3 关键 LangChain 1.x 用法

**Middleware 钩子**（这是 mini-OpenClaw 没有用到的新能力）：

```python
from langchain.agents.middleware import AgentMiddleware

class SkillEngineMiddleware(AgentMiddleware):
    async def before_model(self, state):
        """每次调用模型前 — 用于定期自省记忆"""
        if self._should_self_reflect(state):
            return self._inject_reflection_prompt(state)

    async def after_agent(self, state):
        """Agent 完成一轮后 — 用于触发 skill 生成/强化"""
        used_skills = self._detect_used_skills(state["messages"])
        tool_count = self._count_tool_calls(state["messages"])

        # 后台异步执行，不阻塞用户
        if used_skills:
            asyncio.create_task(self._enhance(state, used_skills))
        elif tool_count >= settings.SKILL_GEN_THRESHOLD:
            asyncio.create_task(self._generate(state))
```

---

## 5. 目录结构

### 5.1 后端

```
FF-OpenHermes/backend/
├── app.py                          # FastAPI 入口
├── config.py                       # 配置加载（OpenRouter / 阈值）
├── .env / .env.example
├── requirements.txt
│
├── api/
│   ├── chat.py                     # POST /api/chat   (SSE)
│   ├── sessions.py                 # CRUD /api/sessions
│   ├── memory.py                   # SOUL / MEMORY / Session History
│   ├── skills.py                   # 技能管理 + 手动加载
│   ├── workspace.py                # 工作空间文件树 + 文件读写
│   └── fs.py                       # 通用目录浏览器（创建 session 时用）
│
├── agent/
│   ├── agent_manager.py            # create_agent 封装 + 流式输出
│   ├── prompt_builder.py           # 多层 system prompt 拼接（按 session）
│   ├── middleware.py               # SkillEngineMiddleware
│   └── permission_handler.py       # HIL 权限交互（async future）
│
├── tools/
│   ├── __init__.py                 # 工具工厂 get_all_tools(session_dir)
│   ├── terminal_tool.py            # 终端命令（沙箱化）
│   ├── python_repl_tool.py
│   ├── fetch_url_tool.py
│   ├── search_tool.py              # 联网搜索（DuckDuckGo / Tavily）
│   ├── file_tool.py                # 通用文件读写（沙箱化）
│   ├── memory_tool.py              # read_memory / write_memory
│   └── skill_tool.py               # read_skill（按 session 范围）
│
├── skill_engine/
│   ├── generator.py                # Skill 自主生成（参考 case-07）
│   ├── enhancer.py                 # Skill 自主强化（参考 case-08）
│   ├── scanner.py                  # 扫描 skills/ 生成 SNAPSHOT
│   ├── lint.py                     # 客户端 lint 规则（参考 case-07）
│   └── schemas.py                  # Pydantic schemas
│
├── templates/                      # 新会话默认模板
│   ├── SOUL.md
│   └── MEMORY.md
│
└── sessions/                       # ⭐ Agent 元数据工作区根目录
    ├── sessions_index.json
    └── {session_id}/
        ├── meta.json               # 标题、创建时间、模型、workspace_path
        ├── SOUL.md
        ├── MEMORY.md
        ├── loaded_skills.json      # 当前手动加载的技能 + level
        ├── state.db                # LangGraph SqliteSaver
        └── skills/
            ├── SKILLS_SNAPSHOT.md
            └── {skill_name}/
                ├── SKILL.md
                └── HISTORY.md
```

> **Agent 元数据工作区 vs 用户项目工作空间**：
> - `sessions/{sid}/` 是 **Agent 自己的元数据**（人格/记忆/技能/状态），不暴露给用户日常浏览
> - 每个 session 还**绑定一个外部的用户项目目录**（`workspace_path`，由用户在创建 session 时选择/填写），那才是 Agent 跑命令、读写文件、显示文件树的地方
> - 类比 Claude Code：`sessions/{sid}/` ≈ `~/.claude/projects/<project>/`（CLI 状态），`workspace_path` ≈ 用户实际 `cd` 进去的项目目录

### 5.2 前端

```
FF-OpenHermes/frontend/
├── src/
│   ├── app/                        # Next.js App Router
│   │   ├── layout.tsx              # 全局布局（Header + NavSidebar）
│   │   ├── page.tsx                # /  → Chat 页
│   │   ├── memory/page.tsx         # /memory → Memory 页
│   │   └── skills/page.tsx         # /skills → Skills 页
│   ├── components/
│   │   ├── layout/                 # Header / SessionSelector / NavSidebar
│   │   │                           # WorkspaceTree (NavSidebar 下半部分)
│   │   │                           # NewSessionModal (含 DirectoryPicker)
│   │   ├── chat/                   # ChatPanel / ChatMessage / ThoughtChain
│   │   │                           # ToolCallCard / PermissionModal
│   │   │                           # SkillEventCard / RawMessagesPanel
│   │   ├── memory/                 # MemoryLayerCards / SoulEditor
│   │   │                           # MemoryEditor / SessionHistoryView
│   │   │                           # TurnDetailCard / CapacityBar
│   │   └── skills/                 # SkillLibrary / SkillDetail
│   │                               # SkillEditor / EvolutionLog
│   │                               # LoadSkillButton / NewSkillModal
│   ├── stores/                     # Zustand
│   │   ├── chatStore.ts
│   │   ├── sessionStore.ts         # ⭐ 顶部 pivot
│   │   ├── memoryStore.ts
│   │   └── skillStore.ts
│   ├── hooks/
│   │   └── useSseStream.ts         # SSE 客户端
│   └── services/
│       └── api.ts                  # REST 客户端
└── package.json
```

### 5.3 共享 / 顶层

```
FF-OpenHermes/
├── README.md
├── PRD.md                          # 本文档
├── docs/
│   ├── 01-architecture.md          # 详细架构图 + 数据流
│   ├── 02-skill-engine.md          # generator + enhancer 详细说明
│   ├── 03-api.md                   # REST + SSE 协议
│   └── 04-development.md           # 开发指南
├── backend/
└── frontend/
```

---

## 6. 数据模型

### 6.1 Session 工作区元数据（meta.json）

```json
{
  "id": "sess_2026042901",
  "title": "北京天气查询",
  "workspace_path": "C:/Users/Administrator/projects/scraper-demo",
  "created_at": "2026-04-29T10:30:00Z",
  "updated_at": "2026-04-29T11:45:00Z",
  "model": "deepseek/deepseek-chat-v3.1",
  "stats": {
    "turns": 12,
    "total_tokens": 8420,
    "skills_generated": 2,
    "skills_enhanced": 5
  }
}
```

`workspace_path` 在创建 session 时确定，之后只读（避免 Agent 中途换目录引起混乱）。删除 session 时**只删 `sessions/{sid}/`，不动 workspace_path 指向的用户目录**。

### 6.2 SKILL.md 格式（agentskills.io 标准）

```markdown
---
name: extract-web-table
description: "抓取网页表格并导出 Excel。当用户要求 scrape table、save webpage data、提取表格 时使用。"
version: 1.2
generated_by: agent
created_at: 2026-04-29T10:00:00Z
---

# extract-web-table

## Overview
通过 fetch_url + python_repl 抓取并解析 HTML 表格...

## Triggers
- "抓取表格"、"scrape table"
- "导出为 Excel"、"save as xlsx"

## Steps
1. ...
2. ...

## Edge Cases & Errors
- 多表格页面：...
- JS 渲染表格：fall back 到 browser_use（如可用）

## Verification
- 检查 .xlsx 文件存在
- 行数 ≥ 1
```

### 6.3 HISTORY.md 格式

```markdown
# Evolution History · extract-web-table

## v1.2 · 2026-04-29 11:45 · 🤖 Auto-Enhanced
Added: JS-rendered table fallback to browser_use
Reason: 在 cnbeta.com 失败发现 JS 渲染场景

## v1.1 · 2026-04-29 10:20 · 🤖 Auto-Enhanced
Added: 多表格页面用户选择步骤

## v1.0 · 2026-04-29 10:00 · 🤖 Auto-Generated
Initial version. Source task: sess_2026042901 / turn 3
```

---

## 7. API 设计

### 7.1 REST API

| 方法 | 路径 | 说明 |
|---|---|---|
| **会话** ||
| GET | `/api/sessions` | 会话列表 |
| POST | `/api/sessions` | 创建会话（body 含 `workspace_path` + `title` + 可选 `inherit_from`） |
| GET | `/api/sessions/{sid}` | 会话元数据（含 workspace_path） |
| PUT | `/api/sessions/{sid}` | 重命名（不允许改 workspace_path） |
| DELETE | `/api/sessions/{sid}` | 删除（仅删 `sessions/{sid}/`，不动 workspace 目录） |
| GET | `/api/sessions/{sid}/history` | 会话历史（解析自 state.db） |
| **工作空间**（基于当前 session 的 workspace_path） ||
| GET | `/api/sessions/{sid}/workspace/tree` | 文件树（支持 `?path=relpath` 子目录） |
| GET | `/api/sessions/{sid}/workspace/file` | 读文件内容（`?path=relpath`） |
| PUT | `/api/sessions/{sid}/workspace/file` | 写文件（受 isSubPath 校验） |
| POST | `/api/sessions/{sid}/workspace/mkdir` | 创建目录 |
| POST | `/api/sessions/{sid}/workspace/rename` | 重命名 |
| DELETE | `/api/sessions/{sid}/workspace/file` | 删除文件/目录 |
| GET | `/api/fs/browse` | **创建 session 时的目录浏览器**（不绑定 sid，盘符枚举） |
| **记忆** ||
| GET/PUT | `/api/sessions/{sid}/soul` | SOUL.md |
| GET/PUT | `/api/sessions/{sid}/memory` | MEMORY.md |
| GET | `/api/sessions/{sid}/memory/stats` | token 用量统计 |
| POST | `/api/sessions/{sid}/memory/optimize` | AI 优化记忆 |
| **技能** ||
| GET | `/api/sessions/{sid}/skills` | 技能列表 |
| POST | `/api/sessions/{sid}/skills` | 手动创建技能 |
| GET/PUT/DELETE | `/api/sessions/{sid}/skills/{name}` | 技能详情/编辑/删除 |
| GET | `/api/sessions/{sid}/skills/{name}/history` | 演化日志 |
| POST | `/api/sessions/{sid}/skills/{name}/load` | `{level: 0\|1}` 加载到上下文 |
| POST | `/api/sessions/{sid}/skills/{name}/unload` | 卸载 |
| GET | `/api/sessions/{sid}/skills/loaded` | 当前已加载技能 |

### 7.2 SSE 事件协议（POST /api/chat）

**前端 → 后端（请求体）**：
```json
{
  "session_id": "sess_xxx",
  "message": "用户消息",
  "model": "deepseek/deepseek-chat-v3.1"
}
```

**后端 → 前端（事件流）**：

| event | data | 说明 |
|---|---|---|
| `turn_start` | `{turn_id}` | 新一轮开始 |
| `assistant_token` | `{content}` | 文本流增量 |
| `tool_start` | `{tool_call_id, name, input}` | 工具开始 |
| `tool_end` | `{tool_call_id, output, is_error}` | 工具结束 |
| `permission_request` | `{request_id, tool, input}` | HIL 权限请求 |
| `memory_write` | `{path, summary}` | Agent 写入了 MEMORY.md |
| `skill_generated` | `{name, description}` | 触发 generator 完成 |
| `skill_enhanced` | `{name, version, summary}` | 触发 enhancer 完成 |
| `usage` | `{input_tokens, output_tokens}` | token 累积 |
| `turn_end` | `{turn_id, full_response}` | 一轮结束 |
| `error` | `{code, message}` | 错误 |

**前端的反向事件**（POST /api/permission/{request_id}）：
```json
{ "behavior": "allow_once" | "allow_always" | "deny" }
```

---

## 8. UI 设计要点

### 8.1 整体布局

```
┌──────────────────────────────────────────────────────────┐
│ 🔮 FF-OpenHermes  [▼ Session] [+New] [Model▾] [🌙/☀️]    │  ← Header（共享）
├─────┬────────────────────────────────────────────────────┤
│ 💬  │                                                    │
│ 🧠  │   Main Content（按当前页 + 当前 session 渲染）     │
│ ⚡🔴│                                                    │
│ ─── │                                                    │
│ 📁  │                                                    │
│ src/│                                                    │
│ docs│                                                    │
│ pkg │                                                    │
│ ... │                                                    │
└─────┴────────────────────────────────────────────────────┘
```

- **Header SessionSelector** 是全局 pivot，切换后三个页面 + 工作空间文件树联动 reload
- **左侧 NavSidebar 上半部分**：三个 tab — 💬 对话 / 🧠 记忆 / ⚡ 技能
- **左侧 NavSidebar 下半部分**：📁 **当前 Session 工作空间**（从 `workspace_path` 读取的文件树）
  - 显示当前 session 绑定目录的相对路径（如 `~/projects/scraper-demo`）
  - 树形展示，支持点击文件用 Monaco 预览
  - 支持新建/重命名/删除（走 `/api/sessions/{sid}/workspace/*` 接口）
  - **Agent 写文件后自动刷新**（监听 SSE 的 `tool_end` 事件中 `write_file` 调用）
- **导航红点** ⚡🔴 表示当前会话有新生成/强化的技能未查看

### 8.2 对话页

详见 doc-05 §3.2.1。关键差异于 mini-OpenClaw 的：
- 对话流中插入两类**事件卡片**：MemoryWriteCard、SkillEventCard
- 右侧可选 RawMessagesPanel（默认折叠）展示原始 JSON 消息
- PermissionModal 弹窗（移植自 fufan-cc-flow，紫色主题）

### 8.3 记忆页

三层记忆展示为顶部三张卡片（SOUL / MEMORY / Session History），下方根据选中卡片展开：
- SOUL/MEMORY：Monaco editor + 容量条 + Save/Optimize/Reset
- Session History：timeline 视图，每一轮可展开看 tool_calls

### 8.4 技能页

三栏布局：
- 左：技能列表（含 ✅ 已加载标记 + 🤖/✍ 来源徽章）
- 中：选中技能的 SKILL.md 预览/编辑（Monaco）
- 右：EvolutionLog（v1.0 → v1.N 时间线，点击看 diff）

### 8.5 视觉规范

| Token | Dark Mode | Light Mode |
|---|---|---|
| Bg Primary | `#0B0818` | `#FAF9FE` |
| Bg Surface | `#15102A` | `#FFFFFF` |
| Border Subtle | `#2A2145` | `#E8E4F3` |
| Text Primary | `#F0EBFA` | `#1E1B2E` |
| Accent Primary | `#A78BFA` | `#7C3AED` |
| User bubble | `#3B2F5E` | `#EDE9FE` |
| Success | `#34D399` | `#059669` |
| Warning | `#FBBF24` | `#D97706` |

字体：Inter（UI）+ JetBrains Mono（代码 / 元数据）

---

## 9. 工具清单

所有"操作类"工具的 cwd 默认为**当前 session 的 `workspace_path`**，写文件路径必须是该路径的子路径（`isSubPath` 校验）。

| 工具 | 用途 | cwd / 沙箱 | 来源 |
|---|---|---|---|
| `terminal` | 执行 Shell 命令 | cwd = workspace_path · 黑名单 + 危险命令 HIL | mini-OpenClaw 改造 |
| `python_repl` | 执行 Python 代码 | cwd = workspace_path · 临时 venv（可选）| mini-OpenClaw |
| `fetch_url` | 抓取 URL → Markdown | URL 白名单/黑名单 | mini-OpenClaw |
| `search_web` | 联网搜索 | DuckDuckGo / Tavily key | 新做 |
| `read_file` / `write_file` | 文件读写 | 限制在 workspace_path 子树 | mini-OpenClaw 改造 |
| `read_memory` / `write_memory` | 操作 SOUL/MEMORY | 仅限当前 `sessions/{sid}/` | 新做（薄封装） |
| `read_skill` | 加载技能全文（Level 1）| 仅限当前 `sessions/{sid}/skills/` | 新做 |

> **安全模型**：Agent 元数据（SOUL/MEMORY/skills）和用户工作空间是两套独立沙箱。Agent 不能用 `write_file` 误写到 `sessions/{sid}/` 里，也不能用 `write_memory` 误写到 workspace 里。

> **不引入** browser_use（mini-OpenClaw 有），因为依赖 Playwright 装环境复杂，对教学项目是噪音。后期作为可选 plugin。

---

## 10. 里程碑（Milestones）

按"先打通主干，再补自我进化能力"的顺序推进：

### M1 · 运行时 + 三层记忆（P0 主干）

**目标**：能聊天，能用工具，能手动加载技能，会话切换隔离干净。

- [x] 项目初始化（PRD + 目录结构 + 依赖）
- [x] FastAPI 骨架 + 8 个工具迁移
- [x] LangChain 1.x `create_agent` + AsyncSqliteSaver
- [x] prompt_builder 按 session 拼接 SOUL/MEMORY/SKILLS_SNAPSHOT
- [x] SSE 流式 + 基础事件（assistant_token / tool_start / tool_end / turn_end）
- [x] Sessions CRUD API（创建时绑定 workspace_path）
- [x] **工作空间文件树 API**（tree / read / write / mkdir / rename / delete + 目录浏览器）
- [x] **工具 cwd 注入**：所有操作类工具默认 cwd 为 session.workspace_path，写文件路径校验 isSubPath
- [x] 前端骨架：Header + NavSidebar（含工作空间文件树）+ 三个空页面
- [x] 对话页：ChatPanel + ToolCallCard + ChatInput
- [x] 记忆页：MemoryLayerCards + SOUL/MEMORY 编辑
- [x] 技能页：SkillLibrary + SkillDetail + 手动加载
- [x] **NewSessionModal**：包含目录浏览器 + 新建目录功能
- [x] **文件树自动刷新**：监听 SSE `tool_end` 事件中 write_file/terminal 调用，自动 reload
- [x] 端到端冒烟：起一个会话（绑定目录）→ 对话写文件 → 文件树刷新 → 切换会话验证目录跟着切

**验收**：跟 mini-OpenClaw 功能对等，但是 Session 隔离 + 紫色主题 + LangChain 1.x。

### M2 · Skill 自主生成（P1）

**目标**：复杂任务结束后能自动产生 SKILL.md，前端有可视化通知。

- [x] `SkillEngineMiddleware.after_agent` 钩子
- [x] `skill_engine/generator.py` + Pydantic schemas（参考 case-07）
- [x] 异步后台执行 + 失败兜底
- [x] SSE 事件 `skill_generated`（旁路 `/api/events/{sid}/stream`）
- [x] 前端 SkillEventCard + 导航红点
- [x] HISTORY.md 自动生成
- [x] SKILLS_SNAPSHOT 自动重建

**验收**：跑一个 3+ 工具调用的任务，回到技能页能看到新技能。**M2 完成于 v0.2.0-m2 tag**。

### M3 · Skill 自主强化（P1）

**目标**：使用过的技能能自我 patch，版本可见。

- [x] `read_skill` 工具（M1 已有，M3 connect 到 enhancer）
- [x] `skill_engine/enhancer.py`（Actor + Curator 两段 LLM with_structured_output）
- [x] 触发条件检测：本轮使用了 read_skill（`extract_used_skill_names`）
- [x] HISTORY.md 追加 v1.0 → v1.1（含内嵌 unified diff）
- [x] SSE 事件 `skill_enhanced`（旁路 `/api/events/{sid}/stream`，复用 M2）

**M3 完成于 v0.3.0-m3 tag**。
- [x] 前端 EvolutionLog + diff 视图

**验收**：连续两次问类似问题，第二次结束后技能版本号 +1。

### M4 · 高级特性（P2，按需）

- [x] HIL PermissionModal（移植 fufan-cc-flow）
- [x] 定期自省 `before_model` middleware
- [x] AI 优化 MEMORY.md
- [x] 模型切换 + Token 用量条
- [x] case-09 风格的 Session 诊断（HQS 评分）

**M4 完成于 v0.4.0-m4 tag**（177 个后端测试通过）。

---

## 11. 已知限制与未来工作

### 当前不做

| 项 | 原因 |
|---|---|
| 跨 Session 共享 skills/memory | Session 自包含设计的代价；后期加"提升到 global"按钮 |
| FTS5 全文检索 + LLM 摘要管线 | Layer 3 简化为 timeline；教学够用 |
| Honcho 用户建模 | Hermes 原版的 Layer 4，过重 |
| DSPy + GEPA 遗传算法 | case-08 也没做；教学超纲 |
| 容器隔离 / namespace | 教学项目，本地运行优先 |
| 多 Provider 自动 fallback | 简化为单一 OpenRouter |
| 多用户 / 鉴权 | 单用户本地工具 |
| 浏览器自动化（browser_use）| 依赖重，留给 P2 |
| 集成终端（xterm.js）| 与 Agent 主线无关 |

### 未来可加

- **MCP 客户端集成**（让 FF-OpenHermes 自身能挂 MCP server）
- **Skill 商店**（mini-OpenClaw 已有的 GitHub 一键安装）
- **多模型对比 A/B 测试**（同一 prompt 走不同模型看 skill 演化差异）
- **Cron 调度器**（Hermes 原版的定时任务，简化版）

---

## 12. 风险与缓解

| 风险 | 概率 | 影响 | 缓解 |
|---|---|---|---|
| LangChain 1.x middleware API 不稳定 | 中 | 中 | 版本锁定 + 自己抽一层适配器 |
| `with_structured_output` 在 deepseek 上输出不稳 | 中 | 高 | 重试 + 兜底 prompt + lint 兜底 |
| 异步 `after_agent` 与 SSE 流的生命周期冲突 | 中 | 中 | 用独立 task pool，事件经主 SSE 推送 |
| Session 工作区文件膨胀 | 低 | 低 | M3 加自动清理 + 容量上限 |
| OpenRouter 单点故障 | 低 | 高 | 配置可切到 DeepSeek 官方 API（同模型） |
| MEMORY.md 被 Agent 写坏导致下次启动崩 | 中 | 中 | 备份机制：每次写入前 cp 到 `.bak` |

---

## 13. 决策记录

| # | 决策 | 选择 | 日期 |
|---|---|---|---|
| D1 | 项目名称 | **FF-OpenHermes** | 2026-04-29 |
| D2 | 系统提示层结构 | SOUL + MEMORY + SKILLS_SNAPSHOT 三件套 | 2026-04-29 |
| D3 | LLM Provider | OpenRouter `deepseek/deepseek-chat-v3.1` | 2026-04-29 |
| D4 | case-07/08 是否保留独立 demo | 保留作为教学可视化 | 2026-04-29 |
| D5 | Session 模型 | 自包含工作区 | 2026-04-29 |
| D6 | HIL 权限 | 引入 PermissionModal（M4）| 2026-04-29 |
| D7 | 集成终端 | 不做（无关主线）| 2026-04-29 |
| D8 | 优先级 | M1 主干 → M2 生成 → M3 强化 | 2026-04-29 |
| D9 | Agent 框架 | **LangChain 1.x**（与 mini-OpenClaw 同栈）| 2026-04-29 |
| D10 | 工作空间模型 | **每个 session 绑定一个外部项目目录**（`workspace_path`），左侧栏底部显示该目录文件树；类 Claude Code project 模式 | 2026-04-29 |

---

## 附录 A · 引用文档

- `260416从零手搓Hermes Agent/docs/01-Harness-Engineering.md` — 核心理念
- `260416从零手搓Hermes Agent/docs/02-OpenClaw.md` — 对照系统
- `260416从零手搓Hermes Agent/docs/03-Hermes-Agent.md` — Hermes 原版能力
- `260416从零手搓Hermes Agent/docs/04-四大核心功能分析与技术路线.md` — 技术路线
- `260416从零手搓Hermes Agent/docs/05-功能规划与Web布局设计.md` — UI/布局规范
- `260416从零手搓Hermes Agent/docs/06-Stitch使用指南与项目提示词.md` — 视觉规范
- `260205mini-OpenClaw开发实战/mini-OpenClaw/` — 运行时基座
- `20260226Claude Code入门/fufan-cc-flow-src/` — UI 范式参考
- `FF-ProjectBuilder/cases/case-07-skill-distiller/` — 生成引擎原型
- `FF-ProjectBuilder/cases/case-08-skill-evolver/` — 强化引擎原型
- `FF-ProjectBuilder/cases/case-09-harness-diagnostics/` — 诊断原型（P2）

## 附录 B · 名词表

| 术语 | 定义 |
|---|---|
| **Harness** | 围绕模型的约束/告知/验证/纠正/兜底机制集合 |
| **闭环学习循环** | Solve → Document → Retrieve → Improve → Repeat |
| **三层记忆** | Frozen Prompt（L1）+ Skills（L2）+ Session History（L3） |
| **Session 即工作区** | 每个会话拥有独立的 SOUL/MEMORY/skills/state.db 目录 |
| **三级加载** | Level 0（仅名称+描述）/ Level 1（全文）/ Level 2（引用文件，本期不做） |
| **HIL** | Human-in-the-loop，危险操作前用户确认 |
| **Middleware 钩子** | LangChain 1.x 提供的 before_agent / before_model / after_model / after_agent 四个生命周期切点 |

---

*文档结束 · 下一步：用 `superpowers:writing-plans` 拆 M1 实施计划*
