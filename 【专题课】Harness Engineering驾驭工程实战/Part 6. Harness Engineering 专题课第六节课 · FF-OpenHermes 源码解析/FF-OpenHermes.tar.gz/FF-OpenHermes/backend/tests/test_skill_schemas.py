"""Tests for Pydantic schemas used by the skill generator."""
import pytest
from pydantic import ValidationError

from skill_engine.schemas import GeneratedSkill, GeneratorOutput


def test_generated_skill_minimal_valid():
    s = GeneratedSkill(
        name="extract-web-table",
        description="Scrape HTML tables from web pages and export to Excel. Use when the user asks to scrape table or save webpage data.",
        body="# extract-web-table\n\n## Overview\n...",
        triggers=["scrape table", "extract table"],
    )
    assert s.name == "extract-web-table"
    assert len(s.triggers) == 2


def test_generated_skill_coerces_name_to_kebab():
    """LLM-produced snake_case / spaced / cased names are normalized, not rejected.

    Regression guard for the distill bug: the model frequently emitted
    `pg_query_perf_fix`-style names that the old strict validator rejected,
    silently dropping otherwise-valid skills.
    """
    body = "# title\n## Overview\nlong enough body content here"
    cases = {
        "pg_query_perf_fix": "pg-query-perf-fix",
        "Nginx Reverse Proxy": "nginx-reverse-proxy",
        "foo__bar  baz": "foo-bar-baz",
        "123-skill": "skill-123-skill",
    }
    for raw, expected in cases.items():
        s = GeneratedSkill(
            name=raw,
            description="Long enough description that mentions when to use it.",
            body=body,
            triggers=["x"],
        )
        assert s.name == expected, f"{raw!r} -> {s.name!r}, expected {expected!r}"


def test_generated_skill_rejects_empty_triggers():
    with pytest.raises(ValidationError):
        GeneratedSkill(
            name="x-skill",
            description="Long enough description that mentions when to use it.",
            body="# title",
            triggers=[],
        )


def test_generated_skill_rejects_long_name():
    with pytest.raises(ValidationError):
        GeneratedSkill(
            name="x" * 65,
            description="Long enough description that mentions when to use it.",
            body="# t",
            triggers=["a"],
        )


def test_generator_output_no_skill_branch():
    o = GeneratorOutput(decision="NO_SKILL", skill=None, reasoning="Task too trivial")
    assert o.decision == "NO_SKILL"
    assert o.skill is None


def test_generator_output_generate_branch_requires_skill():
    with pytest.raises(ValidationError, match="skill"):
        GeneratorOutput(decision="GENERATE", skill=None, reasoning="x")
