"""E3 background_review — fork combined sub-agent 自主复盘（agentic，对齐本源 background_review）。

每轮结束 nudge 命中由 SkillEngineMiddleware 调度。fork 受限 sub-agent → 自主调 skill_manage /
write_memory 沉淀 memory + skill（combined，取代原来的 structured-output pipeline）。

4 重约束：
  ① recursion_limit=16（步数上限）
  ② 独立 ainvoke 不经父 astream → SSE 天然隔离
  ③ 工具集隔离：只给 memory+skills 四个工具，无 terminal/python/search
  ④ middleware=[]（防递归：sub-agent 不挂 SkillEngineMiddleware）

所有失败吞掉返回 None，安全用于后台 asyncio 调度。
"""
import logging
import traceback
from pathlib import Path
from typing import Any, Callable

from langchain.agents import create_agent
from langchain_core.messages import BaseMessage, HumanMessage

from agent.skill_provenance import set_write_origin, reset_write_origin, BACKGROUND

logger = logging.getLogger("skill_engine.background_review")

# 移植本源 _COMBINED_REVIEW_PROMPT（引导 sub-agent 自主调工具沉淀 memory + skill）
COMBINED_REVIEW_PROMPT = """你是后台自审 agent，复盘刚结束的一轮对话，自主沉淀「记忆」和/或「技能」。
这两个维度相互独立，必须分别判断——一轮对话可以同时产出记忆和技能，也可以只产其一。
不要把它们当成二选一：发现了可复用方法就建技能，发现了持久用户信息就写记忆，二者可兼得。

你只能调用这几个工具：read_memory / write_memory / read_skill / skill_manage。其他工具会被拒绝。

**记忆维度**（write_memory）：对话里有没有值得长期记住的 user 画像 / 持久偏好 / 协作期望？有就 write_memory 存。
不要存环境型一次性失败、否定型断言、一次性任务叙述、已在 MEMORY.md 的重复内容。

**技能维度**（skill_manage）：这轮回答里有没有「下次遇到同类问题能照着做」的步骤化方法？
只要有可复用的工作流 / 技巧 / 排错套路 / 命令组合 / 修复方法 / 最佳实践 / 用户纠正，就该沉淀成技能——
技术 how-to、排错流程、操作步骤都算数，不要因为「这只是个小技巧」就跳过。判定到后：
  1. 先 read_skill 看现有技能，能 patch 就 skill_manage(action=patch) 改进它（PATCH 优先）
  2. 没有合适的现有技能，才 skill_manage(action=create) 建新技能（name 必须 class-level kebab-case，
     概括这"一类"问题，禁用 PR 号/错误串/fix-X 这类一次性词）
  3. 可选 skill_manage(action=write_file) 加 references/templates/scripts 支持文件

判定基线：对话里出现了可复用的技术方法 → 必须创建或改进一个技能；出现了持久用户信息 → 写记忆。
只有当对话纯属闲聊、既无任何可复用方法、也无新用户信息时，才回复「Nothing to save.」并停止——
但不要为凑数编造空洞或一次性的低质技能。

现在复盘下面的对话，自主调工具沉淀，完成后简述你做了什么。
"""


def _format_trace(messages: list[BaseMessage]) -> str:
    """把对话快照压成可读 trace（保留 human/ai，略过 tool 消息）。"""
    lines: list[str] = []
    for m in messages:
        role = getattr(m, "type", None)
        content = (getattr(m, "content", "") or "").strip()
        if role == "human":
            lines.append(f"USER: {content}")
        elif role == "ai":
            if content:
                lines.append(f"ASSISTANT: {content}")
        # tool 消息略过：sub-agent 关注对话内容，不需要工具结果细节
    return "\n".join(lines)


async def spawn_review_subagent(
    messages_snapshot: list[BaseMessage],
    session_dir: Path,
    llm_factory: Callable,
) -> dict[str, Any] | None:
    """fork 受限 sub-agent 自主复盘 → 调 skill_manage/write_memory 沉淀（agentic，对齐本源 background_review）。

    4 重约束 + BACKGROUND provenance + best-effort 吞错。返回 {actions: [...]} 或 None。
    """
    try:
        trace = _format_trace(messages_snapshot)
        if not trace.strip():
            return None

        # 工具复用现有 factory（③ 工具集隔离：只给 memory+skills 四个工具，无 terminal/python/search）
        from tools.skill_tool import create_skill_manage_tool, create_read_skill_tool
        from tools.memory_tool import create_write_memory_tool, create_read_memory_tool

        tools = [
            create_skill_manage_tool(session_dir),
            create_write_memory_tool(session_dir=session_dir),
            create_read_skill_tool(session_dir),
            create_read_memory_tool(session_dir=session_dir),
        ]
        review_agent = create_agent(
            model=llm_factory(),     # 复用父 llm（与本源继承父 runtime 一致）
            tools=tools,
            middleware=[],           # ④ 防递归：sub-agent 不挂 SkillEngineMiddleware
        ).with_config(recursion_limit=16)   # ① 步数上限

        prompt = COMBINED_REVIEW_PROMPT + "\n\n--- 本轮对话 ---\n" + trace

        # provenance：BACKGROUND 包裹 → sub-agent 调 skill_manage create 时 created_by=agent（R1 已验证传播）
        token = set_write_origin(BACKGROUND)
        try:
            # ② 安静：独立 ainvoke 不经父 astream，SSE 天然隔离
            # config 隔离（configurable={}）：middleware 经 create_task 复制了父对话 astream 的 context，
            # 内含父 AsyncSqliteSaver checkpointer；不隔离则 fork sub-agent 复用父 state.db，主对话退出
            # 关闭 db 后报 "Cannot operate on a closed database"（端到端真跑暴露，probe 未覆盖）。
            result = await review_agent.ainvoke(
                {"messages": [HumanMessage(content=prompt)]},
                config={"configurable": {}},
            )
        finally:
            reset_write_origin(token)

        actions = _extract_tool_actions(result)   # 从 result.messages 提取 sub-agent 调了哪些工具
        return {"actions": actions} if actions else None
    except Exception as e:
        logger.error("spawn_review_subagent error: %s\n%s", e, traceback.format_exc())
        return None


def _extract_tool_actions(result: dict) -> list[str]:
    """从 sub-agent invoke 结果提取成功的工具动作（用于通知事件）。"""
    actions: list[str] = []
    for m in result.get("messages", []) if isinstance(result, dict) else []:
        for tc in getattr(m, "tool_calls", []) or []:
            name = tc.get("name", "")
            if name in ("skill_manage", "write_memory"):
                args = tc.get("args", {})
                # or 短路 None：LLM 可能对 tool_call 显式传 action=None（dict.get 命中 key 返回 None 而非 default）
                val = args.get("action") or args.get("entry") or ""
                actions.append(f"{name}:{str(val)[:40]}")
    return actions
