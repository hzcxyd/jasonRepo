#!/usr/bin/env bash
# FF-OpenHermes 后端启动（开发模式）
#   --reload：改任意 .py 文件自动热重载（sessions/ 下的技能/记忆数据写入不会触发，
#             因为 uvicorn 默认只监视 *.py）。
#   HOST/PORT：跟随 backend/.env（默认 127.0.0.1:8013）。
#   解释器：默认用 harness conda 环境；可用 PYTHON=/path/to/python ./start.sh 覆盖。
set -euo pipefail
cd "$(dirname "$0")"

PY="${PYTHON:-/opt/anaconda3/envs/harness/bin/python}"
HOST="$(grep -E '^HOST=' .env 2>/dev/null | cut -d= -f2- | tr -d ' ' || true)"
PORT="$(grep -E '^PORT=' .env 2>/dev/null | cut -d= -f2- | tr -d ' ' || true)"

exec "$PY" -m uvicorn app:app --reload --host "${HOST:-127.0.0.1}" --port "${PORT:-8013}"
