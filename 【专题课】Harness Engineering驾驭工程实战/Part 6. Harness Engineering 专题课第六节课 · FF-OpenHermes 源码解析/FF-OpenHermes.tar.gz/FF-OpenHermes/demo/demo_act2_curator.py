"""Act 2 实测：curator 自治理 fork sub-agent —— 合并 3 个相似 agent 技能成 umbrella，
   user 技能(my-precious) 不受治理。带 fail-fast 落盘校验，避免静默写空。"""
import httpx, json, time, sys, os
from pathlib import Path
BASE = "http://127.0.0.1:8013/api"
BACKEND = "/Users/mac/PycharmProjects/JupyterProject/OpenHermes/FF-OpenHermes/backend"
os.chdir(BACKEND); sys.path.insert(0, BACKEND)

from agent.skill_ops import SkillOps
from agent.skill_provenance import set_write_origin, reset_write_origin, BACKGROUND

# ① 经 API 建 session（与服务端 session_dir 一致）
sid = httpx.post(f"{BASE}/sessions", json={"title": "demo-act2-curator", "workspace_path": "/tmp"}, timeout=30).json()["id"]
print("=" * 60)
print("SESSION:", sid)
print("=" * 60)

sd = Path(BACKEND) / "sessions" / sid
ops = SkillOps(sd)

def mk(name, desc, body, *, background):
    content = f"""---
name: {name}
description: {desc}
version: 1.0
generated_by: {"skill_manage" if not background else "agent"}
created_at: 2026-06-12
---

# {name}

{body}
"""
    if background:
        tok = set_write_origin(BACKGROUND)
        try: ops.write_skill(name, content, history_line="agent 后台自沉淀")
        finally: reset_write_origin(tok)
    else:
        ops.write_skill(name, content, history_line="user 前台手工创建")

# ② 3 个高度相似的 agent 技能（应被 curator 合并）+ 1 个 user 技能（不受治理）
mk("write-report", "把分析结果写成结构化报告：标题+背景+发现+结论",
   "步骤：1) 写标题 2) 写背景 3) 列发现 4) 给结论。输出 markdown。", background=True)
mk("write-summary", "把长文档压缩成结构化摘要：要点+结论",
   "步骤：1) 提取要点 2) 归纳结论。输出 markdown 列表。", background=True)
mk("write-doc", "把零散笔记整理成结构化文档：概述+小节+总结",
   "步骤：1) 写概述 2) 分小节 3) 写总结。输出 markdown。", background=True)
mk("my-precious", "我私藏的发布流程：build→tag→push→release，绝不能被合并",
   "这是我手工维护的关键发布流程，user 资产。", background=False)

# ③ fail-fast 落盘校验
skills = {s["name"]: s for s in ops.list_skills()}
prov = {n: ops.created_by(n) for n in skills}
print("\n【整理前·落盘校验】")
for n in ["write-report", "write-summary", "write-doc", "my-precious"]:
    assert n in skills, f"❌ 落盘失败：{n} 未写入 {sd}"
    print(f"  · {n:16s} created_by={prov[n]}")
assert prov["write-report"] == "agent" and prov["my-precious"] == "user", \
    f"❌ provenance 错：{prov}"
assert (ops.skills_dir / "SKILLS_SNAPSHOT.md").exists(), "❌ SNAPSHOT 未生成"
print("  ✅ 4 技能落盘 + provenance 正确 + SNAPSHOT 存在")

# ④ 触发 curator sub-agent（真跑，非 dry_run）
print("\n【触发 curator fork sub-agent（recursion_limit=10）...】")
t0 = time.time()
r = httpx.post(f"{BASE}/sessions/{sid}/skills/curate", json={"dry_run": False}, timeout=300)
report = r.json()
print(f"  耗时 {time.time()-t0:.1f}s, HTTP {r.status_code}")
print("  report:", json.dumps(report, ensure_ascii=False, indent=2)[:800])

# ⑤ 整理后复查
time.sleep(1)
survivors = {s["name"]: ops.created_by(s["name"]) for s in ops.list_skills() if s["name"] != "SKILLS_SNAPSHOT.md"}
archive_dir = ops.skills_dir / ".archive"
archived = [p.name for p in archive_dir.iterdir() if p.is_dir()] if archive_dir.exists() else []
print("\n【整理后·存活技能】")
for n, cb in survivors.items():
    print(f"  · {n:20s} [{cb}]")
print("【已归档】", archived)
print("\n【验收】")
print("  my-precious 仍存活(user 不受治理):", "✅" if "my-precious" in survivors else "❌")
print("  发生合并/归档动作:", "✅" if (report.get('actions') or archived) else "⚠️ 无动作")
print("\nSID:", sid)
