"""Act 1 实测：同 session 双重 provenance（前台 user + 后台 agent）+ 学员可见性。"""
import httpx, json, time, sys, os
from pathlib import Path
BASE = "http://127.0.0.1:8013/api"
BACKEND = "/Users/mac/PycharmProjects/JupyterProject/OpenHermes/FF-OpenHermes/backend"
os.chdir(BACKEND); sys.path.insert(0, BACKEND)

sid = httpx.post(f"{BASE}/sessions", json={"title": "demo-act1", "workspace_path": "/tmp"}, timeout=30).json()["id"]
print("session:", sid, "\n")

# 步骤①：前台主动存技能（明说存 → created_by=user）
# 步骤②③④：碎片化聊另一主题，绝不提存 → 后台 nudge 产 created_by=agent
prompts = [
    ("①前台·明说存", "我有套固定的 conda 部署流程：先 conda create 建环境，再 pip install 装依赖，最后 uvicorn 启动服务。请用 skill_manage 工具把它存成一个叫 conda-deploy 的技能。"),
    ("②后台·碎片聊", "换个完全不同的问题——我 PostgreSQL 有个查询突然从几十毫秒变 3 秒，EXPLAIN ANALYZE 看到全表扫描，大概什么方向？"),
    ("③后台·碎片聊", "嗯确认了，是 WHERE 条件用 lower() 把字段包起来导致索引失效。"),
    ("④后台·夹画像", "对了我是后端工程师，主要做 Python 数据后台，PostgreSQL 和 Redis 用得多，回答习惯结论先行。"),
]

for tag, msg in prompts:
    fg = []
    with httpx.stream("POST", f"{BASE}/chat", json={"session_id": sid, "message": msg}, timeout=150) as resp:
        ev = None
        for line in resp.iter_lines():
            if line.startswith("event:"): ev = line[6:].strip()
            elif line.startswith("data:"):
                try: o = json.loads(line[5:].strip())
                except Exception: continue
                if ev == "tool_start" and o.get("name") in ("skill_manage", "write_memory"): fg.append(o.get("name"))
    print(f"  {tag} 完成{'  前台调:'+str(fg) if fg else ''}")

print("\n等后台 nudge fork 复盘（40s）...")
time.sleep(40)

from agent.skill_ops import SkillOps
ops = SkillOps(Path(BACKEND) / "sessions" / sid)
print("\n===== /skills 页学员会看到的（双重 provenance）=====")
for s in ops.list_skills():
    cb = ops.created_by(s["name"])
    章 = "🟦 user（你教的）" if cb == "user" else "🟩 agent（它自学的）" if cb == "agent" else cb
    print(f"  · {s['name']:30s} [{章}]")
print("\nSID:", sid)
