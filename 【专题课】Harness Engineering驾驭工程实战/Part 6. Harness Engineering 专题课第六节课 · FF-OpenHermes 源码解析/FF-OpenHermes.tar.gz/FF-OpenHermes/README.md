# FF-OpenHermes

> 一个能记住你、自主写技能、不断进化的 AI Agent 教学项目。
> 基于 Hermes Agent (Nous Research) 设计哲学 + LangChain 1.x + Next.js 14 实现。

![status](https://img.shields.io/badge/status-v0.4.0--m4-brightgreen) ![tests](https://img.shields.io/badge/backend_tests-177_passing-success) ![license](https://img.shields.io/badge/license-MIT-blue)

---

## 这是什么？

FF-OpenHermes 用 4 个里程碑（M1 → M4）演示了一个**自我进化 Agent**的完整闭环：

1. **M1 · 运行时基础** — Web 聊天 / 工作目录绑定 / 三层记忆（SOUL.md + MEMORY.md + SqliteSaver）/ 手动技能管理
2. **M2 · 技能自主生成** — Agent 用过 ≥3 个工具就反思、提炼成可复用的 SKILL.md（双段 LLM Generator）
3. **M3 · 技能自主强化** — Agent 复用某技能时再次反思，输出 v1.1 patch（Actor + Curator 两阶段）
4. **M4 · 高级特性** — HIL 危险命令拦截 / 周期性自省 / AI 优化 MEMORY / 模型切换 + Token 计量 / HQS 会话诊断

**核心立意**：Solve → Document → Improve → Repeat（解决问题 → 沉淀技能 → 持续打磨 → 循环）。

## 截图 / Demo

聊天 + 工作目录 + 实时事件流：左侧栏 + 中间对话 + 文件树。
访问 `/memory` 看三层记忆 + HQS 诊断；访问 `/skills` 看技能库 + 演进历史。

## 技术栈

| 层 | 技术 |
|---|---|
| **Backend** | Python 3.10+ · FastAPI · LangChain 1.x (`create_agent`, `AgentMiddleware`) · LangGraph (`AsyncSqliteSaver`) · Pydantic v2 · sse-starlette |
| **Frontend** | Next.js 14 App Router · TypeScript（strict）· Tailwind v3 · Zustand · Monaco Editor · react-markdown + remark-gfm · lucide-react |
| **LLM** | OpenRouter（默认 `deepseek/deepseek-chat-v3.1`，可在 Header 切换 4 个 preset） |
| **持久化** | 每个 session 一个独立目录：`sessions/{sid}/{SOUL,MEMORY}.md`、`state.db`（SqliteSaver）、`skills/`、`diagnostics.json` |
| **事件机制** | Chat 主流：sse-starlette；旁路：`/api/events/{sid}/stream`（M2/M3/M4 后台事件） |

## 仓库结构

```
FF-OpenHermes/
├── backend/                     Python FastAPI 后端（端口 8013）
│   ├── app.py                   入口 + 路由注册
│   ├── agent/                   LangChain runtime + middleware + memory_ops
│   │   ├── agent_factory.py     create_agent(...) 构造
│   │   ├── agent_manager.py     astream() 主循环 + usage 事件
│   │   ├── middleware.py        SkillEngineMiddleware（before/after_model + after_agent）
│   │   ├── memory_ops.py        SOUL.md / MEMORY.md 读写 + .bak
│   │   ├── memory_optimizer.py  AI 优化 MEMORY.md（M4 Phase C）
│   │   ├── permission_registry.py  HIL 等待注册表（M4 Phase A）
│   │   └── diagnostics.py       HQS 诊断（M4 Phase E）
│   ├── skill_engine/            自主生成 + 强化的技能引擎
│   │   ├── generator.py         M2 双段 LLM 生成
│   │   ├── enhancer.py          M3 Actor + Curator 强化
│   │   ├── lint.py / detect.py / diff.py
│   │   └── enhancer_schemas.py / generator_schemas.py
│   ├── api/                     FastAPI 路由
│   │   ├── chat.py              POST /api/chat（SSE）
│   │   ├── events.py            旁路 SSE
│   │   ├── permission.py        HIL 反向通道
│   │   ├── memory.py / sessions.py / skills.py / workspace.py / diagnostics.py
│   │   └── fs.py                目录浏览
│   ├── tools/                   内置工具（terminal / fetch_url / search_web / read_skill / write_memory ...）
│   ├── tests/                   pytest（177 个）
│   ├── requirements.txt
│   └── .env.example             复制为 .env 后填入 API key
│
├── frontend/                    Next.js 前端（端口 3001）
│   └── src/
│       ├── app/                 App Router（/, /memory, /skills）
│       ├── components/          chat/ + memory/ + skills/ + layout/
│       ├── stores/              Zustand store（chat / session / event / memory / skill / workspace）
│       ├── hooks/               useSseStream（chat）+ useEventStream（旁路）
│       ├── services/api.ts      所有 fetch 封装
│       └── types/api.ts         共享类型
│
├── docs/                        每个 milestone 的 plan + smoke checklist
│   ├── M1-plan.md / M2-plan.md / M3-plan.md / M4-plan.md
│   ├── M1-smoke-checklist.md … M4-smoke-checklist.md
│   └── M4-polish-backlog.md     已知非阻塞优化项
├── PRD.md                       产品需求文档（设计决策 D1-D10、M1-M4 任务清单）
└── README.md                    本文档
```

---

## 快速开始（Mac / Linux）

> Windows 可参考下方"Windows 备注"小节，差异仅在虚拟环境激活路径。

### 0. 前置条件

- **Python ≥ 3.10**（建议 3.11）
- **Node.js ≥ 18**（建议 20 LTS）
- **OpenRouter API Key** —— 注册 https://openrouter.ai/ 即送少量额度
- 推荐 macOS 12+，Apple Silicon 已验证

### 1. 解压 + 进入项目

```bash
tar -xzf FF-OpenHermes-v0.4.0-m4.tar.gz
cd FF-OpenHermes
```

### 2. Backend 安装 + 启动

```bash
cd backend

# 创建虚拟环境
python3 -m venv .venv
source .venv/bin/activate     # Mac/Linux
# Windows: .venv\Scripts\activate

# 安装依赖
pip install -r requirements.txt

# 配置 .env
cp .env.example .env
# 编辑 .env，填入 OPENROUTER_API_KEY=sk-or-v1-xxx

# 跑 177 个测试，确认环境 OK
pytest -v          # 期望：177 passed

# 启动后端（保持开着）
uvicorn app:app --reload --host 127.0.0.1 --port 8013
```

后端就绪标志：终端打印 `Application startup complete.`，访问 http://127.0.0.1:8013/openapi.json 能看到所有路由。

### 3. Frontend 安装 + 启动

**新开一个 terminal**，回到项目根：

```bash
cd FF-OpenHermes/frontend

# 安装依赖（首次约 1-2 分钟）
npm install

# 检查能否构建
npm run build      # 期望 "Compiled successfully"

# 开发模式（保持开着）
npm run dev
```

前端就绪标志：终端打印 `Ready in X.Xs`。浏览器访问 http://localhost:3001/

### 4. 第一次使用

1. 浏览器打开 http://localhost:3001/
2. 顶部点 **+ 新建** 创建会话，选一个空目录作为 workspace（项目自带 `examples/` 可作起点，也可以自建）
3. 在底部输入框发送：`列一下当前工作目录的文件`
4. Agent 应该调用 `terminal` 工具并回复

成功验收：
- 聊天能流式收到 token
- `/memory` 页面可查看 SOUL.md / MEMORY.md / 会话历史
- `/skills` 页面（连续多工具任务后）会出现自动生成的技能

---

## 配置 / 环境变量（`backend/.env`）

| 变量 | 说明 | 默认 |
|---|---|---|
| `OPENROUTER_API_KEY` | **必填**。OpenRouter key | — |
| `OPENROUTER_BASE_URL` | OpenRouter 网关 | `https://openrouter.ai/api/v1` |
| `OPENROUTER_MODEL` | 默认模型 ID | `deepseek/deepseek-chat-v3.1` |
| `TAVILY_API_KEY` | Tavily 联网搜索（可选） | — |
| `HOST` / `PORT` | 后端监听地址 | `127.0.0.1:8013` |
| `CORS_ORIGINS` | 前端来源白名单 | `http://localhost:3001` |
| `SKILL_GEN_THRESHOLD` | M2 触发阈值（≥N 个工具就提取技能） | `3` |
| `MEMORY_REFLECTION_INTERVAL` | M4 自省周期（每 N 轮注入反思提示，0 关闭） | `5` |

### 模型选择

OpenRouter 在某些区域会**屏蔽 anthropic / openai / google 系**模型（403）。本项目默认 `deepseek/deepseek-chat-v3.1` 是因为它对该限制免疫，且 function-calling 稳定。

Header 右上的模型下拉支持运行时切换 4 个 preset：
- DeepSeek Chat v3.1（默认）
- DeepSeek Chat
- Qwen 2.5 72B Instruct
- GLM 4.6

---

## 五大 M4 高级特性使用方式

| 特性 | 触发方式 | 表现 |
|---|---|---|
| **HIL 命令确认**（A） | 让 Agent 用 `terminal` 跑 `rm` / `del` / `mv` 等危险命令 | 弹出"需要授权"模态框，3 选 1（允许一次 / 本会话总是允许 / 拒绝），60 秒不响应自动拒绝。`rm -rf /` 等绝对黑名单不会弹窗，直接硬拒。 |
| **周期性自省**（B） | 连续聊 5 轮（可改 `MEMORY_REFLECTION_INTERVAL`） | 第 5、10、15... 轮 Agent 会主动调 `write_memory` 沉淀重要事实 |
| **AI 优化 MEMORY**（C） | `/memory` 页面 → MEMORY.md 卡 → 点 **AI 优化** | LLM 重写 MEMORY.md 为结构化 sections，自动生成 `.bak` 备份 |
| **模型切换 + Token 条**（D） | Header 模型下拉 + 输入框上方 token 条 | 切换模型立即生效；token 条显示当前轮的 input/output/合计 |
| **HQS 会话诊断**（E） | `/memory` → 切到"会话历史" tab → 点 🩺 **诊断本次会话** | 5-15 秒后显示 0-10 分（红 / 橙 / 绿 ring）+ 5 类失败模式徽章 + 分析 + 修复建议。诊断结果持久化到 `sessions/{sid}/diagnostics.json` |

详细的逐场景脚本见 `docs/M4-smoke-checklist.md`。

## Milestone & 版本

| 版本 tag | 内容 | 文档 |
|---|---|---|
| `v0.1.0-m1` | 运行时基础（Chat + Workspace + 三层记忆 + 手动 skill） | `docs/M1-plan.md` |
| `v0.2.0-m2` | 技能自主生成 | `docs/M2-plan.md` |
| `v0.3.0-m3` | 技能自主强化（Actor + Curator） | `docs/M3-plan.md` |
| `v0.4.0-m4` | HIL / 自省 / AI 优化 MEMORY / 模型切换 / HQS 诊断 | `docs/M4-plan.md` |

```bash
git tag                           # 列出 4 个版本
git checkout v0.3.0-m3            # 回到任一阶段
```

## 脚本速查

```bash
# Backend
cd backend && source .venv/bin/activate
pytest -v                          # 177 个测试
pytest tests/test_diagnostics.py   # 单文件
uvicorn app:app --reload --port 8013

# Frontend
cd frontend
npm run dev                        # 开发模式
npm run build                      # 生产构建（验证 type + lint）
npm run lint                       # 单跑 lint
npm run start                      # 启动生产服务（先 build）
```

## Troubleshooting

### 前端报 `Cannot find module './XXX.js'`

`.next/` 缓存腐化。清掉重启即可：

```bash
cd frontend
rm -rf .next
npm run dev
```

### 后端 OpenRouter 返回 403

你的 IP 命中了 anthropic / openai / google 区域屏蔽。请确认 `.env` 里的 `OPENROUTER_MODEL=deepseek/deepseek-chat-v3.1`，或在 Header 下拉切到 DeepSeek/Qwen/GLM。

### 后端启动报 `address already in use`

```bash
lsof -i :8013                      # Mac / Linux 找占端口的 PID
kill -9 <PID>
```

### M4 路由 404（升级后未重启后端）

`uvicorn --reload` 不会重新加载新 router 的注册。修改 `app.include_router(...)` 或新增 router 文件后，**完整重启 uvicorn**。

### Pytest 失败 `httpx ASGITransport deadlock`

部分 SSE 测试需要真 uvicorn 守护线程 + `trust_env=False`，已在 `tests/conftest.py` 处理。如自定义跑某个 SSE 测试 hang 住，参考 `M2-plan.md` Bundle 3 的解决方案。

## Windows 备注

Windows 唯一的差异是虚拟环境激活路径：

```powershell
# 创建
python -m venv .venv

# 激活
.venv\Scripts\activate            # PowerShell
# 或 .venv\Scripts\activate.bat   # cmd

# pytest 路径（如不激活直接调用）
.venv\Scripts\pytest -v
```

其他完全相同（fastapi/uvicorn/Next.js 都跨平台）。Windows 11 + Apple Silicon Mac 都已验证。

## 待优化（M5 候选）

- 技能页可视化升级（参考 `FF-ProjectBuilder/cases/case-08-skill-evolver` 的演进时间轴）
- HIL 扩展到 `write_file` / `python_repl` 等更多工具
- Token 条改为整轮累计（多次 LLM call 求和）
- HQS 诊断 503 的前端 toast 提示
- 见 `docs/M4-polish-backlog.md`（10 项已识别但延后的非阻塞优化）

## 致谢与参考

- **Hermes Agent**（Nous Research）—— 设计哲学源头
- **mini-OpenClaw** —— LangChain 1.x 运行时蓝本
- **Claude Code / fufan-cc-flow** —— PermissionModal HIL 模式参考
- **case-08-skill-evolver** —— 技能演进可视化参考
- **case-09-harness-diagnostics** —— HQS 诊断参考

## License

MIT
