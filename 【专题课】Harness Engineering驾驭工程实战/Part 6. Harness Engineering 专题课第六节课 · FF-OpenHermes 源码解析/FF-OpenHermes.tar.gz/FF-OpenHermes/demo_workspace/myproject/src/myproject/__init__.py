"""myproject - A Python project scaffold."""

__version__ = "0.1.0"
