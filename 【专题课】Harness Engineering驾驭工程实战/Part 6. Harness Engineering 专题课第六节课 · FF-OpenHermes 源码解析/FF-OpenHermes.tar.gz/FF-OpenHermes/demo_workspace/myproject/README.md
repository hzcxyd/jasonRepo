# myproject

A Python project scaffold.

## Installation

```bash
pip install .
```

## Development

```bash
pip install -e ".[dev]"
```

## Testing

```bash
pytest
```
