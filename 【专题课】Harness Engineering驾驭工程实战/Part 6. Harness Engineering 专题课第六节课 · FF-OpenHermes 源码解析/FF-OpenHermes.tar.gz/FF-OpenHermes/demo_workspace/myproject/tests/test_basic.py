"""Basic tests for myproject."""

import myproject


def test_version():
    """Verify the package version."""
    assert myproject.__version__ == "0.1.0"


def test_import():
    """Verify the package can be imported."""
    assert myproject is not None
