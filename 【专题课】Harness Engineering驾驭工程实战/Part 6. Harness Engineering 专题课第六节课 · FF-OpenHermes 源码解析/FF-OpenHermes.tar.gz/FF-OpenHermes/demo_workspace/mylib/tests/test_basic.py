"""Basic tests for mylib."""

import mylib


def test_version():
    """Verify the package version."""
    assert mylib.__version__ == "0.1.0"


def test_import():
    """Verify the package can be imported."""
    assert mylib is not None
