"""mylib - A reusable Python library scaffold."""

__version__ = "0.1.0"
