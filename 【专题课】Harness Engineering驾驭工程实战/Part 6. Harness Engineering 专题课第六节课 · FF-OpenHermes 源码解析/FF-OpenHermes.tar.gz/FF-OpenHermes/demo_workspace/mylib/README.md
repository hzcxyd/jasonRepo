# mylib

A reusable Python library scaffold.

## Installation

```bash
pip install .
```

## Development

```bash
pip install -e ".[dev]"
```

## Testing

```bash
pytest
```
