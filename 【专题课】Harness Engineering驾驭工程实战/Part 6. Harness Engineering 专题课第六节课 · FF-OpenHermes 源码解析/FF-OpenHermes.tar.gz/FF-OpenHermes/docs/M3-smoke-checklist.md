# M3 Smoke Checklist · Skill 自主强化

> Run after `git checkout v0.3.0-m3`. Backend on `:8003`, frontend on `:3000`.

## Pre-flight

- [ ] `cd backend && .venv/Scripts/pytest -v` → **142 passed**
- [ ] `cd frontend && npm run build` → clean compile, all routes
- [ ] Backend `.env`: `OPENROUTER_MODEL=deepseek/deepseek-chat-v3.1`, `SKILL_GEN_THRESHOLD=3`
- [ ] At least one auto-generated skill from M2 exists in some session (run M2's Scenario A first if not)

## Scenario A — Enhancement triggers when skill is loaded

1. [ ] Open browser → http://localhost:3000
2. [ ] In a session with an existing auto-generated skill, go to /skills page
3. [ ] Click the skill, then "Load (Level 1)"
4. [ ] Switch back to chat. Send a prompt that uses that skill plus 3+ other tools, e.g.:
       _"用刚加载的技能帮我处理 https://example.com，然后用 terminal 把结果保存到 result.txt"_
5. [ ] Wait for assistant turn to complete
6. [ ] **Within 1-2 seconds: an "⚡ Analyzing Skill…" placeholder card appears with a spinner + the skill name**
7. [ ] **Within 5-15 more seconds: the placeholder is replaced with "Skill Enhanced · v1.1" card showing the summary**
8. [ ] Navigate to /skills, select the enhanced skill
9. [ ] EvolutionLog (right panel) shows TWO version cards: v1.1 (top, expanded) and v1.0
10. [ ] Click v1.1 — see the summary text + the unified diff (red - lines and green + lines)

## Scenario B — NO_UPDATE branch

1. [ ] Use a skill but for a task it handles trivially (e.g. exact same workflow as the skill's documented steps)
2. [ ] Watch for "⚡ Analyzing Skill…" placeholder
3. [ ] Within 5-15s the placeholder simply disappears (no enhanced card)
4. [ ] /skills EvolutionLog shows NO new version (still at v1.0)

## Scenario C — Debounce

1. [ ] Right after a successful enhancement (Scenario A), send another similar prompt that uses the same skill
2. [ ] No new enhancement should fire (debounced for 5 minutes)
3. [ ] Check backend log: should see `skill X enhanced recently; skipping (debounce)`

## Scenario D — M2 path still works

1. [ ] Send a complex prompt that uses ≥3 tools but does NOT load any existing skill (no `read_skill` call)
2. [ ] **The original M2 SkillEventCard "Skill Auto-Generated" still appears** (M3 didn't break it)
3. [ ] /skills shows the new auto-generated skill
4. [ ] Both nav-red-dot logic and inline event cards still work

## Known limitations

- Live notifications only — refresh the page mid-enhancement and the placeholder vanishes (the persistent state is `stats.skills_enhanced` counter + the v1.1 SKILL.md on disk).
- 5-minute debounce window is hardcoded; can be tuned in `enhancer.was_enhanced_recently`.
- Curator's `new_body` is generated holistically — no fine-grained `added`/`removed` rule list (case-08 had this for visualization; we compute the diff post-hoc via `difflib`).
- Long bodies (8k+ chars) may push the second LLM call over context limits with deepseek; we cap body at 10000 chars in Pydantic schema.

## What M4 will add (cherry-pick)

- HIL PermissionModal for risky terminal commands
- Periodic memory reflection (`before_model` middleware)
- AI-powered MEMORY.md compaction
- Model switcher + token usage indicator
- HQS Session diagnostics (case-09 port)
