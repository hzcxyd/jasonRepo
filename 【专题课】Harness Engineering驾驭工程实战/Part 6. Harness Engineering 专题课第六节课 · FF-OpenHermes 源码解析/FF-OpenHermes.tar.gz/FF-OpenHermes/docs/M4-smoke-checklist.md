# M4 Smoke Checklist · 5 Advanced Features

> Run after `git checkout v0.4.0-m4`. Backend on `:8003`, frontend on `:3000`.

## Pre-flight

- [ ] `cd backend && .venv/Scripts/pytest -v` → **177 passed** (142 baseline + 35 new in M4)
- [ ] `cd frontend && rm -rf .next && npm run build` → clean compile, all 4 routes
- [ ] Backend `.env` has: `OPENROUTER_MODEL=deepseek/deepseek-chat-v3.1`, `MEMORY_REFLECTION_INTERVAL=5`, `OPENROUTER_API_KEY=…`

## Feature A — HIL PermissionModal

1. [ ] Open browser → http://localhost:3000, start a session
2. [ ] Send a prompt that triggers `terminal` with a Tier-2 command, e.g.:
       _"用 terminal 删除 /tmp/foo.txt（如果存在）"_
3. [ ] **Within ~1s a modal appears** showing the proposed `rm /tmp/foo.txt` command + 3 buttons (Allow Once / Allow Always / Deny — copper, neutral, red respectively)
4. [ ] Click **Allow Once** → modal closes, tool executes, agent continues with the result
5. [ ] Send another `rm` command → click **Deny** → tool returns `"User denied permission"`, agent acknowledges
6. [ ] Send `rm -rf /` → blocked by absolute Tier-1 BLACKLIST (no modal at all, agent gets immediate error)
7. [ ] Modal timeout: send a `rm` and wait 60s without clicking → modal auto-closes, tool returns deny

## Feature B — Periodic memory reflection

1. [ ] Start a fresh session, chat 5 turns of substantive content (not just "hi")
2. [ ] On the 5th turn, watch the agent's response — it should mention reviewing/reflecting on what should be saved (look for `write_memory` tool calls in the trace)
3. [ ] Open Memory page → MEMORY.md should have new entries the agent decided to record
4. [ ] Continue to turn 10 — reflection fires again
5. [ ] Set `MEMORY_REFLECTION_INTERVAL=0` in `.env` (after restart) → reflection should NOT fire on any turn

## Feature C — AI Optimize MEMORY

1. [ ] In Memory page, MEMORY.md card is selected
2. [ ] Manually edit the textarea to add ~10 entries with intentional duplication and inconsistent formatting
3. [ ] Click **Save** to persist
4. [ ] Click **AI Optimize** → confirm dialog appears → confirm
5. [ ] Spinner ~5–15s; on success the textarea is replaced with structured `## section` + `- bullet` content
6. [ ] On disk: `sessions/{sid}/MEMORY.md.bak` exists with the OLD pre-optimize content
7. [ ] Click **Reset** → reverts to current saved (post-optimize) version (Reset is unrelated to AI Optimize backup)
8. [ ] Manually copy `MEMORY.md.bak` over `MEMORY.md` to restore old content if desired

## Feature D — Model switcher + Token indicator

1. [ ] Header shows a model dropdown left of the theme toggle: 4 options (DeepSeek v3.1 default, DeepSeek Chat, Qwen 2.5 72B, GLM-4.6)
2. [ ] Send a message with default DeepSeek → token bar below chat updates with input/output counts
3. [ ] Switch dropdown to Qwen 2.5 72B → send another message → response should use Qwen
4. [ ] Token indicator updates per chunk; resets to 0 on `+New session`
5. [ ] **Known limitation (Bundle 3 polish):** for tool-using turns the token bar shows the LAST LLM call's tokens, not cumulative across all calls in that turn. Tracked in `docs/M4-polish-backlog.md`.

## Feature E — HQS Session diagnostics

1. [ ] In Memory page, switch to Session History tab; pick a session with ≥ 3 turns
2. [ ] Top of view shows `HQSReportCard` with placeholder text "No diagnostic on file" + **Diagnose this session** button
3. [ ] Click button → spinner; 5–15s later the card displays:
       - Score ring (0-3 red, 4-6 orange, 7-10 green) with the numeric score
       - Failure-mode badges (subset of: goal_loss / boundary_break / context_loss / capability_gap / hybrid)
       - Analysis paragraph
       - Numbered fix-suggestions list
4. [ ] Click 🔄 to re-run diagnose → fresh result overwrites old; `sessions/{sid}/diagnostics.json` on disk reflects latest
5. [ ] Switch to a different session → card reflects that session's diagnostic (or "no diagnostic" state)

## Cross-feature regressions to watch

- [ ] M2 `skill_generated` event still fires when ≥3 tools used in a turn
- [ ] M3 `skill_enhancement_started/finished/enhanced` events still fire when an existing skill is loaded + reused
- [ ] Markdown rendering in chat (assistant messages) still works
- [ ] Session switch preserves chat history correctly (no message dropping)
- [ ] EvolutionLog (right panel of Skills page) still shows version cards

## Known limitations

- HIL only on `terminal` tool — `write_file`/`python_repl` are not yet gated. M5 candidate.
- Reflection fires per-turn-counter; if user opens many short sessions, each restarts the counter. Acceptable.
- AI Optimize: no preview before write — relies on `.bak` for revert. UI improvement candidate.
- Token indicator: see Feature D step 5 (post-merge polish item).
- HQSReportCard: 503 on LLM failure logs to console, no toast (polish item).
- `diagnostics.json` write is non-atomic; mid-write crash corrupts the file (polish item).

## What M5+ might add

- HIL extended to all destructive tools
- Streaming HQS analysis (case-09 used Vercel AI SDK streamObject)
- Memory diff/preview before AI Optimize commits
- Token cost in $ alongside token counts
- Session export (JSON / Markdown bundle of MEMORY + SKILL_SNAPSHOT + diagnostics)
