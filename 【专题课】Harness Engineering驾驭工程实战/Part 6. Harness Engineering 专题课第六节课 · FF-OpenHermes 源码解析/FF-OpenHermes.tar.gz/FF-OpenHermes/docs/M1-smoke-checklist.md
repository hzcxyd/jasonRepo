# M1 Smoke Checklist

Backend: `uvicorn app:app --port 8003`
Frontend: `npm run dev` (port 3000)

1. [ ] Create session A bound to `~/tmp/proj-a` — appears in dropdown
2. [ ] Send "create hello.txt" — file appears in workspace tree
3. [ ] Workspace tree auto-refreshes after `write_file`/`terminal` tool_end
4. [ ] `write_memory` updates MEMORY.md
5. [ ] Manually create skill `demo`, edit, load Level 1
6. [ ] Switch to session B (different workspace) — tree changes, skills empty
7. [ ] Restart backend — sessions persist; Memory > History shows past turns
8. [ ] Delete session A — `sessions/{sid}/` removed, but `~/tmp/proj-a` untouched
