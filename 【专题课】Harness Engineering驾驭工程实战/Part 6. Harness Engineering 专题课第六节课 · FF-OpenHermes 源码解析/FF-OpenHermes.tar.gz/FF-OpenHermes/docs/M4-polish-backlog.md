# M4 Polish Backlog

> Non-blocking issues found during bundle reviews. Apply during Bundle 4 (Phase 6 smoke + tag) or after.

## From Bundle 1 (Phase A — HIL PermissionModal)

### Backend
- [ ] `backend/api/permission.py:18` — endpoint reads `reg._pending` (private). Add `PermissionRegistry.is_pending(request_id) -> bool` and use it.
- [ ] `backend/agent/permission_registry.py:23-27` — `register()` silently overwrites if same `request_id` reused, leaking the prior future. Raise `ValueError` on collision.
- [ ] `backend/agent/permission_registry.py:25` — `asyncio.get_event_loop()` deprecated in 3.12+. Switch to `asyncio.get_running_loop().create_future()`.
- [ ] `backend/tools/terminal_tool.py:96-98, 121-123, 467-469` — same `get_event_loop()` deprecation in 3 places.
- [ ] `backend/tests/test_terminal_tool.py:71-102` — `test_async_run_hil_required_resolves_to_allow_runs_command` is degenerate: uses `echo` (Tier-3 SAFE, never triggers HIL). Plan-authored bug. Replace with real HIL command like `mv ./a ./b` and patch `docs/M4-plan.md` lines 281-311 to match.
- [ ] `backend/tests/test_terminal_tool.py:36-42` — duplicate imports of `asyncio`, `pytest`, `create_terminal_tool` (already at lines 5-7). Tidy.

### Frontend
- [ ] `frontend/src/components/chat/PermissionModal.tsx` — no focus trap, no Esc handler, no `role="dialog"` / `aria-modal`. Add for a11y.
- [ ] PermissionModal currently rendered inside ChatPanel's flex column. `fixed inset-0` works but consider hoisting to a top-level layout slot.

## From Bundle 2 (Phase B reflection + Phase C AI Optimize MEMORY)

### Backend
- [ ] `backend/agent/middleware.py:99` — `_reflection_interval=0` causes `ZeroDivisionError` at `n % self._reflection_interval`. `.env.example` claims "Set to 0 to disable" but code doesn't guard. Add `if self._reflection_interval <= 0: return None` or update env comment.
- [ ] `backend/agent/memory_optimizer.py:54` — uses `method="function_calling"`. If real-LLM 503s appear, drop the kwarg and let LangChain pick. Validate during smoke.
- [ ] `backend/api/memory.py:71` — empty MEMORY.md still gets sent to LLM. Add early return: `if current.strip() == "": return {"ok": True, "no_change": True}`.
- [ ] `backend/agent/memory_optimizer.py:58` — replace `logger.warning(... traceback.format_exc())` with `logger.exception(...)`.
- [ ] Reflection prompt size: ~280 chars, slightly over the "~200 char" cap in M4-plan risk section. Trim if pruning prompt budget.

### Frontend
- [ ] `frontend/src/components/memory/SoulMemoryEditor.tsx:51` — Reset and Save buttons remain enabled while `optimizing=true`; clicks can race the POST. Add `disabled={!dirty || optimizing}` to both.
- [ ] `frontend/src/components/memory/SoulMemoryEditor.tsx:69` — `window.confirm` is unstyled and blocking. Replace with project-styled confirm dialog when there's bandwidth.

## From Bundle 3 (Phase D model switcher + Phase E HQS diagnostics)

### Backend
- [ ] `backend/agent/agent_manager.py:106-113` + `frontend/src/stores/chatStore.ts:43-45` — token `usage` emits ONCE per LLM call; tool-using turns have ≥2 LLM calls, so frontend `setUsage` overwrite shows only the LAST call's tokens (not cumulative turn cost). Either accumulate backend-side before emitting (preferred — single emit per turn), or accumulate frontend-side and reset on a new `turn_start` event.
- [ ] `backend/api/diagnostics.py:34-37` — `write_text` is not atomic. If process crashes mid-write, `diagnostics.json` corrupts and GET returns 500. Use temp+rename pattern.
- [ ] `backend/api/diagnostics.py:24` — empty session returns 400; 422 (Unprocessable Entity) is more REST-idiomatic. Cosmetic.
- [ ] `backend/agent/diagnostics.py:64-79` — single LLM attempt. Add retry-once on `ValidationError` (matches M2 generator + M3 enhancer pattern).

### Frontend
- [ ] `frontend/src/stores/memoryStore.ts:55-65` — `runDiagnose` swallows 503 to `console.error`; user sees no feedback. Surface error in UI.
