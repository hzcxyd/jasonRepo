# FF-OpenHermes M2 Implementation Plan — Skill 自主生成

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add the M2 milestone — after a complex turn (≥3 tool calls + no skill loaded), the Agent asynchronously evaluates whether the experience is reusable, and if so, generates a structured `SKILL.md` + `HISTORY.md` and notifies the frontend via a persistent side-channel SSE stream.

**Architecture:** A new `SkillEngineMiddleware` hooks into LangChain 1.x `create_agent`'s `after_agent` lifecycle. On trigger, it spawns a non-blocking `asyncio.create_task` that calls a generator (Pydantic-structured second LLM call), runs lint, and writes via the existing `SkillOps.write_skill`. A new in-memory `EventBus` decouples late-arriving events from the chat SSE (which closes at `turn_end`); the frontend subscribes to `/api/events/{sid}/stream` for the lifetime of the active session.

**Tech Stack:**
- Backend additions: `langchain.agents.middleware.AgentMiddleware`, Pydantic v2 `with_structured_output(method="function_calling")`, `asyncio.Queue` event bus, `sse-starlette` (already installed).
- Frontend additions: a second `useEventStream` hook (persistent SSE, distinct from chat SSE), `SkillEventCard` component, `eventStore` Zustand slice for tracking unread events.
- LLM: same `OPENROUTER_MODEL=deepseek/deepseek-chat-v3.1` as M1 (no new provider).
- **No new dependencies** — everything reuses the M1 dependency set verified during Phase 0 of M1.

**Project root:** `E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes/`

**M1 prerequisites verified before starting M2:**
- 73 backend pytest pass deterministically
- `frontend/npm run build` clean
- `langchain.agents.create_agent` accepts `system_prompt=` and `middleware=[]` kwargs (M1 Phase 4 verified)
- `SkillOps.write_skill(name, content, history_line)` is the single entry-point for SKILL.md + HISTORY.md + snapshot rebuild (M1 Phase 2.4)
- `SessionManager.update_stats(sid, **delta)` increments arbitrary keys in `SessionMeta.stats` (M1 Phase 1.3)
- `SessionMeta.stats.skills_generated: int = 0` field exists (M1 Phase 1.2 model)
- Frontend `useSseStream` parses CRLF (`\r?\n\r?\n`) — reuse the same parsing approach in `useEventStream`

**Compatibility guardrails (do not violate):**
1. **Don't modify `ChatMessage.tsx`** — its react-markdown renderer must stay untouched. `SkillEventCard` is a *separate* component rendered after messages, not inside them.
2. **Don't modify `extract_turns`** — history replay should not surface skill_generated events. Side-channel events are ephemeral by design (live-only, but persisted via `stats.skills_generated` counter for unread tracking).
3. **Don't modify `useSseStream`** — chat SSE remains as-is. New events flow through the new `useEventStream` hook.
4. **Don't change existing `/api/skills/*` endpoints** — M2 only writes via `SkillOps`, doesn't add a new write API. Manual skill creation still uses `POST /api/sessions/{sid}/skills`.
5. **All 73 existing pytest must continue passing.** M2 adds 12-15 new tests; final count ≥ 85.
6. **Workspace tree auto-refresh on `tool_end`** — M2 doesn't touch this. The new SSE channel only carries skill events; tool events stay on the chat SSE.

**Plan defects from M1 to AVOID:**
- LangChain `create_agent` uses `system_prompt=` not `prompt=`
- `FakeListChatModel.bind_tools` raises NotImplementedError → use `ToolBindableFakeListChatModel` subclass (already defined in `tests/test_agent_manager.py`; reuse it)
- `AsyncSqliteSaver.aput` test fixture needs `cfg["configurable"]["checkpoint_ns"] = ""`
- Pydantic v2 syntax: `field_validator`, `model_dump_json`, `model_validate_json`, `Field(default_factory=...)`
- Datetime: `timespec="microseconds"` (Windows clock granularity)
- TypeScript ternary: `(cond ? "x" : "y") as Type` to avoid precedence mishap
- Next.js + ESLint strict: no unused imports/vars (build fails immediately)

---

## Plan Overview · 7 Phases

| Phase | Topic | Tasks |
|---|---|---|
| 0 | Scaffolding (skill_engine/ dir, baseline test pass) | 0.1 |
| 1 | Pydantic schemas + lint (port case-07) | 1.1 – 1.2 |
| 2 | Skill generator (LLM call + name conflict + persistence) | 2.1 – 2.2 |
| 3 | Event bus + SkillEngineMiddleware + AgentManager wiring | 3.1 – 3.3 |
| 4 | `/api/events/{sid}/stream` SSE endpoint | 4.1 |
| 5 | Frontend: useEventStream + SkillEventCard + NavSidebar red dot | 5.1 – 5.4 |
| 6 | E2E smoke + M2 release tag | 6.1 – 6.2 |

**Estimated scope**: ~17 tasks across 7 phases · ~12-15 new pytest · 1 manual smoke pass.

**Key risk being directly addressed**:
- `with_structured_output` reliability with deepseek → wrapped in retry-once + Pydantic re-validation in Task 2.1.
- Async lifecycle of late events vs closed SSE → resolved by side-channel `/api/events/{sid}/stream` in Phase 4 (independent persistent connection).

---

## Phase 0 — Scaffolding

### Task 0.1: Create skill_engine/ package + verify M1 baseline still green

**Files:**
- Create: `FF-OpenHermes/backend/skill_engine/__init__.py`

- [ ] **Step 1: Create the package directory + empty init**

```bash
mkdir -p "E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes/backend/skill_engine"
touch "E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes/backend/skill_engine/__init__.py"
```

- [ ] **Step 2: Confirm M1 baseline tests still pass**

```bash
cd "E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes/backend"
.venv/Scripts/pytest -v
```

Expected: 73 passed. If anything fails, **STOP and report BLOCKED** — do not start M2 on a non-green base.

- [ ] **Step 3: Commit**

```bash
git add backend/skill_engine/__init__.py
git commit -m "chore(backend): scaffold skill_engine package for M2"
```

---

## Phase 1 — Pydantic Schemas + Lint Rules

### Task 1.1: Pydantic schemas (port case-07's Zod schema)

**Files:**
- Create: `FF-OpenHermes/backend/skill_engine/schemas.py`
- Create: `FF-OpenHermes/backend/tests/test_skill_schemas.py`

The case-07 Zod schema has 3 layers (`signals[]` → `clusters{}` → `skill{}`). For the runtime generator we only need the final `skill` portion + a wrapper that lets the LLM say "NO_SKILL" when the turn isn't worth saving. We drop signals/clusters because they were UI choreography, not generator output.

- [ ] **Step 1: Write failing tests**

`backend/tests/test_skill_schemas.py`:

```python
"""Tests for Pydantic schemas used by the skill generator."""
import pytest
from pydantic import ValidationError

from skill_engine.schemas import GeneratedSkill, GeneratorOutput


def test_generated_skill_minimal_valid():
    s = GeneratedSkill(
        name="extract-web-table",
        description="Scrape HTML tables from web pages and export to Excel. Use when the user asks to scrape table or save webpage data.",
        body="# extract-web-table\n\n## Overview\n...",
        triggers=["scrape table", "extract table"],
    )
    assert s.name == "extract-web-table"
    assert len(s.triggers) == 2


def test_generated_skill_rejects_uppercase_name():
    with pytest.raises(ValidationError, match="kebab-case"):
        GeneratedSkill(
            name="ExtractTable",
            description="Long enough description that mentions when to use it.",
            body="# title\nhi",
            triggers=["x"],
        )


def test_generated_skill_rejects_empty_triggers():
    with pytest.raises(ValidationError):
        GeneratedSkill(
            name="x-skill",
            description="Long enough description that mentions when to use it.",
            body="# title",
            triggers=[],
        )


def test_generated_skill_rejects_long_name():
    with pytest.raises(ValidationError):
        GeneratedSkill(
            name="x" * 65,
            description="Long enough description that mentions when to use it.",
            body="# t",
            triggers=["a"],
        )


def test_generator_output_no_skill_branch():
    o = GeneratorOutput(decision="NO_SKILL", skill=None, reasoning="Task too trivial")
    assert o.decision == "NO_SKILL"
    assert o.skill is None


def test_generator_output_generate_branch_requires_skill():
    with pytest.raises(ValidationError, match="skill"):
        GeneratorOutput(decision="GENERATE", skill=None, reasoning="x")
```

- [ ] **Step 2: Run, expect FAIL**

```bash
cd "E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes/backend"
.venv/Scripts/pytest tests/test_skill_schemas.py -v
```

Expected: ImportError (module not found).

- [ ] **Step 3: Implement `skill_engine/schemas.py`**

```python
"""Pydantic schemas for the skill generator's structured LLM output."""
from typing import Literal

from pydantic import BaseModel, Field, field_validator, model_validator

NAME_RE = r"^[a-z][a-z0-9-]{1,63}$"


class GeneratedSkill(BaseModel):
    """The skill the generator decided to write. Mirrors SKILL.md frontmatter + body."""

    name: str = Field(
        ..., min_length=2, max_length=64,
        description="kebab-case identifier, must start with a lowercase letter",
    )
    description: str = Field(
        ..., min_length=20, max_length=1024,
        description="Two-focus description: what + when to use. Single line preferred.",
    )
    body: str = Field(
        ..., min_length=20, max_length=10_000,
        description="Markdown body with H1 heading and Overview / Steps / Edge Cases sections.",
    )
    triggers: list[str] = Field(
        ..., min_length=1, max_length=8,
        description="Short keywords or phrases that hint when this skill applies.",
    )

    @field_validator("name")
    @classmethod
    def _kebab_case(cls, v: str) -> str:
        import re
        if not re.fullmatch(NAME_RE, v):
            raise ValueError("name must be kebab-case (lowercase a-z, digits, '-'), starting with a letter")
        return v

    @field_validator("body")
    @classmethod
    def _has_h1(cls, v: str) -> str:
        if not any(line.startswith("# ") for line in v.splitlines()):
            raise ValueError("body must contain an H1 heading (# title)")
        return v


class GeneratorOutput(BaseModel):
    """Top-level generator response. Either GENERATE+skill or NO_SKILL."""

    decision: Literal["GENERATE", "NO_SKILL"]
    skill: GeneratedSkill | None = None
    reasoning: str = Field(
        ..., min_length=1, max_length=500,
        description="One-sentence justification for the decision (helps debug bad outputs).",
    )

    @model_validator(mode="after")
    def _consistency(self) -> "GeneratorOutput":
        if self.decision == "GENERATE" and self.skill is None:
            raise ValueError("decision=GENERATE requires skill to be present")
        if self.decision == "NO_SKILL" and self.skill is not None:
            raise ValueError("decision=NO_SKILL must not include a skill")
        return self
```

- [ ] **Step 4: Run, expect 6 PASS**

```bash
.venv/Scripts/pytest tests/test_skill_schemas.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/skill_engine/schemas.py backend/tests/test_skill_schemas.py
git commit -m "feat(backend): Pydantic schemas for skill generator (GeneratedSkill + GeneratorOutput)"
```

---

### Task 1.2: Lint rules

**Files:**
- Create: `FF-OpenHermes/backend/skill_engine/lint.py`
- Create: `FF-OpenHermes/backend/tests/test_skill_lint.py`

This ports case-07's `lint-rules.ts` to Python. It enforces beyond-Pydantic semantic rules (reserved names, double-focus description, body hygiene). Pydantic schemas already enforce hard constraints; lint catches softer issues that should warn or error after the fact.

- [ ] **Step 1: Write failing tests**

`backend/tests/test_skill_lint.py`:

```python
"""Tests for skill lint rules."""
import pytest

from skill_engine.lint import lint_skill, LintLevel, LintItem
from skill_engine.schemas import GeneratedSkill


def _mk(**overrides) -> GeneratedSkill:
    base = dict(
        name="my-skill",
        description="Does something specific. Use when the user asks for that thing.",
        body="# my-skill\n\n## Overview\nbla.",
        triggers=["something"],
    )
    base.update(overrides)
    return GeneratedSkill(**base)


def test_clean_skill_returns_no_errors():
    items = lint_skill(_mk())
    assert all(it.level != "error" for it in items)


def test_reserved_name_errors():
    items = lint_skill(_mk(name="claude"))
    rules = {it.rule for it in items if it.level == "error"}
    assert "name-reserved" in rules


def test_short_name_warns():
    items = lint_skill(_mk(name="ab"))
    rules = {it.rule for it in items}
    assert "name-too-short" in rules


def test_description_missing_when_warns():
    items = lint_skill(_mk(description="Does something cool. " * 4))
    rules = {it.rule for it in items}
    assert "desc-missing-when" in rules


def test_description_multiline_warns():
    items = lint_skill(_mk(description="line one. Use when needed.\nline two."))
    rules = {it.rule for it in items}
    assert "desc-multiline" in rules


def test_body_too_long_warns():
    long_body = "# t\n" + ("x\n" * 600)
    items = lint_skill(_mk(body=long_body))
    rules = {it.rule for it in items}
    assert "body-too-long" in rules


def test_has_errors_helper():
    from skill_engine.lint import has_errors
    assert has_errors([LintItem(field="name", level="error", rule="x", message="x")])
    assert not has_errors([LintItem(field="name", level="warn", rule="x", message="x")])
    assert not has_errors([])
```

- [ ] **Step 2: Run, expect FAIL (ImportError)**

```bash
.venv/Scripts/pytest tests/test_skill_lint.py -v
```

- [ ] **Step 3: Implement `skill_engine/lint.py`**

```python
"""Lint rules for generator output. Run AFTER Pydantic schema validation passes."""
import re
from dataclasses import dataclass
from typing import Literal

from skill_engine.schemas import GeneratedSkill

LintLevel = Literal["ok", "warn", "error"]
RESERVED_WORDS = {"anthropic", "claude", "openai", "skill", "agent", "hermes", "gpt"}


@dataclass
class LintItem:
    field: Literal["name", "description", "body"]
    level: LintLevel
    rule: str
    message: str


def lint_skill(skill: GeneratedSkill) -> list[LintItem]:
    """Return list of lint findings. Empty list = clean."""
    items: list[LintItem] = []

    # ── name ──────────────────────────────────────────────
    if skill.name.lower() in RESERVED_WORDS:
        items.append(LintItem("name", "error", "name-reserved",
                              f'name cannot be a reserved word "{skill.name}"'))
    if len(skill.name) < 4:
        items.append(LintItem("name", "warn", "name-too-short",
                              "name is short; 4-30 chars improves discoverability"))

    # ── description ───────────────────────────────────────
    when_re = re.compile(
        r"(when|use when|适用|用于|何时|场景|trigger|触发|when to|用来|当)", re.IGNORECASE
    )
    if not when_re.search(skill.description):
        items.append(LintItem("description", "warn", "desc-missing-when",
                              'description lacks a "when to use" focus'))
    if "\n" in skill.description:
        items.append(LintItem("description", "warn", "desc-multiline",
                              "description should be single-line for YAML safety"))

    # ── body ──────────────────────────────────────────────
    line_count = skill.body.count("\n") + 1
    if line_count > 500:
        items.append(LintItem("body", "warn", "body-too-long",
                              f"body has {line_count} lines; consider splitting (>500 lines)"))

    return items


def has_errors(items: list[LintItem]) -> bool:
    """True if any item is an error (not just warn)."""
    return any(it.level == "error" for it in items)
```

- [ ] **Step 4: Run, expect 7 PASS**

```bash
.venv/Scripts/pytest tests/test_skill_lint.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/skill_engine/lint.py backend/tests/test_skill_lint.py
git commit -m "feat(backend): skill lint rules (reserved name, double-focus desc, body hygiene)"
```

---

## Phase 2 — Skill Generator

### Task 2.1: Generator core function

**Files:**
- Create: `FF-OpenHermes/backend/skill_engine/generator.py`
- Create: `FF-OpenHermes/backend/tests/test_skill_generator.py`

The generator takes the chat turn's messages + a session_dir, runs a structured LLM call, validates with Pydantic, runs lint, resolves name conflicts, and writes via `SkillOps.write_skill`. Failures are caught and logged but don't propagate (background task safety).

- [ ] **Step 1: Write failing tests**

`backend/tests/test_skill_generator.py`:

```python
"""Tests for the skill generator end-to-end (with FakeListChatModel)."""
import json
from pathlib import Path

import pytest
from langchain_core.language_models.fake_chat_models import FakeListChatModel
from langchain_core.messages import HumanMessage, AIMessage, ToolMessage

from skill_engine.generator import generate_skill_from_turn
from agent.skill_ops import SkillOps


class StructuredFake(FakeListChatModel):
    """Fake model that returns its preset string AS-IF it were the structured output's JSON.

    LangChain's `with_structured_output` normally parses tool_call JSON. We bypass
    that by overriding `bind_tools` (no-op) and feeding the JSON string straight as
    AIMessage content; then `with_structured_output(method='function_calling')` will
    fall back to JSON-mode parsing.

    For this test we'll just stub `with_structured_output` itself to return a callable
    that yields a preset GeneratorOutput-shaped dict.
    """

    structured_response: dict | Exception | None = None

    def with_structured_output(self, schema, **kwargs):  # type: ignore[override]
        outer = self

        class StructuredRunnable:
            async def ainvoke(self, prompt):
                if isinstance(outer.structured_response, Exception):
                    raise outer.structured_response
                return schema.model_validate(outer.structured_response)

        return StructuredRunnable()

    def bind_tools(self, tools, **kwargs):  # avoid NotImplementedError when used elsewhere
        return self


@pytest.fixture
def session_dir(tmp_path: Path) -> Path:
    sd = tmp_path / "sess"
    (sd / "skills").mkdir(parents=True)
    (sd / "skills" / "SKILLS_SNAPSHOT.md").write_text("# Skills Snapshot\n", encoding="utf-8")
    (sd / "loaded_skills.json").write_text("[]", encoding="utf-8")
    return sd


def _sample_turn_messages() -> list:
    return [
        HumanMessage(content="抓取 example.com 的价格表并导出 Excel"),
        AIMessage(content="我来抓取页面", tool_calls=[
            {"id": "tc1", "name": "fetch_url", "args": {"url": "https://example.com"}},
        ]),
        ToolMessage(content="<html>...</html>", tool_call_id="tc1"),
        AIMessage(content="解析表格", tool_calls=[
            {"id": "tc2", "name": "python_repl", "args": {"code": "..."}},
        ]),
        ToolMessage(content="parsed 24 rows", tool_call_id="tc2"),
        AIMessage(content="写入 Excel", tool_calls=[
            {"id": "tc3", "name": "write_file", "args": {"file_path": "prices.xlsx"}},
        ]),
        ToolMessage(content="wrote prices.xlsx", tool_call_id="tc3"),
        AIMessage(content="已导出 24 行价格表到 prices.xlsx"),
    ]


@pytest.mark.asyncio
async def test_generator_writes_skill_when_decision_is_generate(session_dir: Path):
    fake = StructuredFake(responses=[])
    fake.structured_response = {
        "decision": "GENERATE",
        "reasoning": "Reusable workflow for table scraping",
        "skill": {
            "name": "extract-web-table",
            "description": "Scrape HTML tables from web pages and export to Excel. Use when the user asks for table data extraction.",
            "body": "# extract-web-table\n\n## Overview\nFetch HTML, parse table, write xlsx.",
            "triggers": ["scrape table", "export to excel"],
        },
    }

    result = await generate_skill_from_turn(
        messages=_sample_turn_messages(),
        session_dir=session_dir,
        llm_factory=lambda: fake,
    )

    assert result is not None
    assert result["name"] == "extract-web-table"
    skill_md = (session_dir / "skills" / "extract-web-table" / "SKILL.md").read_text(encoding="utf-8")
    assert "extract-web-table" in skill_md
    history = (session_dir / "skills" / "extract-web-table" / "HISTORY.md").read_text(encoding="utf-8")
    assert "v1.0" in history or "Auto-Generated" in history


@pytest.mark.asyncio
async def test_generator_skips_when_decision_is_no_skill(session_dir: Path):
    fake = StructuredFake(responses=[])
    fake.structured_response = {
        "decision": "NO_SKILL",
        "skill": None,
        "reasoning": "Task too trivial",
    }
    result = await generate_skill_from_turn(
        messages=_sample_turn_messages(),
        session_dir=session_dir,
        llm_factory=lambda: fake,
    )
    assert result is None
    # No skills directory created
    skills = list((session_dir / "skills").iterdir())
    skill_dirs = [p for p in skills if p.is_dir()]
    assert skill_dirs == []


@pytest.mark.asyncio
async def test_generator_resolves_name_conflict_with_suffix(session_dir: Path):
    # Pre-create a skill with the same name
    ops = SkillOps(session_dir)
    ops.write_skill(
        "extract-web-table",
        "---\nname: extract-web-table\ndescription: Existing skill. Use when always.\nversion: 1.0\n---\n\n# extract-web-table\nold body",
    )

    fake = StructuredFake(responses=[])
    fake.structured_response = {
        "decision": "GENERATE",
        "reasoning": "New variation",
        "skill": {
            "name": "extract-web-table",
            "description": "Scrape HTML tables. Use when the user asks for table data.",
            "body": "# extract-web-table\n\nbody",
            "triggers": ["scrape"],
        },
    }
    result = await generate_skill_from_turn(
        messages=_sample_turn_messages(),
        session_dir=session_dir,
        llm_factory=lambda: fake,
    )
    assert result is not None
    assert result["name"] != "extract-web-table"
    assert result["name"].startswith("extract-web-table")
    # Both directories exist
    assert (session_dir / "skills" / "extract-web-table").is_dir()
    assert (session_dir / "skills" / result["name"]).is_dir()


@pytest.mark.asyncio
async def test_generator_returns_none_on_llm_exception(session_dir: Path, caplog):
    fake = StructuredFake(responses=[])
    fake.structured_response = RuntimeError("LLM upstream blew up")

    result = await generate_skill_from_turn(
        messages=_sample_turn_messages(),
        session_dir=session_dir,
        llm_factory=lambda: fake,
    )
    assert result is None  # silent failure, no propagation


@pytest.mark.asyncio
async def test_generator_returns_none_on_lint_error(session_dir: Path):
    fake = StructuredFake(responses=[])
    fake.structured_response = {
        "decision": "GENERATE",
        "reasoning": "ok",
        "skill": {
            "name": "claude",  # reserved → lint error
            "description": "Does stuff. Use when needed.",
            "body": "# claude\nbody",
            "triggers": ["x"],
        },
    }
    result = await generate_skill_from_turn(
        messages=_sample_turn_messages(),
        session_dir=session_dir,
        llm_factory=lambda: fake,
    )
    assert result is None
```

- [ ] **Step 2: Run, expect FAIL (ImportError)**

```bash
.venv/Scripts/pytest tests/test_skill_generator.py -v
```

- [ ] **Step 3: Implement `skill_engine/generator.py`**

```python
"""Skill generator — second LLM call that emits a structured SKILL.md from a turn."""
import logging
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, ToolMessage
from pydantic import ValidationError

from agent.skill_ops import SkillOps
from skill_engine.lint import lint_skill, has_errors
from skill_engine.schemas import GeneratedSkill, GeneratorOutput

logger = logging.getLogger("skill_engine.generator")

GENERATOR_SYSTEM_PROMPT = """You are evaluating an Agent's just-completed task and deciding whether the workflow is reusable enough to save as a "skill" for future tasks.

A skill is a structured Markdown document (SKILL.md) that captures:
- The trigger conditions (when to use this)
- The step-by-step procedure
- Edge cases and pitfalls

You MUST output structured JSON matching the GeneratorOutput schema. The schema requires:
- `decision`: either "GENERATE" (the task is worth saving) or "NO_SKILL" (too trivial / one-off / unreproducible)
- `reasoning`: one sentence explaining your decision
- `skill`: required when decision=GENERATE; null otherwise

When you choose GENERATE, the `skill` object must satisfy:
- `name`: kebab-case (lowercase + digits + dashes), 4-30 chars ideally
- `description`: one line, MUST mention "use when..." or similar phrasing
- `body`: Markdown with H1 + Overview + Steps + Edge Cases sections
- `triggers`: 1-8 short keyword phrases

Output NO_SKILL if:
- The task involved fewer than 3 meaningful tool calls
- The task is highly user-specific and not generalizable
- The output of the task did not succeed
"""


def _format_turn_for_generator(messages: list[BaseMessage]) -> str:
    """Render the turn as plain text for the generator prompt."""
    lines: list[str] = []
    for m in messages:
        role = getattr(m, "type", None)
        content = (getattr(m, "content", "") or "").strip()
        if role == "human":
            lines.append(f"USER: {content}")
        elif role == "ai":
            tcs = getattr(m, "tool_calls", []) or []
            if content:
                lines.append(f"ASSISTANT: {content}")
            for tc in tcs:
                lines.append(f"  TOOL_CALL: {tc.get('name')}({tc.get('args', {})})")
        elif role == "tool":
            short = content[:300] + ("…" if len(content) > 300 else "")
            lines.append(f"  TOOL_RESULT: {short}")
    return "\n".join(lines)


def _resolve_name_conflict(desired: str, ops: SkillOps) -> str:
    """If desired name already exists, append numeric suffix until free."""
    existing = {s["name"] for s in ops.list_skills()}
    if desired not in existing:
        return desired
    i = 2
    while f"{desired}-v{i}" in existing:
        i += 1
    return f"{desired}-v{i}"


async def _invoke_with_retry(structured_runnable, prompt: str, retries: int = 1) -> GeneratorOutput | None:
    """Call the structured runnable; retry once on Pydantic ValidationError; return None on persistent fail."""
    last_err: Exception | None = None
    for attempt in range(retries + 1):
        try:
            result = await structured_runnable.ainvoke(prompt)
            if isinstance(result, GeneratorOutput):
                return result
            # Some LangChain versions return dict; coerce
            return GeneratorOutput.model_validate(result)
        except ValidationError as e:
            last_err = e
            logger.warning("generator output failed Pydantic validation (attempt %d): %s", attempt + 1, e)
        except Exception as e:
            last_err = e
            logger.warning("generator LLM call failed (attempt %d): %s", attempt + 1, e)
            break  # non-validation errors aren't retried
    if last_err:
        logger.warning("generator gave up after retries: %s", last_err)
    return None


async def generate_skill_from_turn(
    messages: list[BaseMessage],
    session_dir: Path,
    llm_factory: Callable[[], BaseChatModel],
) -> dict[str, Any] | None:
    """Top-level generator. Returns {name, description} on success, None on skip/failure.

    Failures are logged and swallowed — never raised — so this is safe to call from
    a background asyncio task. The intent is best-effort enrichment.
    """
    try:
        llm = llm_factory()
        structured = llm.with_structured_output(GeneratorOutput, method="function_calling")
        prompt = (
            GENERATOR_SYSTEM_PROMPT
            + "\n\n--- BEGIN TURN ---\n"
            + _format_turn_for_generator(messages)
            + "\n--- END TURN ---\n\nProvide your decision now."
        )
        out = await _invoke_with_retry(structured, prompt, retries=1)
        if out is None:
            return None
        if out.decision != "GENERATE" or out.skill is None:
            logger.info("generator decided NO_SKILL: %s", out.reasoning)
            return None

        skill = out.skill

        # Lint after Pydantic
        lint_findings = lint_skill(skill)
        if has_errors(lint_findings):
            err_summary = "; ".join(f"{it.rule}: {it.message}" for it in lint_findings if it.level == "error")
            logger.warning("generator output failed lint: %s", err_summary)
            return None

        # Resolve name conflicts
        ops = SkillOps(session_dir)
        final_name = _resolve_name_conflict(skill.name, ops)

        # Format SKILL.md content with frontmatter
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S+00:00")
        triggers_yaml = ", ".join(f'"{t}"' for t in skill.triggers)
        skill_md = (
            "---\n"
            f"name: {final_name}\n"
            f'description: "{skill.description}"\n'
            "version: 1.0\n"
            "generated_by: agent\n"
            f"created_at: {ts}\n"
            f"triggers: [{triggers_yaml}]\n"
            "---\n\n"
            + skill.body
        )

        history_line = f"v1.0 · 🤖 Auto-Generated by skill engine (reasoning: {out.reasoning[:120]})"
        ops.write_skill(final_name, skill_md, history_line=history_line)

        return {"name": final_name, "description": skill.description}

    except Exception as e:
        logger.error("generate_skill_from_turn unhandled error: %s\n%s", e, traceback.format_exc())
        return None
```

- [ ] **Step 4: Run, expect 5 PASS**

```bash
.venv/Scripts/pytest tests/test_skill_generator.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/skill_engine/generator.py backend/tests/test_skill_generator.py
git commit -m "feat(backend): skill generator with structured LLM output + lint + conflict resolution"
```

---

### Task 2.2: Detect "skill was used in this turn" helper

**Files:**
- Create: `FF-OpenHermes/backend/skill_engine/detect.py`
- Create: `FF-OpenHermes/backend/tests/test_skill_detect.py`

The middleware needs to know: did THIS turn already use an existing skill? If yes, M3 (enhancer) handles it, not M2. The signal is: `read_skill` tool was called.

- [ ] **Step 1: Write failing tests**

`backend/tests/test_skill_detect.py`:

```python
"""Tests for turn-content detection helpers."""
from langchain_core.messages import HumanMessage, AIMessage, ToolMessage

from skill_engine.detect import count_tool_calls_in_turn, used_existing_skill


def _t(*msgs):
    return list(msgs)


def test_count_tool_calls_zero_for_text_only():
    msgs = _t(
        HumanMessage(content="hi"),
        AIMessage(content="hello"),
    )
    assert count_tool_calls_in_turn(msgs) == 0


def test_count_tool_calls_counts_all():
    msgs = _t(
        HumanMessage(content="x"),
        AIMessage(content="step 1", tool_calls=[
            {"id": "1", "name": "terminal", "args": {}},
            {"id": "2", "name": "python_repl", "args": {}},
        ]),
        ToolMessage(content="r1", tool_call_id="1"),
        ToolMessage(content="r2", tool_call_id="2"),
        AIMessage(content="step 2", tool_calls=[
            {"id": "3", "name": "write_file", "args": {}},
        ]),
        ToolMessage(content="r3", tool_call_id="3"),
        AIMessage(content="done"),
    )
    assert count_tool_calls_in_turn(msgs) == 3


def test_used_existing_skill_detects_read_skill():
    msgs = _t(
        HumanMessage(content="x"),
        AIMessage(content="loading skill", tool_calls=[
            {"id": "1", "name": "read_skill", "args": {"name": "weather"}},
        ]),
        ToolMessage(content="...", tool_call_id="1"),
    )
    assert used_existing_skill(msgs) is True


def test_used_existing_skill_false_when_only_other_tools():
    msgs = _t(
        HumanMessage(content="x"),
        AIMessage(content="...", tool_calls=[
            {"id": "1", "name": "terminal", "args": {}},
        ]),
    )
    assert used_existing_skill(msgs) is False
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_skill_detect.py -v
```

- [ ] **Step 3: Implement `skill_engine/detect.py`**

```python
"""Helpers for inspecting a turn's messages — counts and tool-name detection."""
from typing import Iterable


def count_tool_calls_in_turn(messages: Iterable) -> int:
    """Count distinct tool calls (across all AIMessages in the turn)."""
    n = 0
    for m in messages:
        tcs = getattr(m, "tool_calls", []) or []
        n += len(tcs)
    return n


def used_existing_skill(messages: Iterable) -> bool:
    """True if any AIMessage in the turn called read_skill (i.e. loaded an existing skill).

    M2 (auto-generation) should SKIP turns that already used a skill — those go to
    M3 (auto-enhancement) instead.
    """
    for m in messages:
        for tc in getattr(m, "tool_calls", []) or []:
            if tc.get("name") == "read_skill":
                return True
    return False
```

- [ ] **Step 4: Run, expect 4 PASS**

```bash
.venv/Scripts/pytest tests/test_skill_detect.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/skill_engine/detect.py backend/tests/test_skill_detect.py
git commit -m "feat(backend): turn-inspection helpers (tool-call count + read_skill detection)"
```

---

## Phase 3 — Event Bus + Middleware + Integration

### Task 3.1: In-memory EventBus

**Files:**
- Create: `FF-OpenHermes/backend/agent/event_bus.py`
- Create: `FF-OpenHermes/backend/tests/test_event_bus.py`

The bus is a per-process singleton (lives on `app.state`) that decouples publishers (background tasks) from subscribers (SSE endpoints). Each session_id has zero or more subscriber queues. Bounded queue sizes prevent slow subscribers from leaking memory.

- [ ] **Step 1: Write failing tests**

`backend/tests/test_event_bus.py`:

```python
"""Tests for the per-process EventBus."""
import asyncio

import pytest

from agent.event_bus import EventBus


@pytest.mark.asyncio
async def test_publish_no_subscribers_is_noop():
    bus = EventBus()
    bus.publish("sess1", {"type": "x"})  # should not raise


@pytest.mark.asyncio
async def test_subscribe_receives_published_events():
    bus = EventBus()
    received: list[dict] = []

    async with bus.subscribe("sess1") as q:
        bus.publish("sess1", {"type": "skill_generated", "name": "foo"})
        bus.publish("sess1", {"type": "skill_generated", "name": "bar"})
        # consume both
        for _ in range(2):
            ev = await asyncio.wait_for(q.get(), timeout=1.0)
            received.append(ev)

    assert [e["name"] for e in received] == ["foo", "bar"]


@pytest.mark.asyncio
async def test_publish_to_other_session_not_received():
    bus = EventBus()
    async with bus.subscribe("sess1") as q:
        bus.publish("sess2", {"type": "skill_generated", "name": "other"})
        bus.publish("sess1", {"type": "skill_generated", "name": "mine"})
        ev = await asyncio.wait_for(q.get(), timeout=1.0)
        assert ev["name"] == "mine"
        # No more events queued
        assert q.empty()


@pytest.mark.asyncio
async def test_multiple_subscribers_same_session_each_get_event():
    bus = EventBus()
    async with bus.subscribe("sess1") as q1, bus.subscribe("sess1") as q2:
        bus.publish("sess1", {"type": "skill_generated", "name": "shared"})
        ev1 = await asyncio.wait_for(q1.get(), timeout=1.0)
        ev2 = await asyncio.wait_for(q2.get(), timeout=1.0)
        assert ev1["name"] == "shared"
        assert ev2["name"] == "shared"


@pytest.mark.asyncio
async def test_unsubscribe_on_context_exit():
    bus = EventBus()
    async with bus.subscribe("sess1") as q:
        pass
    # After exit, publish should not error and should have no subscribers
    bus.publish("sess1", {"type": "x"})
    # Internal state: no subscribers tracked for sess1
    assert "sess1" not in bus._subscribers or len(bus._subscribers["sess1"]) == 0
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_event_bus.py -v
```

- [ ] **Step 3: Implement `agent/event_bus.py`**

```python
"""In-memory pub/sub bus for late-arriving session events (skill generation, etc).

This decouples background tasks (e.g. SkillEngineMiddleware running after turn_end)
from frontend subscribers (SSE on /api/events/{sid}/stream). Lives on app.state.
"""
import asyncio
import logging
from contextlib import asynccontextmanager
from typing import AsyncIterator

logger = logging.getLogger("agent.event_bus")

QUEUE_MAX = 64  # per-subscriber buffer; drop on overflow


class EventBus:
    def __init__(self) -> None:
        self._subscribers: dict[str, set[asyncio.Queue]] = {}

    def publish(self, session_id: str, event: dict) -> None:
        """Fan out event to all subscribers of session_id. Non-blocking; drops on full queue."""
        subs = self._subscribers.get(session_id)
        if not subs:
            return
        for q in subs:
            try:
                q.put_nowait(event)
            except asyncio.QueueFull:
                logger.warning("event_bus dropped event for %s (subscriber queue full)", session_id)

    @asynccontextmanager
    async def subscribe(self, session_id: str) -> AsyncIterator[asyncio.Queue]:
        """Async context manager. Yields a Queue; events arrive via q.get(). Auto-unsubscribes on exit."""
        q: asyncio.Queue = asyncio.Queue(maxsize=QUEUE_MAX)
        self._subscribers.setdefault(session_id, set()).add(q)
        try:
            yield q
        finally:
            self._subscribers[session_id].discard(q)
            if not self._subscribers[session_id]:
                self._subscribers.pop(session_id, None)
```

- [ ] **Step 4: Run, expect 5 PASS**

```bash
.venv/Scripts/pytest tests/test_event_bus.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/agent/event_bus.py backend/tests/test_event_bus.py
git commit -m "feat(backend): in-memory EventBus for session-scoped late events"
```

---

### Task 3.2: SkillEngineMiddleware

**Files:**
- Create: `FF-OpenHermes/backend/agent/middleware.py`
- Create: `FF-OpenHermes/backend/tests/test_skill_middleware.py`

LangChain 1.x's `AgentMiddleware` provides `after_agent` hook. We override it to detect trigger conditions and spawn a background task. The middleware is constructed with all dependencies it needs (event_bus, llm_factory, session_manager, threshold).

- [ ] **Step 1: Write failing tests**

`backend/tests/test_skill_middleware.py`:

```python
"""Tests for SkillEngineMiddleware trigger logic."""
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest
from langchain_core.messages import HumanMessage, AIMessage, ToolMessage

from agent.middleware import SkillEngineMiddleware
from agent.event_bus import EventBus
from agent.session_manager import SessionManager


@pytest.fixture
def setup(tmp_path: Path):
    ws = tmp_path / "ws"
    ws.mkdir()
    sd = tmp_path / "sessions"
    td = tmp_path / "templates"
    td.mkdir()
    (td / "SOUL.md").write_text("# soul", encoding="utf-8")
    (td / "MEMORY.md").write_text("# mem", encoding="utf-8")
    sm = SessionManager(sessions_dir=sd, templates_dir=td)
    meta = sm.create("Test", str(ws), model="m")
    bus = EventBus()
    return sm, meta, bus


def _msgs_with_n_tools(n: int) -> list:
    msgs = [HumanMessage(content="x")]
    for i in range(n):
        msgs.append(AIMessage(content=f"step {i}", tool_calls=[
            {"id": f"tc{i}", "name": "terminal", "args": {}},
        ]))
        msgs.append(ToolMessage(content="ok", tool_call_id=f"tc{i}"))
    msgs.append(AIMessage(content="done"))
    return msgs


@pytest.mark.asyncio
async def test_middleware_does_not_trigger_below_threshold(setup, monkeypatch):
    sm, meta, bus = setup
    generate_mock = AsyncMock(return_value=None)
    monkeypatch.setattr("agent.middleware.generate_skill_from_turn", generate_mock)

    mw = SkillEngineMiddleware(
        session_manager=sm,
        event_bus=bus,
        llm_factory=lambda: MagicMock(),
        threshold=3,
    )
    # Synchronously trigger the inspection (the helper used by after_agent)
    await mw.run_for_session(meta.id, _msgs_with_n_tools(2))
    generate_mock.assert_not_called()


@pytest.mark.asyncio
async def test_middleware_does_not_trigger_when_skill_was_used(setup, monkeypatch):
    sm, meta, bus = setup
    generate_mock = AsyncMock(return_value=None)
    monkeypatch.setattr("agent.middleware.generate_skill_from_turn", generate_mock)

    mw = SkillEngineMiddleware(
        session_manager=sm,
        event_bus=bus,
        llm_factory=lambda: MagicMock(),
        threshold=3,
    )
    # 5 tool calls, but one of them is read_skill
    msgs = [
        HumanMessage(content="x"),
        AIMessage(content="loading", tool_calls=[
            {"id": "1", "name": "read_skill", "args": {"name": "weather"}},
        ]),
        ToolMessage(content="...", tool_call_id="1"),
        AIMessage(content="now do work", tool_calls=[
            {"id": "2", "name": "terminal", "args": {}},
            {"id": "3", "name": "terminal", "args": {}},
            {"id": "4", "name": "terminal", "args": {}},
            {"id": "5", "name": "terminal", "args": {}},
        ]),
    ]
    await mw.run_for_session(meta.id, msgs)
    generate_mock.assert_not_called()


@pytest.mark.asyncio
async def test_middleware_triggers_above_threshold_no_skill_used(setup, monkeypatch):
    sm, meta, bus = setup
    generate_mock = AsyncMock(return_value={"name": "demo", "description": "Demo skill"})
    monkeypatch.setattr("agent.middleware.generate_skill_from_turn", generate_mock)

    mw = SkillEngineMiddleware(
        session_manager=sm,
        event_bus=bus,
        llm_factory=lambda: MagicMock(),
        threshold=3,
    )
    await mw.run_for_session(meta.id, _msgs_with_n_tools(4))
    generate_mock.assert_called_once()


@pytest.mark.asyncio
async def test_middleware_publishes_event_and_updates_stats(setup, monkeypatch):
    sm, meta, bus = setup
    generate_mock = AsyncMock(return_value={"name": "demo", "description": "Demo skill"})
    monkeypatch.setattr("agent.middleware.generate_skill_from_turn", generate_mock)

    received: list[dict] = []

    async def consume():
        async with bus.subscribe(meta.id) as q:
            ev = await q.get()
            received.append(ev)

    import asyncio as _asyncio
    consumer_task = _asyncio.create_task(consume())
    await _asyncio.sleep(0.05)  # let subscribe register

    mw = SkillEngineMiddleware(
        session_manager=sm,
        event_bus=bus,
        llm_factory=lambda: MagicMock(),
        threshold=3,
    )
    await mw.run_for_session(meta.id, _msgs_with_n_tools(4))
    await _asyncio.wait_for(consumer_task, timeout=2.0)

    assert len(received) == 1
    assert received[0]["type"] == "skill_generated"
    assert received[0]["name"] == "demo"
    # Stats updated
    assert sm.get(meta.id).stats.skills_generated == 1
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_skill_middleware.py -v
```

- [ ] **Step 3: Implement `agent/middleware.py`**

```python
"""SkillEngineMiddleware — hooks `after_agent` and asynchronously generates skills."""
import asyncio
import logging
from typing import Any, Callable

from langchain.agents.middleware import AgentMiddleware
from langchain_core.language_models import BaseChatModel

from agent.event_bus import EventBus
from agent.session_manager import SessionManager
from skill_engine.detect import count_tool_calls_in_turn, used_existing_skill
from skill_engine.generator import generate_skill_from_turn

logger = logging.getLogger("agent.middleware")


class SkillEngineMiddleware(AgentMiddleware):
    """LangChain 1.x middleware: after each agent turn, decide whether to generate a skill.

    Trigger conditions:
        - tool_calls in this turn >= threshold
        - the turn did NOT call read_skill (already-used skill case is M3, not M2)
        - generator's LLM evaluation returns decision=GENERATE

    Failures are logged and NEVER propagate — running this is best-effort.
    """

    def __init__(
        self,
        session_manager: SessionManager,
        event_bus: EventBus,
        llm_factory: Callable[[], BaseChatModel],
        threshold: int = 3,
    ) -> None:
        super().__init__()
        self._sm = session_manager
        self._bus = event_bus
        self._llm_factory = llm_factory
        self._threshold = threshold

    # NOTE: LangGraph 1.x checks both sync (after_agent) and async (aafter_agent)
    # variants. When the agent runs via astream/ainvoke the async one is preferred.
    # Override both to be safe.
    async def aafter_agent(self, state: dict[str, Any], runtime: Any) -> None:  # type: ignore[override]
        """Async variant — preferred by LangGraph when agent runs async."""
        await self._dispatch(state)

    async def after_agent(self, state: dict[str, Any], runtime: Any) -> None:  # type: ignore[override]
        """Sync variant fallback. `runtime` is positional in LangGraph 1.x — no default."""
        await self._dispatch(state)

    async def _dispatch(self, state: dict[str, Any]) -> None:
        try:
            session_id = self._resolve_session_id(state)
            messages = state.get("messages", []) if isinstance(state, dict) else []
            if not session_id or not messages:
                return
            asyncio.create_task(self.run_for_session(session_id, messages))
        except Exception as e:
            logger.warning("after_agent dispatch failed: %s", e)

    def _resolve_session_id(self, state: dict[str, Any]) -> str | None:
        """Get thread_id from state (rare) or from active RunnableConfig (LangGraph 1.x default).

        IMPORTANT: in LangGraph 1.x the agent state is just {"messages": [...]} — `configurable`
        lives on the runtime config, NOT in state. We try state first (forward-compat) then
        fall back to `langgraph.config.get_config()` which fetches the config of the currently
        executing graph node.
        """
        # Path A — state-embedded (plan's original assumption; not seen in LangGraph 1.x)
        cfg = state.get("configurable", {}) if isinstance(state, dict) else {}
        sid = cfg.get("thread_id") if isinstance(cfg, dict) else None
        if sid:
            return sid
        # Path B — pull from active RunnableConfig
        try:
            from langgraph.config import get_config
            return get_config().get("configurable", {}).get("thread_id")
        except Exception:
            return None

    async def run_for_session(self, session_id: str, messages: list[Any]) -> None:
        """Public, awaitable equivalent — used by tests and by the create_task in after_agent."""
        try:
            tc_count = count_tool_calls_in_turn(messages)
            if tc_count < self._threshold:
                return
            if used_existing_skill(messages):
                logger.debug("session %s used existing skill; skipping generation (M3 will handle)", session_id)
                return

            try:
                meta = self._sm.get(session_id)
            except FileNotFoundError:
                logger.warning("session %s not found at after_agent time", session_id)
                return
            sdir = self._sm.session_dir(session_id)

            result = await generate_skill_from_turn(
                messages=messages,
                session_dir=sdir,
                llm_factory=self._llm_factory,
            )
            if result is None:
                return

            self._sm.update_stats(session_id, skills_generated=1)
            self._bus.publish(session_id, {
                "type": "skill_generated",
                "name": result["name"],
                "description": result["description"],
            })
            logger.info("session %s generated skill: %s", session_id, result["name"])

        except Exception as e:
            logger.error("run_for_session error: %s", e)
```

- [ ] **Step 4: Run, expect 4 PASS**

```bash
.venv/Scripts/pytest tests/test_skill_middleware.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/agent/middleware.py backend/tests/test_skill_middleware.py
git commit -m "feat(backend): SkillEngineMiddleware with after_agent trigger + async generation"
```

---

### Task 3.3: Wire middleware + EventBus into AgentManager + lifespan

**Files:**
- Modify: `FF-OpenHermes/backend/agent/agent_manager.py`
- Modify: `FF-OpenHermes/backend/app.py`
- Create: `FF-OpenHermes/backend/tests/test_agent_manager_m2.py`

The agent_manager builds a fresh agent each turn. We need to pass `middleware=[SkillEngineMiddleware(...)]` to `create_agent`, and the EventBus needs to live on `app.state` so both the middleware and the SSE endpoint can access it.

- [ ] **Step 1: Write failing test (verifies middleware is wired and triggers on real agent flow)**

`backend/tests/test_agent_manager_m2.py`:

```python
"""Verify AgentManager wires SkillEngineMiddleware and triggers it on multi-tool turns."""
import asyncio
from pathlib import Path
from unittest.mock import AsyncMock

import pytest
from langchain_core.language_models.fake_chat_models import FakeListChatModel

from agent.agent_manager import AgentManager
from agent.event_bus import EventBus
from agent.session_manager import SessionManager
from tests.test_agent_manager import setup as base_setup  # reuse fixture


class ToolBindableFake(FakeListChatModel):
    def bind_tools(self, tools, **kwargs):
        return self


@pytest.mark.asyncio
async def test_agent_manager_accepts_event_bus_and_middleware(tmp_path: Path):
    workspace = tmp_path / "ws"
    workspace.mkdir()
    sd = tmp_path / "sessions"
    td = tmp_path / "templates"
    td.mkdir()
    (td / "SOUL.md").write_text("# soul", encoding="utf-8")
    (td / "MEMORY.md").write_text("# mem", encoding="utf-8")
    sm = SessionManager(sessions_dir=sd, templates_dir=td)
    meta = sm.create("Test", str(workspace), model="fake")

    bus = EventBus()
    fake = ToolBindableFake(responses=["short reply"])
    mgr = AgentManager(
        session_manager=sm,
        llm_factory=lambda: fake,
        event_bus=bus,  # NEW M2 param
    )

    # Just iterate through and ensure no error.
    events = []
    async for ev in mgr.astream(meta.id, "hi"):
        events.append(ev)
    types = [e["type"] for e in events]
    assert "turn_start" in types
    assert "turn_end" in types
```

- [ ] **Step 2: Run, expect FAIL (constructor signature mismatch)**

```bash
.venv/Scripts/pytest tests/test_agent_manager_m2.py -v
```

- [ ] **Step 3: Modify `agent/agent_manager.py`** — add `event_bus` parameter and middleware

Replace the entire file content with:

```python
"""AgentManager — wraps LangChain create_agent + AsyncSqliteSaver per session.

M2 additions: optional EventBus + SkillEngineMiddleware for auto-generated skills.
"""
import uuid
from pathlib import Path
from typing import Any, AsyncGenerator, Callable

from langchain.agents import create_agent
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import HumanMessage
from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver

from agent.event_bus import EventBus
from agent.llm import build_llm
from agent.middleware import SkillEngineMiddleware
from agent.prompt_builder import build_system_prompt
from agent.session_manager import SessionManager
from config import settings
from tools import get_session_tools


class AgentManager:
    """Per-call agent builder. Each chat() builds a fresh agent so SOUL/MEMORY/SKILLS are re-read."""

    def __init__(
        self,
        session_manager: SessionManager,
        llm_factory: Callable[[], BaseChatModel] | None = None,
        event_bus: EventBus | None = None,
    ) -> None:
        self.sessions = session_manager
        self.llm_factory = llm_factory or build_llm
        self.event_bus = event_bus

    async def astream(self, session_id: str, user_message: str) -> AsyncGenerator[dict[str, Any], None]:
        """Stream agent events for a single user turn."""
        meta = self.sessions.get(session_id)
        sdir = self.sessions.session_dir(session_id)
        workspace = Path(meta.workspace_path)

        turn_id = uuid.uuid4().hex[:8]
        yield {"type": "turn_start", "turn_id": turn_id}

        system_prompt = build_system_prompt(sdir)
        tools = get_session_tools(session_dir=sdir, workspace=workspace)
        llm = self.llm_factory()

        # M2: build middleware list (only when event_bus provided)
        mw_list: list = []
        if self.event_bus is not None:
            mw_list.append(SkillEngineMiddleware(
                session_manager=self.sessions,
                event_bus=self.event_bus,
                llm_factory=self.llm_factory,
                threshold=settings.SKILL_GEN_THRESHOLD,
            ))

        full_text = ""
        tool_id_counter = 0

        db_path = sdir / "state.db"
        async with AsyncSqliteSaver.from_conn_string(str(db_path)) as cp:
            agent = create_agent(
                model=llm,
                tools=tools,
                system_prompt=system_prompt,
                checkpointer=cp,
                middleware=mw_list,
            )

            try:
                async for mode, data in agent.astream(
                    {"messages": [HumanMessage(content=user_message)]},
                    config={"configurable": {"thread_id": session_id}},
                    stream_mode=["messages", "updates"],
                ):
                    if mode == "messages":
                        msg, metadata = data
                        if hasattr(msg, "content") and msg.content and getattr(msg, "type", "") in ("AIMessageChunk", "ai"):
                            if not getattr(msg, "tool_calls", None):
                                full_text += msg.content
                                yield {"type": "assistant_token", "content": msg.content}

                    elif mode == "updates":
                        if not isinstance(data, dict):
                            continue
                        for node, payload in data.items():
                            if node == "model" and isinstance(payload, dict):
                                for m in payload.get("messages", []):
                                    for tc in getattr(m, "tool_calls", []) or []:
                                        tool_id_counter += 1
                                        yield {
                                            "type": "tool_start",
                                            "tool_call_id": tc.get("id", f"tc_{tool_id_counter}"),
                                            "name": tc.get("name"),
                                            "input": tc.get("args", {}),
                                        }
                            elif node == "tools" and isinstance(payload, dict):
                                for m in payload.get("messages", []):
                                    yield {
                                        "type": "tool_end",
                                        "tool_call_id": getattr(m, "tool_call_id", ""),
                                        "name": getattr(m, "name", ""),
                                        "output": str(getattr(m, "content", ""))[:5000],
                                        "is_error": False,
                                    }

            except Exception as e:
                yield {"type": "error", "code": "agent_error", "message": str(e)}

        yield {"type": "turn_end", "turn_id": turn_id, "full_response": full_text}
        self.sessions.update_stats(session_id, turns=1)
```

- [ ] **Step 4: Modify `app.py`** — instantiate EventBus and pass to AgentManager

Replace the lifespan function:

```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
    from agent.session_manager import SessionManager
    from agent.agent_manager import AgentManager
    from agent.event_bus import EventBus

    sm = SessionManager(sessions_dir=SESSIONS_DIR, templates_dir=TEMPLATES_DIR)
    bus = EventBus()
    app.state.session_manager = sm
    app.state.event_bus = bus
    app.state.agent_manager = AgentManager(session_manager=sm, event_bus=bus)
    print(f"FF-OpenHermes backend ready · sessions={SESSIONS_DIR}")
    yield
```

- [ ] **Step 5: Run all backend tests**

```bash
.venv/Scripts/pytest -v
```

Expected: 73 (M1) + 6 (1.1) + 7 (1.2) + 5 (2.1) + 4 (2.2) + 5 (3.1) + 4 (3.2) + 1 (3.3) = **105 passed**.

If `test_streaming_emits_token_and_done` from M1's `test_agent_manager.py` fails: the FakeListChatModel test now goes through middleware. Since `event_bus=None` is the default, middleware list is empty and behavior is unchanged. Test should still pass.

- [ ] **Step 6: Commit**

```bash
git add backend/agent/agent_manager.py backend/app.py backend/tests/test_agent_manager_m2.py
git commit -m "feat(backend): wire EventBus + SkillEngineMiddleware into AgentManager + lifespan"
```

---

## Phase 4 — Side-channel SSE: /api/events/{sid}/stream

### Task 4.1: Events SSE endpoint + integration

**Files:**
- Create: `FF-OpenHermes/backend/api/events.py`
- Modify: `FF-OpenHermes/backend/app.py` (register router)
- Create: `FF-OpenHermes/backend/tests/test_events_api.py`

A persistent SSE that subscribes to the EventBus for the active session. Frontend opens this once per session and keeps it open.

- [ ] **Step 1: Write failing test**

`backend/tests/test_events_api.py`:

```python
"""Tests for /api/events/{sid}/stream SSE side-channel."""
import asyncio
import json
from pathlib import Path

import pytest
from httpx import ASGITransport, AsyncClient

import app as app_module
from agent.event_bus import EventBus
from agent.session_manager import SessionManager


@pytest.mark.asyncio
async def test_events_stream_delivers_published_events(tmp_path: Path):
    ws = tmp_path / "ws"; ws.mkdir()
    sd = tmp_path / "sessions"
    td = tmp_path / "templates"; td.mkdir()
    (td / "SOUL.md").write_text("# s", encoding="utf-8")
    (td / "MEMORY.md").write_text("# m", encoding="utf-8")
    sm = SessionManager(sessions_dir=sd, templates_dir=td)
    bus = EventBus()
    app_module.app.state.session_manager = sm
    app_module.app.state.event_bus = bus
    meta = sm.create("Test", str(ws), model="m")

    received: list[str] = []

    async def consume_stream():
        async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test", timeout=5.0) as ac:
            async with ac.stream("GET", f"/api/events/{meta.id}/stream") as resp:
                assert resp.status_code == 200
                async for line in resp.aiter_lines():
                    received.append(line)
                    if line.startswith("event: skill_generated"):
                        return  # got it; close

    # Start consumer
    task = asyncio.create_task(consume_stream())
    # Give the consumer time to subscribe
    await asyncio.sleep(0.2)
    # Publish
    bus.publish(meta.id, {"type": "skill_generated", "name": "foo", "description": "bar"})
    # Wait for consumer
    try:
        await asyncio.wait_for(task, timeout=3.0)
    except asyncio.TimeoutError:
        pytest.fail(f"event not received in 3s. got: {received[:30]}")

    payload = "\n".join(received)
    assert "skill_generated" in payload
    assert '"name": "foo"' in payload or '"name":"foo"' in payload


@pytest.mark.asyncio
async def test_events_stream_404_unknown_session(tmp_path: Path):
    sd = tmp_path / "sessions"
    td = tmp_path / "templates"; td.mkdir()
    (td / "SOUL.md").write_text("# s", encoding="utf-8")
    (td / "MEMORY.md").write_text("# m", encoding="utf-8")
    sm = SessionManager(sessions_dir=sd, templates_dir=td)
    bus = EventBus()
    app_module.app.state.session_manager = sm
    app_module.app.state.event_bus = bus

    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        resp = await ac.get("/api/events/sess_nonexistent/stream")
    assert resp.status_code == 404
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_events_api.py -v
```

- [ ] **Step 3: Implement `api/events.py`**

```python
"""GET /api/events/{sid}/stream — persistent SSE side-channel for session events.

Carries late-arriving events that the chat SSE can't deliver because it closes
at turn_end (e.g. skill_generated, future skill_enhanced). Frontend opens one
of these per active session and keeps it open.
"""
import asyncio
import json
from typing import AsyncGenerator

from fastapi import APIRouter, HTTPException, Request
from sse_starlette.sse import EventSourceResponse

router = APIRouter()

KEEPALIVE_SECONDS = 20


@router.get("/events/{sid}/stream")
async def events_stream(sid: str, request: Request):
    sm = request.app.state.session_manager
    bus = request.app.state.event_bus
    try:
        sm.get(sid)
    except FileNotFoundError:
        raise HTTPException(404, "session not found")

    async def gen() -> AsyncGenerator[dict, None]:
        async with bus.subscribe(sid) as q:
            # Send a hello so the client knows the channel is up
            yield {"event": "ready", "data": json.dumps({"session_id": sid})}
            while True:
                if await request.is_disconnected():
                    return
                try:
                    ev = await asyncio.wait_for(q.get(), timeout=KEEPALIVE_SECONDS)
                except asyncio.TimeoutError:
                    # Keepalive ping (SSE comment line — sse-starlette emits properly)
                    yield {"event": "ping", "data": "{}"}
                    continue
                # IMPORTANT: do NOT mutate `ev` — EventBus fans the SAME dict
                # reference to every subscriber. Mutation would corrupt the
                # dict for any other subscriber on the same session.
                ev_type = ev.get("type", "message")
                payload = {k: v for k, v in ev.items() if k != "type"}
                yield {"event": ev_type, "data": json.dumps(payload, ensure_ascii=False)}

    return EventSourceResponse(gen())
```

- [ ] **Step 4: Register router in `app.py`**

After the existing router registrations, add:

```python
from api.events import router as events_router
app.include_router(events_router, prefix="/api")
```

- [ ] **Step 5: Run, expect 2 PASS + full suite green**

```bash
.venv/Scripts/pytest tests/test_events_api.py -v
.venv/Scripts/pytest -v
```

Full suite expected: **107 passed** (105 + 2 new).

- [ ] **Step 6: Commit**

```bash
git add backend/api/events.py backend/app.py backend/tests/test_events_api.py
git commit -m "feat(backend): /api/events/{sid}/stream SSE side-channel for late events"
```

---

## Phase 5 — Frontend Integration

### Task 5.1: useEventStream hook + eventStore

**Files:**
- Create: `FF-OpenHermes/frontend/src/hooks/useEventStream.ts`
- Create: `FF-OpenHermes/frontend/src/stores/eventStore.ts`
- Modify: `FF-OpenHermes/frontend/src/types/api.ts` (add SkillGeneratedEvent type)

The hook is a persistent SSE subscriber per active session. It reuses the same CRLF-tolerant frame parser pattern from `useSseStream`. Events flow into `eventStore` which tracks unread count.

- [ ] **Step 1: Add type to `src/types/api.ts`** — append at end

```ts
export interface SkillGeneratedEvent {
  type: "skill_generated";
  name: string;
  description: string;
  receivedAt: number; // local timestamp
}
```

- [ ] **Step 2: Create `src/stores/eventStore.ts`**

```ts
"use client";
import { create } from "zustand";
import type { SkillGeneratedEvent } from "@/types/api";

interface State {
  /** Events received since the last `markAllSeen()` call (per active session) */
  unread: SkillGeneratedEvent[];
  /** Cumulative log of all skill_generated events for the current session, displayed inline in chat */
  inSession: SkillGeneratedEvent[];
  pushSkillGenerated(ev: Omit<SkillGeneratedEvent, "type" | "receivedAt">): void;
  markAllSeen(): void;
  resetForSession(): void;
}

export const useEventStore = create<State>((set) => ({
  unread: [],
  inSession: [],
  pushSkillGenerated(ev) {
    const full: SkillGeneratedEvent = {
      type: "skill_generated",
      name: ev.name,
      description: ev.description,
      receivedAt: Date.now(),
    };
    set((s) => ({
      unread: [...s.unread, full],
      inSession: [...s.inSession, full],
    }));
  },
  markAllSeen() {
    set({ unread: [] });
  },
  resetForSession() {
    set({ unread: [], inSession: [] });
  },
}));
```

- [ ] **Step 3: Create `src/hooks/useEventStream.ts`**

```ts
"use client";
import { useEffect, useRef } from "react";
import { SSE_BASE } from "@/services/api";
import { useEventStore } from "@/stores/eventStore";

/** Persistent SSE subscriber for the given session. Auto-reconnects on transient network drops. */
export function useEventStream(sessionId: string | null) {
  const pushSkillGenerated = useEventStore((s) => s.pushSkillGenerated);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    if (!sessionId) return;
    let cancelled = false;
    let reconnectDelayMs = 1000;

    const connect = async () => {
      while (!cancelled) {
        const ctrl = new AbortController();
        abortRef.current = ctrl;
        try {
          const resp = await fetch(`${SSE_BASE}/api/events/${sessionId}/stream`, {
            method: "GET",
            signal: ctrl.signal,
          });
          if (!resp.ok || !resp.body) {
            console.warn("event stream HTTP", resp.status);
            await sleep(reconnectDelayMs);
            reconnectDelayMs = Math.min(reconnectDelayMs * 2, 15000);
            continue;
          }
          reconnectDelayMs = 1000; // reset on successful connect
          const reader = resp.body.getReader();
          const decoder = new TextDecoder();
          let buf = "";
          while (!cancelled) {
            const { done, value } = await reader.read();
            if (done) break;
            buf += decoder.decode(value, { stream: true });
            // Same CRLF-tolerant frame split as useSseStream
            let m: RegExpExecArray | null;
            const sep = /\r?\n\r?\n/;
            while ((m = sep.exec(buf))) {
              const frame = buf.slice(0, m.index);
              buf = buf.slice(m.index + m[0].length);
              let event = "";
              const dataLines: string[] = [];
              for (const line of frame.split(/\r?\n/)) {
                if (line.startsWith("event:")) event = line.slice(6).trim();
                else if (line.startsWith("data:")) dataLines.push(line.slice(5).trim());
              }
              if (!event) continue;
              let data: unknown = null;
              try { data = JSON.parse(dataLines.join("\n")); } catch { /* ignore */ }
              if (event === "skill_generated" && data && typeof data === "object") {
                const d = data as { name?: string; description?: string };
                if (d.name) pushSkillGenerated({ name: d.name, description: d.description ?? "" });
              }
              // ready / ping / unknown events ignored
            }
          }
        } catch (e) {
          if ((e as { name?: string }).name === "AbortError") return;
          console.warn("event stream error:", e);
        }
        // Loop back and reconnect after backoff
        if (!cancelled) await sleep(reconnectDelayMs);
        reconnectDelayMs = Math.min(reconnectDelayMs * 2, 15000);
      }
    };

    void connect();
    return () => {
      cancelled = true;
      abortRef.current?.abort();
    };
  }, [sessionId, pushSkillGenerated]);
}

function sleep(ms: number) {
  return new Promise<void>((resolve) => setTimeout(resolve, ms));
}
```

- [ ] **Step 4: Commit**

```bash
git add frontend/src/types/api.ts frontend/src/stores/eventStore.ts frontend/src/hooks/useEventStream.ts
git commit -m "feat(frontend): useEventStream hook + eventStore for side-channel events"
```

---

### Task 5.2: SkillEventCard component

**Files:**
- Create: `FF-OpenHermes/frontend/src/components/chat/SkillEventCard.tsx`

A standalone bubble that appears in the chat stream after assistant messages. Distinguished from regular messages by a copper accent border and ⚡ icon.

- [ ] **Step 1: Create the component**

```tsx
"use client";
import Link from "next/link";
import { Zap, ArrowRight } from "lucide-react";
import type { SkillGeneratedEvent } from "@/types/api";

export default function SkillEventCard({ event }: { event: SkillGeneratedEvent }) {
  return (
    <div className="rounded-xl border-l-4 border-l-accent-primary border border-border-subtle bg-bg-surface px-4 py-3 shadow-sm max-w-[80%] animate-in fade-in slide-in-from-bottom-1">
      <div className="flex items-start gap-3">
        <div className="w-8 h-8 rounded-lg bg-accent-primary/15 text-accent-primary flex items-center justify-center flex-shrink-0">
          <Zap className="w-4 h-4" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-xs uppercase tracking-wide text-accent-primary font-semibold mb-0.5">
            Skill Auto-Generated
          </div>
          <div className="font-mono text-sm font-medium text-text-primary truncate">{event.name}</div>
          {event.description && (
            <div className="text-xs text-text-secondary mt-1 line-clamp-2">{event.description}</div>
          )}
        </div>
        <Link
          href="/skills"
          className="self-center text-xs text-accent-primary hover:text-accent-hover flex items-center gap-1 flex-shrink-0"
        >
          View <ArrowRight className="w-3 h-3" />
        </Link>
      </div>
    </div>
  );
}
```

- [ ] **Step 2: Commit**

```bash
git add frontend/src/components/chat/SkillEventCard.tsx
git commit -m "feat(frontend): SkillEventCard component for inline skill-generation notification"
```

---

### Task 5.3: Wire SkillEventCard into ChatPanel + reset on session switch

**Files:**
- Modify: `FF-OpenHermes/frontend/src/components/chat/ChatPanel.tsx`

Mount `useEventStream` when there's an active session. Render `SkillEventCard` for each entry in `eventStore.inSession` after the messages list. Reset `eventStore` on session switch.

- [ ] **Step 1: Modify `ChatPanel.tsx`**

The full updated file:

```tsx
"use client";
import { useEffect, useMemo, useRef } from "react";
import { useSessionStore } from "@/stores/sessionStore";
import { useChatStore } from "@/stores/chatStore";
import { useWorkspaceStore } from "@/stores/workspaceStore";
import { useEventStore } from "@/stores/eventStore";
import { useSseStream } from "@/hooks/useSseStream";
import { useEventStream } from "@/hooks/useEventStream";
import { api } from "@/services/api";
import ChatMessage from "./ChatMessage";
import ChatInput from "./ChatInput";
import ChatEmpty from "./ChatEmpty";
import SkillEventCard from "./SkillEventCard";

export default function ChatPanel() {
  const sid = useSessionStore((s) => s.activeSid);
  const messages = useChatStore((s) => s.messages);
  const pending = useChatStore((s) => s.pendingAssistant);
  const reset = useChatStore((s) => s.reset);
  const loadHistory = useChatStore((s) => s.loadHistory);
  const pushUser = useChatStore((s) => s.pushUser);
  const startAssistant = useChatStore((s) => s.startAssistant);
  const appendToken = useChatStore((s) => s.appendToken);
  const toolStart = useChatStore((s) => s.toolStart);
  const toolEnd = useChatStore((s) => s.toolEnd);
  const finishAssistant = useChatStore((s) => s.finishAssistant);
  const setRunning = useChatStore((s) => s.setRunning);
  const refreshWorkspace = useWorkspaceStore((s) => s.refresh);
  const inSessionEvents = useEventStore((s) => s.inSession);
  const resetEvents = useEventStore((s) => s.resetForSession);

  // Subscribe to side-channel events for the active session
  useEventStream(sid);

  // Reset chat + events on session switch and load history
  useEffect(() => {
    reset();
    resetEvents();
    if (!sid) return;
    let cancelled = false;
    api.history(sid).then(({ turns }) => {
      if (!cancelled) loadHistory(turns);
    }).catch((e) => console.error("history load failed:", e));
    return () => { cancelled = true; };
  }, [sid, reset, resetEvents, loadHistory]);

  const handler = useMemo(() => (event: string, data: unknown) => {
    const d = data as Record<string, unknown>;
    if (event === "turn_start") startAssistant(String(d.turn_id ?? ""));
    else if (event === "assistant_token") appendToken(String(d.content ?? ""));
    else if (event === "tool_start") toolStart(d as never);
    else if (event === "tool_end") {
      toolEnd(d as never);
      const toolName = String((d as { name?: string }).name ?? "");
      if (sid && (toolName === "write_file" || toolName === "terminal")) {
        void refreshWorkspace(sid);
      }
    }
    else if (event === "turn_end") finishAssistant();
    else if (event === "error") { console.error("SSE error:", d); finishAssistant(); }
  }, [startAssistant, appendToken, toolStart, toolEnd, finishAssistant, sid, refreshWorkspace]);

  const { send, running } = useSseStream(handler);
  useEffect(() => { setRunning(running); }, [running, setRunning]);

  const onSend = async (text: string) => {
    if (!sid) return;
    pushUser(text);
    await send(sid, text);
  };

  const scrollRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, pending, inSessionEvents]);

  if (!sid) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-text-muted gap-3 px-8">
        <div className="text-text-secondary">No session selected.</div>
        <div className="text-xs">Click <span className="px-2 py-0.5 rounded bg-accent-primary text-white font-medium">+ New</span> at the top to create one.</div>
      </div>
    );
  }

  const isEmpty = messages.length === 0 && !pending && inSessionEvents.length === 0;

  return (
    <div className="h-full flex flex-col">
      {isEmpty ? (
        <div className="flex-1 overflow-auto">
          <ChatEmpty onSamplePrompt={onSend} />
        </div>
      ) : (
        <div ref={scrollRef} className="flex-1 overflow-auto px-6 py-4 space-y-4">
          {messages.map((m) => <ChatMessage key={m.id} message={m} />)}
          {pending && <ChatMessage message={pending} streaming />}
          {inSessionEvents.map((e, i) => (
            <SkillEventCard key={`evt_${i}_${e.receivedAt}`} event={e} />
          ))}
        </div>
      )}
      <ChatInput onSend={onSend} disabled={running} />
    </div>
  );
}
```

- [ ] **Step 2: Verify build**

```bash
cd "E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes/frontend"
npm run build
```

Expected: clean compile, all routes generated, no TypeScript errors.

- [ ] **Step 3: Commit**

```bash
git add frontend/src/components/chat/ChatPanel.tsx
git commit -m "feat(frontend): mount useEventStream + render SkillEventCard inline in chat"
```

---

### Task 5.4: NavSidebar red dot for unread skill events

**Files:**
- Modify: `FF-OpenHermes/frontend/src/components/layout/NavSidebar.tsx`

Show a red dot on the ⚡ Skills nav item when `eventStore.unread.length > 0`. Mark as seen when user navigates to /skills page.

- [ ] **Step 1: Modify `NavSidebar.tsx`** to wire the red dot

Replace `NavSidebar.tsx` content:

```tsx
"use client";
import { useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { MessageSquare, Brain, Zap, Settings } from "lucide-react";
import clsx from "clsx";
import WorkspaceTree from "./WorkspaceTree";
import { useEventStore } from "@/stores/eventStore";

const items = [
  { href: "/", icon: MessageSquare, label: "Chat" },
  { href: "/memory", icon: Brain, label: "Memory" },
  { href: "/skills", icon: Zap, label: "Skills" },
] as const;

export default function NavSidebar() {
  const pathname = usePathname();
  const unreadCount = useEventStore((s) => s.unread.length);
  const markAllSeen = useEventStore((s) => s.markAllSeen);

  // Auto-mark events seen when user lands on /skills
  useEffect(() => {
    if (pathname === "/skills" && unreadCount > 0) markAllSeen();
  }, [pathname, unreadCount, markAllSeen]);

  return (
    <aside className="h-full w-full border-r border-border-subtle bg-bg-sidebar flex flex-col">
      <nav className="px-3 py-3 space-y-1">
        {items.map(({ href, icon: Icon, label }) => {
          const active = pathname === href;
          const showBadge = label === "Skills" && unreadCount > 0;
          return (
            <Link
              key={href}
              href={href}
              className={clsx(
                "relative flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors",
                active
                  ? "bg-bg-surface text-text-primary shadow-sm"
                  : "text-text-secondary hover:bg-bg-elevated hover:text-text-primary"
              )}
            >
              <Icon className={clsx("w-4 h-4", active && "text-accent-primary")} />
              {label}
              {showBadge && (
                <span
                  title={`${unreadCount} new skill${unreadCount > 1 ? "s" : ""}`}
                  className="ml-auto w-2 h-2 rounded-full bg-accent-primary animate-pulse"
                />
              )}
            </Link>
          );
        })}
      </nav>

      <div className="border-t border-border-subtle/60 flex-1 overflow-hidden flex flex-col">
        <WorkspaceTree />
      </div>

      <div className="border-t border-border-subtle/60 px-3 py-3 flex items-center gap-2">
        <div className="w-9 h-9 rounded-full bg-accent-primary text-white text-sm font-semibold flex items-center justify-center shadow-sm">
          F
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-sm font-medium text-text-primary truncate">FF-OpenHermes</div>
          <div className="text-xs text-text-muted flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-ok inline-block" /> Online
          </div>
        </div>
        <button
          title="Settings"
          className="w-7 h-7 rounded-md text-text-muted hover:text-accent-primary hover:bg-bg-elevated flex items-center justify-center transition-colors"
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>
    </aside>
  );
}
```

- [ ] **Step 2: Verify build**

```bash
cd "E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes/frontend"
npm run build
```

Expected: clean compile.

- [ ] **Step 3: Commit**

```bash
git add frontend/src/components/layout/NavSidebar.tsx
git commit -m "feat(frontend): NavSidebar red-dot indicator for unread skill_generated events"
```

---

## Phase 6 — End-to-End Smoke + M2 Release

### Task 6.1: Run full backend suite + create smoke checklist

**Files:**
- Create: `FF-OpenHermes/docs/M2-smoke-checklist.md`

- [ ] **Step 1: Run all backend tests**

```bash
cd "E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes/backend"
.venv/Scripts/pytest -v
```

Expected: **107 passed** (73 from M1 + 34 new from M2: 6 schemas + 7 lint + 5 generator + 4 detect + 5 event_bus + 4 middleware + 1 agent_manager_m2 + 2 events_api).

If anything red, fix before tagging.

- [ ] **Step 2: Run frontend build**

```bash
cd "E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes/frontend"
npm run build
```

Expected: clean build with all routes (Chat / Memory / Skills) generated.

- [ ] **Step 3: Create `docs/M2-smoke-checklist.md`**

```markdown
# M2 Smoke Checklist · Skill 自主生成

Backend: `uvicorn app:app --port 8003` (uses `.env` with TAVILY_API_KEY for search_web)
Frontend: `npm run dev` (port 3000)

## Pre-flight
- [ ] `pytest -v` → 107 passed
- [ ] `npm run build` → clean
- [ ] Backend `.env` has `OPENROUTER_MODEL=deepseek/deepseek-chat-v3.1`
- [ ] Backend `.env` has `SKILL_GEN_THRESHOLD=3`

## Scenario A — Trigger auto-generation

1. [ ] Open browser, create a session bound to any existing directory
2. [ ] Send a complex prompt that uses ≥3 tools, e.g.:
       _"用 search_web 找一下 LangChain 1.x 的官方文档地址，然后 fetch_url 抓取首页内容，最后用 python_repl 提取所有以 https 开头的链接列出来"_
3. [ ] Verify in chat: assistant streams normal reply with 3+ tool call cards
4. [ ] Wait 3-15 seconds after `turn_end` (generator runs async)
5. [ ] **A SkillEventCard with copper border + ⚡ icon appears below the assistant reply**
6. [ ] **NavSidebar's ⚡ Skills item shows a small pulsing copper dot**
7. [ ] Click "View →" or navigate to `/skills` — the new auto-generated skill appears in the library
8. [ ] The skill's HISTORY.md (visible in EvolutionLog right panel) shows `v1.0 · 🤖 Auto-Generated`
9. [ ] After visiting `/skills`, the red dot disappears

## Scenario B — NO_SKILL branch

1. [ ] Send a one-tool-call simple prompt: _"用 terminal 列一下当前目录的文件"_
2. [ ] After turn_end, no SkillEventCard appears (only 1 tool call < threshold 3)

## Scenario C — Skipped because skill was already used

1. [ ] First, manually create a skill on the Skills page (or use one auto-generated from Scenario A)
2. [ ] Click "Load Level 1" to load it into the session
3. [ ] Send a prompt that uses that skill plus 3+ other tool calls
4. [ ] Verify NO new SkillEventCard appears (M2 skips when read_skill was called — that's M3's job)

## Scenario D — Side-channel reconnect

1. [ ] In another terminal: `taskkill /PID <uvicorn-pid> /F`
2. [ ] Restart backend: `uvicorn app:app --port 8003`
3. [ ] Send a chat that triggers auto-generation
4. [ ] Frontend `useEventStream` should auto-reconnect (1s → 2s → 4s backoff) and deliver the new skill_generated event
```

- [ ] **Step 4: Commit**

```bash
cd "E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes"
git add docs/M2-smoke-checklist.md
git commit -m "docs: M2 smoke checklist for end-to-end verification"
```

---

### Task 6.2: Tag M2 release

- [ ] **Step 1: Tag**

```bash
cd "E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes"
git tag -a v0.2.0-m2 -m "M2: Skill auto-generation via after_agent middleware + side-channel SSE"
git tag
```

Expected `git tag` output should include both `v0.1.0-m1` and `v0.2.0-m2`.

- [ ] **Step 2: Update PRD §10 M2 task list to checked**

Open `PRD.md`, find the `### M2 · Skill 自主生成（P1）` section, change all `- [ ]` to `- [x]`. Commit:

```bash
git add PRD.md
git commit -m "docs: mark M2 milestone complete in PRD"
```

---

## Self-Review

**Spec coverage check** (cross-reference against the spec in this plan's preamble):

| Spec requirement | Plan task(s) | Status |
|---|---|---|
| `after_agent` middleware that detects ≥3 tool calls + no skill used | 3.2, 3.3 | covered |
| Async non-blocking via `asyncio.create_task` | 3.2 | covered |
| Pydantic structured output (port from case-07 Zod) | 1.1 | covered |
| Lint rules (kebab-case / double-focus / length / reserved words) | 1.2 | covered |
| LLM evaluation returns NO_SKILL when not worth saving | 1.1 (decision Literal) + 2.1 (handle path) | covered |
| Persistence via `SkillOps.write_skill` (existing) | 2.1 | covered |
| Atomic write + HISTORY.md + snapshot rebuild | 2.1 (delegated to SkillOps from M1) | covered |
| Name conflict handling | 2.1 (`_resolve_name_conflict`) | covered |
| Pydantic validation retry once | 2.1 (`_invoke_with_retry`) | covered |
| Failure tolerance (silent log) | 2.1 (try/except in generator + middleware) | covered |
| `SKILL_GEN_THRESHOLD` env config | 3.3 (reads `settings.SKILL_GEN_THRESHOLD`) | covered |
| Side-channel SSE for late events | 3.1 + 4.1 + 5.1 | covered |
| Frontend SkillEventCard | 5.2, 5.3 | covered |
| NavSidebar red-dot indicator | 5.4 | covered |
| Stats counter (`skills_generated`) update | 3.2 (middleware) | covered |
| Compatibility: don't break ChatMessage / extract_turns / useSseStream | inherent — none of those files modified | covered |

**Type / signature consistency check**:
- `SkillEngineMiddleware(session_manager, event_bus, llm_factory, threshold)` — same signature in 3.2 (definition), 3.3 (instantiation), test in 3.2.
- `generate_skill_from_turn(messages, session_dir, llm_factory)` — same signature 2.1 (def), 3.2 (call), tests in 2.1 and 3.2.
- `EventBus.publish(session_id, event)` and `subscribe(session_id)` — consistent across 3.1, 3.2, 4.1, 5.1.
- `SkillGeneratedEvent` interface — same field set in `types/api.ts`, `eventStore.ts`, `SkillEventCard.tsx`, `useEventStream.ts`.
- `SkillOps.write_skill(name, content, history_line)` — used unchanged from M1 in 2.1.

**Placeholder scan**: No "TBD", "implement later", "similar to Task N", or open-ended "add error handling" left. Every task has complete code blocks.

---

## Execution Handoff

**Plan complete and saved to `FF-OpenHermes/docs/M2-plan.md`. Two execution options:**

1. **Subagent-Driven (recommended)** — I dispatch a fresh subagent per task (or per logical bundle of small tasks), review between tasks, fast iteration. Best for this scope (~17 tasks, 7 phases). Uses `superpowers:subagent-driven-development`.

2. **Inline Execution** — Execute tasks in this session using `superpowers:executing-plans`, batch with checkpoints for review.

**Which approach?**
