# FF-OpenHermes M1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the M1 milestone of FF-OpenHermes — a runnable web Agent that supports SSE chat, three-layer memory (SOUL/MEMORY/SqliteSaver), per-session workspace binding (Claude-Code-style), and manual skill loading. M2/M3 (auto-generation, auto-enhancement) are NOT in this plan.

**Architecture:** Python 3.10+ FastAPI backend with LangChain 1.x `create_agent` + `AsyncSqliteSaver` per-session checkpointer; Next.js 14 frontend with Tailwind + Zustand + Monaco. Each session is a self-contained directory under `backend/sessions/{sid}/` holding SOUL.md, MEMORY.md, skills/, state.db, and a `meta.json` whose `workspace_path` field binds the session to an external user project directory. All "operate on files" tools default cwd to that workspace_path; the left sidebar's bottom half displays its file tree.

**Tech Stack:**
- Backend: Python 3.10+, FastAPI, sse-starlette, LangChain 1.x, langgraph, langgraph-checkpoint-sqlite, langchain-openai (used as OpenRouter client), pydantic v2, pytest + httpx
- Frontend: Next.js 14 (App Router), TypeScript, Tailwind CSS v3, Zustand, Monaco Editor, lucide-react, vitest + @testing-library/react
- LLM: OpenRouter `deepseek/deepseek-chat-v3.1` (anthropic/openai/google models are 403 from this IP — see user memory `openrouter_region_block`)
- Reuse base: `260205mini-OpenClaw开发实战/mini-OpenClaw/backend/` for tools and runtime patterns; `20260226Claude Code入门/fufan-cc-flow-src/` for FileTree and path-utility patterns

**Project root:** `E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes/`

**Reference files (read before each phase that mentions them):**
- `260205mini-OpenClaw开发实战/mini-OpenClaw/backend/tools/terminal_tool.py` (terminal)
- `260205mini-OpenClaw开发实战/mini-OpenClaw/backend/tools/python_repl_tool.py`
- `260205mini-OpenClaw开发实战/mini-OpenClaw/backend/tools/read_file_tool.py` (sandbox pattern)
- `260205mini-OpenClaw开发实战/mini-OpenClaw/backend/tools/tavily_search_tool.py`
- `260205mini-OpenClaw开发实战/mini-OpenClaw/backend/utils/encoding.py`
- `260205mini-OpenClaw开发实战/mini-OpenClaw/backend/graph/agent.py` (the OLD pattern — we're switching to LangChain 1.x middleware + AsyncSqliteSaver)
- `20260226Claude Code入门/fufan-cc-flow-src/server/src/utils/pathUtils.ts` (isSubPath)
- `20260226Claude Code入门/fufan-cc-flow-src/server/src/services/fileService.ts` (tree builder)

---

## Plan Overview · 14 Phases

| Phase | Topic | Tasks |
|---|---|---|
| 0 | Project scaffolding (deps, dirs, env) | 0.1 – 0.4 |
| 1 | Path utils + Session model + persistence | 1.1 – 1.3 |
| 2 | Workspace ops (tree, file CRUD, sandboxing) | 2.1 – 2.3 |
| 3 | Tools migration + workspace cwd binding | 3.1 – 3.5 |
| 4 | LangChain 1.x agent runtime + middleware skeleton | 4.1 – 4.4 |
| 5 | SSE chat API | 5.1 – 5.2 |
| 6 | REST APIs (sessions, workspace, fs, memory, skills) | 6.1 – 6.5 |
| 7 | Frontend scaffold (Next.js + theme + layout) | 7.1 – 7.3 |
| 8 | Session state + SessionSelector | 8.1 – 8.2 |
| 9 | Chat page | 9.1 – 9.3 |
| 10 | Memory page | 10.1 – 10.3 |
| 11 | Skills page (manual load) | 11.1 – 11.4 |
| 12 | Workspace file tree (NavSidebar bottom half) | 12.1 – 12.2 |
| 13 | NewSessionModal + DirectoryPicker | 13.1 – 13.2 |
| 14 | E2E smoke test | 14.1 – 14.2 |

---

## Phase 0 — Project Scaffolding

### Task 0.1: Backend project skeleton

**Files:**
- Create: `FF-OpenHermes/backend/requirements.txt`
- Create: `FF-OpenHermes/backend/.env.example`
- Create: `FF-OpenHermes/backend/.gitignore`
- Create: `FF-OpenHermes/backend/pytest.ini`
- Create: `FF-OpenHermes/backend/conftest.py`
- Create: `FF-OpenHermes/backend/api/__init__.py`
- Create: `FF-OpenHermes/backend/agent/__init__.py`
- Create: `FF-OpenHermes/backend/tools/__init__.py`
- Create: `FF-OpenHermes/backend/utils/__init__.py`
- Create: `FF-OpenHermes/backend/templates/SOUL.md`
- Create: `FF-OpenHermes/backend/templates/MEMORY.md`

- [ ] **Step 1: Create directories**

```bash
cd FF-OpenHermes/backend
mkdir -p api agent tools utils templates sessions tests
touch api/__init__.py agent/__init__.py tools/__init__.py utils/__init__.py tests/__init__.py
```

- [ ] **Step 2: Write `requirements.txt`**

```
fastapi>=0.110.0
uvicorn[standard]>=0.27.0
sse-starlette>=2.0.0
python-dotenv>=1.0.0
pydantic>=2.0.0

# LangChain 1.x
langchain>=1.0.0
langchain-core>=0.3.0
langchain-openai>=0.3.0
langgraph>=1.0.0
langgraph-checkpoint-sqlite>=2.0.0
aiosqlite>=0.20.0

# Tools
beautifulsoup4>=4.12.0
html2text>=2024.2.26
requests>=2.31.0
httpx>=0.27.0
tavily-python>=0.5.0

# Token counting
tiktoken>=0.7.0

# Tests
pytest>=8.0.0
pytest-asyncio>=0.23.0
```

- [ ] **Step 3: Write `.env.example`**

```bash
# OpenRouter (anthropic/openai/google models are 403 from this IP — use deepseek)
OPENROUTER_API_KEY=sk-or-v1-REPLACE_ME
OPENROUTER_BASE_URL=https://openrouter.ai/api/v1
OPENROUTER_MODEL=deepseek/deepseek-chat-v3.1

# Optional: Tavily for web search tool
TAVILY_API_KEY=

# Server
HOST=127.0.0.1
PORT=8003
CORS_ORIGINS=http://localhost:3000

# Skill engine (used in M2/M3, defined now to avoid migrations)
SKILL_GEN_THRESHOLD=3
```

- [ ] **Step 4: Write `.env` from existing OpenRouter key**

The user's working OpenRouter key lives in `260423RAG入门/cerebellum-llm-wiki/.env.local`. Copy it:

```bash
cp .env.example .env
# Then edit .env and set OPENROUTER_API_KEY to the value found in
# E:/work/大模型课程课件/公开课直播项目/260423RAG入门/cerebellum-llm-wiki/.env.local
# (line: OPENROUTER_API_KEY=sk-or-v1-...)
```

⚠️ Do NOT use the example file's `anthropic/claude-sonnet-4.6` — for this user's region that returns 403. Force `OPENROUTER_MODEL=deepseek/deepseek-chat-v3.1`.

- [ ] **Step 5: Write `.gitignore`**

```
__pycache__/
*.pyc
.env
.venv/
venv/
sessions/
!sessions/.gitkeep
*.db
*.db-journal
*.db-wal
*.db-shm
.pytest_cache/
```

- [ ] **Step 6: Write `pytest.ini`**

```ini
[pytest]
asyncio_mode = auto
testpaths = tests
pythonpath = .
```

- [ ] **Step 7: Write `templates/SOUL.md`**

```markdown
# Agent Soul

You are Hermes, an AI assistant that learns and evolves through conversation.

## Core Traits
- You actively summarize complex tasks into reusable skill documents
- You identify important information worth remembering and write it to long-term memory
- You reflect on skill execution and continuously improve them
- Your goal is to become more capable and accurate with each interaction

## Behavior
- Think clearly, step by step
- Explain why you use each tool
- If unsure, say so honestly
- Default response language: Chinese (中文), unless the user writes in another language
```

- [ ] **Step 8: Write `templates/MEMORY.md`**

```markdown
# Long-term Memory

This file is your persistent memory across the lifetime of this session.
It is loaded into your system prompt every turn. Use the `write_memory`
tool to add facts that will be useful in future turns.

<!-- Memory entries below this line. Keep concise. -->
```

- [ ] **Step 9: Create empty `sessions/.gitkeep`**

```bash
touch sessions/.gitkeep
```

- [ ] **Step 10: Install deps**

```bash
cd FF-OpenHermes/backend
python -m venv .venv
# Windows
.venv/Scripts/pip install -r requirements.txt
# (or on POSIX: .venv/bin/pip install -r requirements.txt)
```

Expected: all packages install without errors.

- [ ] **Step 11: Verify imports**

```bash
.venv/Scripts/python -c "import langchain; from langchain.agents import create_agent; from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver; from langchain_openai import ChatOpenAI; print('OK')"
```

Expected: `OK` (no ImportError). If `create_agent` or `AsyncSqliteSaver` fail, you have a stale LangChain — rerun `pip install --upgrade langchain langgraph langgraph-checkpoint-sqlite`.

- [ ] **Step 12: Commit**

```bash
cd FF-OpenHermes
git init
git add backend/
git commit -m "feat(backend): initialize FastAPI + LangChain 1.x scaffolding"
```

---

### Task 0.2: Frontend project skeleton

**Files:**
- Create: `FF-OpenHermes/frontend/package.json`
- Create: `FF-OpenHermes/frontend/tsconfig.json`
- Create: `FF-OpenHermes/frontend/next.config.mjs`
- Create: `FF-OpenHermes/frontend/tailwind.config.ts`
- Create: `FF-OpenHermes/frontend/postcss.config.mjs`
- Create: `FF-OpenHermes/frontend/.env.local.example`

- [ ] **Step 1: Bootstrap Next.js**

```bash
cd FF-OpenHermes
npx create-next-app@14 frontend --typescript --tailwind --eslint --app --src-dir --import-alias "@/*" --no-turbopack
```

When prompted, accept defaults. This creates `frontend/` with App Router + TS + Tailwind v3.

- [ ] **Step 2: Add dependencies**

```bash
cd frontend
npm install zustand monaco-editor @monaco-editor/react lucide-react clsx
npm install --save-dev @testing-library/react @testing-library/jest-dom vitest jsdom @vitejs/plugin-react
```

- [ ] **Step 3: Write `.env.local.example`**

```
NEXT_PUBLIC_API_BASE=http://127.0.0.1:8003
```

- [ ] **Step 4: Copy to `.env.local`**

```bash
cp .env.local.example .env.local
```

- [ ] **Step 5: Add vitest config**

Create `frontend/vitest.config.ts`:

```ts
import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";
import path from "path";

export default defineConfig({
  plugins: [react()],
  test: {
    environment: "jsdom",
    globals: true,
    setupFiles: ["./vitest.setup.ts"],
  },
  resolve: {
    alias: { "@": path.resolve(__dirname, "src") },
  },
});
```

Create `frontend/vitest.setup.ts`:

```ts
import "@testing-library/jest-dom";
```

Add to `package.json` scripts:

```json
"test": "vitest run",
"test:watch": "vitest"
```

- [ ] **Step 6: Smoke run**

```bash
cd frontend
npm run dev
```

Expected: Next.js boots on http://localhost:3000 with default page. Ctrl+C to stop.

- [ ] **Step 7: Commit**

```bash
git add frontend/
git commit -m "feat(frontend): bootstrap Next.js 14 + Tailwind + Zustand"
```

---

### Task 0.3: FastAPI app entrypoint

**Files:**
- Create: `FF-OpenHermes/backend/config.py`
- Create: `FF-OpenHermes/backend/app.py`
- Create: `FF-OpenHermes/backend/tests/test_app.py`

- [ ] **Step 1: Write the failing test**

`backend/tests/test_app.py`:

```python
"""Tests for FastAPI app entrypoint."""
import pytest
from httpx import ASGITransport, AsyncClient

from app import app


@pytest.mark.asyncio
async def test_root_returns_status():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        resp = await ac.get("/")
    assert resp.status_code == 200
    body = resp.json()
    assert body["name"] == "FF-OpenHermes"
    assert body["status"] == "running"
```

- [ ] **Step 2: Run, expect ImportError**

```bash
cd FF-OpenHermes/backend
.venv/Scripts/pytest tests/test_app.py -v
```

Expected: FAIL with `ModuleNotFoundError: No module named 'app'`.

- [ ] **Step 3: Implement `config.py`**

```python
"""Centralized config — loads from .env once at import time."""
import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
SESSIONS_DIR = BASE_DIR / "sessions"
TEMPLATES_DIR = BASE_DIR / "templates"

load_dotenv(BASE_DIR / ".env")


class Settings:
    OPENROUTER_API_KEY: str = os.getenv("OPENROUTER_API_KEY", "")
    OPENROUTER_BASE_URL: str = os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1")
    OPENROUTER_MODEL: str = os.getenv("OPENROUTER_MODEL", "deepseek/deepseek-chat-v3.1")

    TAVILY_API_KEY: str = os.getenv("TAVILY_API_KEY", "")

    HOST: str = os.getenv("HOST", "127.0.0.1")
    PORT: int = int(os.getenv("PORT", "8003"))
    CORS_ORIGINS: list[str] = [
        s.strip() for s in os.getenv("CORS_ORIGINS", "http://localhost:3000").split(",") if s.strip()
    ]

    SKILL_GEN_THRESHOLD: int = int(os.getenv("SKILL_GEN_THRESHOLD", "3"))


settings = Settings()
```

- [ ] **Step 4: Implement `app.py`**

```python
"""FF-OpenHermes — FastAPI entrypoint."""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from config import settings, SESSIONS_DIR


@asynccontextmanager
async def lifespan(app: FastAPI):
    SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
    print(f"FF-OpenHermes backend ready · sessions={SESSIONS_DIR}")
    yield


app = FastAPI(title="FF-OpenHermes", version="0.1.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def root():
    return {"name": "FF-OpenHermes", "version": "0.1.0", "status": "running"}
```

- [ ] **Step 5: Run test, expect PASS**

```bash
.venv/Scripts/pytest tests/test_app.py -v
```

Expected: 1 passed.

- [ ] **Step 6: Boot manually**

```bash
.venv/Scripts/uvicorn app:app --port 8003 --reload
```

Open another terminal:

```bash
curl http://127.0.0.1:8003/
```

Expected: `{"name":"FF-OpenHermes","version":"0.1.0","status":"running"}`. Stop the server.

- [ ] **Step 7: Commit**

```bash
git add backend/config.py backend/app.py backend/tests/test_app.py
git commit -m "feat(backend): FastAPI app skeleton with health check"
```

---

### Task 0.4: Encoding util (port from mini-OpenClaw)

**Files:**
- Create: `FF-OpenHermes/backend/utils/encoding.py`
- Create: `FF-OpenHermes/backend/tests/test_encoding.py`

This util is identical to mini-OpenClaw's — copy verbatim. Tests verify the fallback chain.

- [ ] **Step 1: Write failing test**

`backend/tests/test_encoding.py`:

```python
"""Tests for encoding fallback util."""
from pathlib import Path

import pytest

from utils.encoding import safe_read_text


def test_utf8_file(tmp_path: Path):
    p = tmp_path / "u.txt"
    p.write_text("héllo 中文", encoding="utf-8")
    assert safe_read_text(p) == "héllo 中文"


def test_gbk_file(tmp_path: Path):
    p = tmp_path / "g.txt"
    p.write_bytes("中文测试".encode("gbk"))
    assert "中文测试" in safe_read_text(p)


def test_replace_fallback(tmp_path: Path):
    p = tmp_path / "bad.bin"
    p.write_bytes(b"\xff\xfe\x00garbage")
    # Should not raise
    safe_read_text(p)
```

- [ ] **Step 2: Run, expect FAIL (module missing)**

```bash
.venv/Scripts/pytest tests/test_encoding.py -v
```

- [ ] **Step 3: Implement `utils/encoding.py`** (copy from `260205mini-OpenClaw开发实战/mini-OpenClaw/backend/utils/encoding.py`)

```python
"""Shared encoding utilities — safe file reading with fallback."""
from pathlib import Path


def safe_read_text(path: Path) -> str:
    """Read text with encoding fallback: UTF-8 -> GBK -> UTF-8(replace)."""
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        pass
    try:
        return path.read_text(encoding="gbk")
    except UnicodeDecodeError:
        pass
    return path.read_text(encoding="utf-8", errors="replace")
```

- [ ] **Step 4: Run, expect 3 PASS**

```bash
.venv/Scripts/pytest tests/test_encoding.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/utils/encoding.py backend/tests/test_encoding.py
git commit -m "feat(backend): port safe_read_text encoding util from mini-OpenClaw"
```

---

## Phase 1 — Path Utils, Session Model, Persistence

### Task 1.1: Path-safety utilities

**Files:**
- Create: `FF-OpenHermes/backend/utils/paths.py`
- Create: `FF-OpenHermes/backend/tests/test_paths.py`

These are critical — they prevent the Agent from escaping its sandbox. Mirror fufan-cc-flow `pathUtils.ts` but in Python.

- [ ] **Step 1: Write failing tests**

`backend/tests/test_paths.py`:

```python
"""Tests for path-safety utilities."""
import os
from pathlib import Path

import pytest

from utils.paths import normalize_path, is_subpath, resolve_in


def test_normalize_expands_tilde(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("USERPROFILE", str(tmp_path))  # Windows
    monkeypatch.setenv("HOME", str(tmp_path))           # POSIX
    assert normalize_path("~/foo") == str((tmp_path / "foo").resolve())


def test_is_subpath_simple(tmp_path: Path):
    parent = tmp_path / "p"
    parent.mkdir()
    (parent / "child").mkdir()
    assert is_subpath(parent, parent / "child")
    assert is_subpath(parent, parent)  # self counts
    assert not is_subpath(parent, tmp_path)


def test_is_subpath_traversal_blocked(tmp_path: Path):
    parent = tmp_path / "p"
    parent.mkdir()
    assert not is_subpath(parent, parent / ".." / "evil")


def test_resolve_in_strips_leading_dot_slash(tmp_path: Path):
    f = tmp_path / "x.txt"
    f.write_text("hi")
    resolved = resolve_in(tmp_path, "./x.txt")
    assert resolved == f.resolve()


def test_resolve_in_rejects_escape(tmp_path: Path):
    with pytest.raises(ValueError, match="escapes"):
        resolve_in(tmp_path, "../../etc/passwd")
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_paths.py -v
```

- [ ] **Step 3: Implement `utils/paths.py`**

```python
"""Path-safety utilities — sandbox enforcement."""
from pathlib import Path


def normalize_path(p: str | Path) -> str:
    """Expand ~ and resolve to absolute string path."""
    s = str(p)
    if s.startswith("~"):
        s = str(Path(s).expanduser())
    return str(Path(s).resolve())


def is_subpath(parent: str | Path, child: str | Path) -> bool:
    """True iff `child` is `parent` or a descendant of it."""
    try:
        p = Path(parent).resolve()
        c = Path(child).resolve()
    except (OSError, ValueError):
        return False
    if p == c:
        return True
    try:
        c.relative_to(p)
        return True
    except ValueError:
        return False


def resolve_in(root: str | Path, rel: str) -> Path:
    """Resolve `rel` (relative-or-absolute) inside `root`. Raise ValueError on escape."""
    root_p = Path(root).resolve()
    cleaned = rel.replace("\\", "/")
    # NOTE: str.lstrip("./") is charset-based — would strip any leading '.' or '/'
    # and silently neutralize '..' traversal. Use prefix-strip loop instead.
    while cleaned.startswith("./"):
        cleaned = cleaned[2:]
    candidate = (root_p / cleaned).resolve()
    if not is_subpath(root_p, candidate):
        raise ValueError(f"Path escapes sandbox root: {rel}")
    return candidate
```

- [ ] **Step 4: Run, expect 5 PASS**

```bash
.venv/Scripts/pytest tests/test_paths.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/utils/paths.py backend/tests/test_paths.py
git commit -m "feat(backend): path-safety utilities for sandbox enforcement"
```

---

### Task 1.2: Session metadata model

**Files:**
- Create: `FF-OpenHermes/backend/agent/models.py`
- Create: `FF-OpenHermes/backend/tests/test_models.py`

- [ ] **Step 1: Write failing test**

`backend/tests/test_models.py`:

```python
"""Tests for Pydantic session models."""
import pytest

from agent.models import SessionMeta, SessionStats


def test_session_meta_minimal():
    m = SessionMeta(
        id="sess_x",
        title="t",
        workspace_path="C:/tmp/proj",
        model="deepseek/deepseek-chat-v3.1",
    )
    assert m.id == "sess_x"
    assert m.stats.turns == 0


def test_session_meta_serializes():
    m = SessionMeta(
        id="sess_x",
        title="t",
        workspace_path="C:/tmp/proj",
        model="deepseek/deepseek-chat-v3.1",
    )
    j = m.model_dump_json()
    assert "workspace_path" in j


def test_session_meta_rejects_empty_workspace():
    with pytest.raises(ValueError):
        SessionMeta(
            id="sess_x",
            title="t",
            workspace_path="",
            model="deepseek/deepseek-chat-v3.1",
        )
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_models.py -v
```

- [ ] **Step 3: Implement `agent/models.py`**

```python
"""Pydantic data models for Sessions and related entities."""
from datetime import datetime, timezone

from pydantic import BaseModel, Field, field_validator


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


class SessionStats(BaseModel):
    turns: int = 0
    total_tokens: int = 0
    skills_generated: int = 0
    skills_enhanced: int = 0


class SessionMeta(BaseModel):
    id: str
    title: str
    workspace_path: str
    model: str
    created_at: str = Field(default_factory=_now_iso)
    updated_at: str = Field(default_factory=_now_iso)
    stats: SessionStats = Field(default_factory=SessionStats)

    @field_validator("workspace_path")
    @classmethod
    def _wp_nonempty(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("workspace_path must not be empty")
        return v


class CreateSessionRequest(BaseModel):
    title: str = "New Session"
    workspace_path: str
    model: str | None = None


class RenameSessionRequest(BaseModel):
    title: str
```

- [ ] **Step 4: Run, expect 3 PASS**

```bash
.venv/Scripts/pytest tests/test_models.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/agent/models.py backend/tests/test_models.py
git commit -m "feat(backend): SessionMeta model with workspace_path validation"
```

---

### Task 1.3: Session manager — per-session directories

**Files:**
- Create: `FF-OpenHermes/backend/agent/session_manager.py`
- Create: `FF-OpenHermes/backend/tests/test_session_manager.py`

This replaces mini-OpenClaw's JSON-file approach with a per-session directory layout.

- [ ] **Step 1: Write failing tests**

`backend/tests/test_session_manager.py`:

```python
"""Tests for SessionManager (per-session directory layout)."""
from pathlib import Path

import pytest

from agent.session_manager import SessionManager


@pytest.fixture
def workspace(tmp_path: Path) -> Path:
    ws = tmp_path / "myproj"
    ws.mkdir()
    return ws


@pytest.fixture
def manager(tmp_path: Path):
    sessions = tmp_path / "sessions"
    templates = tmp_path / "templates"
    templates.mkdir()
    (templates / "SOUL.md").write_text("# Soul template", encoding="utf-8")
    (templates / "MEMORY.md").write_text("# Memory template", encoding="utf-8")
    return SessionManager(sessions_dir=sessions, templates_dir=templates)


def test_create_session_makes_dir_and_meta(manager: SessionManager, workspace: Path):
    meta = manager.create("Title 1", str(workspace), model="m")
    sdir = manager.session_dir(meta.id)
    assert sdir.exists()
    assert (sdir / "meta.json").exists()
    assert (sdir / "SOUL.md").read_text(encoding="utf-8").startswith("# Soul template")
    assert (sdir / "MEMORY.md").read_text(encoding="utf-8").startswith("# Memory template")
    assert (sdir / "skills").is_dir()
    assert (sdir / "loaded_skills.json").exists()


def test_create_rejects_missing_workspace(manager: SessionManager, tmp_path: Path):
    with pytest.raises(ValueError, match="workspace_path"):
        manager.create("Title", str(tmp_path / "does-not-exist"), model="m")


def test_list_sorted_by_updated_at(manager: SessionManager, workspace: Path):
    a = manager.create("A", str(workspace), model="m")
    b = manager.create("B", str(workspace), model="m")
    rows = manager.list()
    ids = [r.id for r in rows]
    # b should come before a (more recent)
    assert ids.index(b.id) < ids.index(a.id)


def test_get_meta_roundtrip(manager: SessionManager, workspace: Path):
    meta = manager.create("Roundtrip", str(workspace), model="m")
    loaded = manager.get(meta.id)
    assert loaded.id == meta.id
    assert loaded.workspace_path == str(workspace.resolve())


def test_rename_updates_title(manager: SessionManager, workspace: Path):
    meta = manager.create("Old", str(workspace), model="m")
    manager.rename(meta.id, "New")
    assert manager.get(meta.id).title == "New"


def test_delete_removes_session_only(manager: SessionManager, workspace: Path):
    meta = manager.create("Doomed", str(workspace), model="m")
    sdir = manager.session_dir(meta.id)
    assert sdir.exists()
    (workspace / "untouched.txt").write_text("keep me", encoding="utf-8")
    manager.delete(meta.id)
    assert not sdir.exists()
    assert (workspace / "untouched.txt").exists()  # workspace not deleted
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_session_manager.py -v
```

- [ ] **Step 3: Implement `agent/session_manager.py`**

```python
"""Per-session directory manager. Each session has its own dir with meta/SOUL/MEMORY/state.db/skills."""
import json
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path

from agent.models import SessionMeta, SessionStats
from utils.encoding import safe_read_text


class SessionManager:
    def __init__(self, sessions_dir: Path, templates_dir: Path) -> None:
        self.sessions_dir = Path(sessions_dir)
        self.templates_dir = Path(templates_dir)
        self.sessions_dir.mkdir(parents=True, exist_ok=True)

    def session_dir(self, sid: str) -> Path:
        safe = "".join(c for c in sid if c.isalnum() or c in "-_")
        return self.sessions_dir / safe

    # ── CRUD ───────────────────────────────────────────────

    def create(self, title: str, workspace_path: str, model: str) -> SessionMeta:
        ws = Path(workspace_path).expanduser().resolve()
        if not ws.exists() or not ws.is_dir():
            raise ValueError(f"workspace_path does not exist or is not a directory: {workspace_path}")

        sid = f"sess_{uuid.uuid4().hex[:12]}"
        sdir = self.session_dir(sid)
        sdir.mkdir(parents=True, exist_ok=False)

        # Copy templates
        for name in ("SOUL.md", "MEMORY.md"):
            src = self.templates_dir / name
            dst = sdir / name
            dst.write_text(safe_read_text(src) if src.exists() else f"# {name}", encoding="utf-8")

        # Skills directory + empty snapshot
        (sdir / "skills").mkdir()
        (sdir / "skills" / "SKILLS_SNAPSHOT.md").write_text("# Skills Snapshot\n\nNo skills yet.\n", encoding="utf-8")

        # Loaded skills tracker
        (sdir / "loaded_skills.json").write_text("[]", encoding="utf-8")

        meta = SessionMeta(
            id=sid,
            title=title,
            workspace_path=str(ws),
            model=model,
            stats=SessionStats(),
        )
        self._write_meta(meta)
        return meta

    def get(self, sid: str) -> SessionMeta:
        path = self.session_dir(sid) / "meta.json"
        if not path.exists():
            raise FileNotFoundError(f"Session {sid} not found")
        return SessionMeta.model_validate_json(safe_read_text(path))

    def list(self) -> list[SessionMeta]:
        out: list[SessionMeta] = []
        for sdir in sorted(self.sessions_dir.iterdir()):
            if not sdir.is_dir() or sdir.name.startswith("."):
                continue
            mp = sdir / "meta.json"
            if not mp.exists():
                continue
            try:
                out.append(SessionMeta.model_validate_json(safe_read_text(mp)))
            except Exception:
                continue
        out.sort(key=lambda m: m.updated_at, reverse=True)
        return out

    def rename(self, sid: str, title: str) -> SessionMeta:
        meta = self.get(sid)
        meta.title = title
        meta.updated_at = datetime.now(timezone.utc).isoformat(timespec="microseconds")
        self._write_meta(meta)
        return meta

    def delete(self, sid: str) -> None:
        sdir = self.session_dir(sid)
        if sdir.exists():
            shutil.rmtree(sdir)

    def touch(self, sid: str) -> None:
        meta = self.get(sid)
        meta.updated_at = datetime.now(timezone.utc).isoformat(timespec="microseconds")
        self._write_meta(meta)

    def update_stats(self, sid: str, **delta: int) -> None:
        meta = self.get(sid)
        for k, v in delta.items():
            cur = getattr(meta.stats, k, 0)
            setattr(meta.stats, k, cur + v)
        meta.updated_at = datetime.now(timezone.utc).isoformat(timespec="microseconds")
        self._write_meta(meta)

    # ── helpers ────────────────────────────────────────────

    def _write_meta(self, meta: SessionMeta) -> None:
        path = self.session_dir(meta.id) / "meta.json"
        path.write_text(meta.model_dump_json(indent=2), encoding="utf-8")
```

- [ ] **Step 4: Run, expect 6 PASS**

```bash
.venv/Scripts/pytest tests/test_session_manager.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/agent/session_manager.py backend/tests/test_session_manager.py
git commit -m "feat(backend): SessionManager with per-session directory layout"
```

---

## Phase 2 — Workspace File Operations

### Task 2.1: Workspace tree builder

**Files:**
- Create: `FF-OpenHermes/backend/agent/workspace.py`
- Create: `FF-OpenHermes/backend/tests/test_workspace.py`

Mirrors fufan-cc-flow's `FileService.getTree`/`readDir`.

- [ ] **Step 1: Write failing tests**

`backend/tests/test_workspace.py`:

```python
"""Tests for workspace file operations."""
from pathlib import Path

import pytest

from agent.workspace import WorkspaceOps


@pytest.fixture
def ws(tmp_path: Path) -> WorkspaceOps:
    root = tmp_path / "proj"
    root.mkdir()
    (root / "src").mkdir()
    (root / "src" / "main.py").write_text("print('hi')\n", encoding="utf-8")
    (root / "README.md").write_text("# Test\n", encoding="utf-8")
    (root / "node_modules").mkdir()
    (root / "node_modules" / "junk.js").write_text("x", encoding="utf-8")
    (root / ".git").mkdir()
    (root / ".git" / "HEAD").write_text("x", encoding="utf-8")
    return WorkspaceOps(root)


def test_tree_excludes_node_modules_and_git(ws: WorkspaceOps):
    tree = ws.tree()
    names = [c["name"] for c in tree["children"]]
    assert "src" in names
    assert "README.md" in names
    assert "node_modules" not in names
    assert ".git" not in names


def test_tree_directories_first(ws: WorkspaceOps):
    tree = ws.tree()
    types = [c["type"] for c in tree["children"]]
    # Find first file index — every dir must come before it
    first_file = next((i for i, t in enumerate(types) if t == "file"), len(types))
    assert all(t == "directory" for t in types[:first_file])


def test_read_file(ws: WorkspaceOps):
    res = ws.read_file("src/main.py")
    assert res["content"] == "print('hi')\n"
    assert res["language"] == "python"


def test_read_file_blocks_escape(ws: WorkspaceOps):
    with pytest.raises(ValueError, match="escapes"):
        ws.read_file("../escape.txt")


def test_write_file_creates_parent_dirs(ws: WorkspaceOps):
    ws.write_file("docs/notes/a.md", "# Hi")
    assert (ws.root / "docs" / "notes" / "a.md").read_text(encoding="utf-8") == "# Hi"


def test_mkdir_rename_delete(ws: WorkspaceOps):
    ws.mkdir("foo")
    assert (ws.root / "foo").is_dir()
    ws.rename("foo", "bar")
    assert (ws.root / "bar").is_dir()
    assert not (ws.root / "foo").exists()
    ws.delete("bar")
    assert not (ws.root / "bar").exists()


def test_delete_outside_root_blocked(ws: WorkspaceOps):
    with pytest.raises(ValueError):
        ws.delete("../README.md")
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_workspace.py -v
```

- [ ] **Step 3: Implement `agent/workspace.py`**

```python
"""Workspace file operations bound to a session's workspace_path."""
from pathlib import Path
from typing import Any

from utils.encoding import safe_read_text
from utils.paths import resolve_in

EXCLUDE_DIRS = {
    "node_modules", ".git", ".next", "dist", "build", ".cache",
    ".vscode", "__pycache__", ".DS_Store", "coverage", ".venv", "venv",
    ".pytest_cache",
}

LANG_MAP = {
    ".ts": "typescript", ".tsx": "tsx", ".js": "javascript", ".jsx": "jsx",
    ".py": "python", ".rs": "rust", ".go": "go", ".java": "java",
    ".c": "c", ".cpp": "cpp", ".h": "c", ".css": "css", ".scss": "scss",
    ".html": "html", ".json": "json", ".yaml": "yaml", ".yml": "yaml",
    ".md": "markdown", ".sh": "bash", ".sql": "sql", ".xml": "xml",
    ".toml": "toml",
}


class WorkspaceOps:
    def __init__(self, root: Path | str) -> None:
        self.root = Path(root).resolve()
        if not self.root.is_dir():
            raise ValueError(f"workspace root does not exist or is not a dir: {root}")

    # ── tree ───────────────────────────────────────────────

    def tree(self, rel_path: str = ".", max_depth: int = 3) -> dict[str, Any]:
        target = resolve_in(self.root, rel_path)
        return self._node(target, max_depth)

    def _node(self, p: Path, depth: int) -> dict[str, Any]:
        rel = str(p.relative_to(self.root)).replace("\\", "/")
        if p.is_file():
            stat = p.stat()
            return {
                "name": p.name,
                "path": rel if rel != "." else "",
                "type": "file",
                "size": stat.st_size,
            }
        children = []
        if depth > 0:
            try:
                entries = list(p.iterdir())
            except PermissionError:
                entries = []
            for e in entries:
                if e.name in EXCLUDE_DIRS:
                    continue
                if e.name.startswith(".") and e.name not in (".env",):
                    continue
                children.append(self._node(e, depth - 1))
            children.sort(key=lambda n: (n["type"] != "directory", n["name"].lower()))
        return {
            "name": p.name if rel != "." else self.root.name,
            "path": rel if rel != "." else "",
            "type": "directory",
            "children": children,
        }

    # ── file ops ───────────────────────────────────────────

    def read_file(self, rel: str) -> dict[str, Any]:
        target = resolve_in(self.root, rel)
        if not target.is_file():
            raise FileNotFoundError(f"not a file: {rel}")
        content = safe_read_text(target)
        ext = target.suffix.lower()
        return {
            "content": content,
            "language": LANG_MAP.get(ext, "plaintext"),
            "lines": content.count("\n") + 1,
            "size": target.stat().st_size,
        }

    def write_file(self, rel: str, content: str) -> None:
        target = resolve_in(self.root, rel)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")

    def mkdir(self, rel: str) -> None:
        target = resolve_in(self.root, rel)
        target.mkdir(parents=True, exist_ok=True)

    def rename(self, rel_from: str, rel_to: str) -> None:
        src = resolve_in(self.root, rel_from)
        dst = resolve_in(self.root, rel_to)
        src.rename(dst)

    def delete(self, rel: str) -> None:
        target = resolve_in(self.root, rel)
        if target.is_dir():
            import shutil
            shutil.rmtree(target)
        elif target.exists():
            target.unlink()
```

- [ ] **Step 4: Run, expect 7 PASS**

```bash
.venv/Scripts/pytest tests/test_workspace.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/agent/workspace.py backend/tests/test_workspace.py
git commit -m "feat(backend): workspace tree + file CRUD bound to session root"
```

---

### Task 2.2: Filesystem browse (for NewSessionModal directory picker)

**Files:**
- Create: `FF-OpenHermes/backend/agent/fs_browse.py`
- Create: `FF-OpenHermes/backend/tests/test_fs_browse.py`

This is the **only** API that's NOT bound to a session — it's used to pick a directory before the session is created. Restrict to listing dirs (not file contents) and return only directories + drive letters on Windows.

- [ ] **Step 1: Write failing test**

`backend/tests/test_fs_browse.py`:

```python
"""Tests for fs_browse used by NewSessionModal directory picker."""
import sys
from pathlib import Path

import pytest

from agent.fs_browse import browse, list_drives


def test_browse_lists_dirs_only(tmp_path: Path):
    (tmp_path / "a").mkdir()
    (tmp_path / "b").mkdir()
    (tmp_path / "f.txt").write_text("x")
    items = browse(str(tmp_path))
    names = [it["name"] for it in items["entries"]]
    assert "a" in names
    assert "b" in names
    assert "f.txt" not in names


def test_browse_returns_parent(tmp_path: Path):
    sub = tmp_path / "sub"
    sub.mkdir()
    res = browse(str(sub))
    # browse() normalizes to forward slashes for cross-platform frontend consumption
    assert res["parent"] == str(tmp_path.resolve()).replace("\\", "/")


def test_browse_root_no_parent(tmp_path: Path):
    res = browse(str(tmp_path))  # not actual root, but our impl walks up
    assert "parent" in res


@pytest.mark.skipif(sys.platform != "win32", reason="windows only")
def test_list_drives_windows():
    drives = list_drives()
    assert any(d.endswith(":\\") or d.endswith(":/") for d in drives)
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_fs_browse.py -v
```

- [ ] **Step 3: Implement `agent/fs_browse.py`**

```python
"""Filesystem browser for the new-session directory picker."""
import os
import string
import sys
from pathlib import Path
from typing import Any


def list_drives() -> list[str]:
    """Windows: return drive letters like ['C:/', 'D:/']. Other: ['/']."""
    if sys.platform != "win32":
        return ["/"]
    drives: list[str] = []
    for letter in string.ascii_uppercase:
        root = f"{letter}:/"
        if os.path.exists(root):
            drives.append(root)
    return drives


def browse(path: str) -> dict[str, Any]:
    """List sub-directories of `path`. Returns entries + parent + cwd."""
    p = Path(path).expanduser().resolve()
    if not p.exists() or not p.is_dir():
        raise ValueError(f"not a directory: {path}")

    entries: list[dict[str, Any]] = []
    try:
        for child in p.iterdir():
            if not child.is_dir():
                continue
            if child.name.startswith(".") and child.name not in (".claude",):
                continue
            entries.append({
                "name": child.name,
                "path": str(child).replace("\\", "/"),
            })
    except PermissionError:
        pass
    entries.sort(key=lambda e: e["name"].lower())

    parent = str(p.parent).replace("\\", "/") if p.parent != p else None
    return {
        "cwd": str(p).replace("\\", "/"),
        "parent": parent,
        "entries": entries,
    }
```

- [ ] **Step 4: Run, expect PASS (3 or 4 depending on platform)**

```bash
.venv/Scripts/pytest tests/test_fs_browse.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/agent/fs_browse.py backend/tests/test_fs_browse.py
git commit -m "feat(backend): fs_browse for new-session directory picker"
```

---

### Task 2.3: Memory file operations (SOUL/MEMORY)

**Files:**
- Create: `FF-OpenHermes/backend/agent/memory_ops.py`
- Create: `FF-OpenHermes/backend/tests/test_memory_ops.py`

These read/write the SOUL.md and MEMORY.md *inside* `sessions/{sid}/` (NOT in workspace_path).

- [ ] **Step 1: Write failing test**

`backend/tests/test_memory_ops.py`:

```python
"""Tests for SOUL/MEMORY file operations."""
from pathlib import Path

import pytest

from agent.memory_ops import MemoryOps


@pytest.fixture
def ops(tmp_path: Path) -> MemoryOps:
    sdir = tmp_path / "sess_x"
    sdir.mkdir()
    (sdir / "SOUL.md").write_text("# Soul", encoding="utf-8")
    (sdir / "MEMORY.md").write_text("# Memory", encoding="utf-8")
    return MemoryOps(sdir)


def test_read_soul(ops: MemoryOps):
    assert ops.read_soul().startswith("# Soul")


def test_write_soul_persists(ops: MemoryOps):
    ops.write_soul("new soul")
    assert ops.read_soul() == "new soul"


def test_read_memory(ops: MemoryOps):
    assert ops.read_memory().startswith("# Memory")


def test_write_memory_creates_backup(ops: MemoryOps):
    ops.write_memory("v1")
    ops.write_memory("v2")
    assert (ops.session_dir / "MEMORY.md.bak").exists()
    assert (ops.session_dir / "MEMORY.md.bak").read_text(encoding="utf-8") == "v1"


def test_token_count():
    # rough: 1 token ~ 4 chars for English. Just check it returns int.
    from agent.memory_ops import approx_tokens
    assert approx_tokens("hello world") > 0
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_memory_ops.py -v
```

- [ ] **Step 3: Implement `agent/memory_ops.py`**

```python
"""SOUL.md / MEMORY.md operations for a session."""
from pathlib import Path

from utils.encoding import safe_read_text


def approx_tokens(s: str) -> int:
    """Cheap token estimate: 1 token ≈ 4 chars for English, 1.5 chars for CJK."""
    if not s:
        return 0
    cjk = sum(1 for c in s if "一" <= c <= "鿿")
    other = len(s) - cjk
    return int(cjk / 1.5 + other / 4)


class MemoryOps:
    def __init__(self, session_dir: Path) -> None:
        self.session_dir = Path(session_dir)
        self.soul = self.session_dir / "SOUL.md"
        self.memory = self.session_dir / "MEMORY.md"

    def read_soul(self) -> str:
        return safe_read_text(self.soul) if self.soul.exists() else ""

    def write_soul(self, content: str) -> None:
        self._backup_then_write(self.soul, content)

    def read_memory(self) -> str:
        return safe_read_text(self.memory) if self.memory.exists() else ""

    def write_memory(self, content: str) -> None:
        self._backup_then_write(self.memory, content)

    def stats(self) -> dict[str, int]:
        return {
            "soul_tokens": approx_tokens(self.read_soul()),
            "memory_tokens": approx_tokens(self.read_memory()),
        }

    def _backup_then_write(self, p: Path, content: str) -> None:
        if p.exists():
            (p.parent / f"{p.name}.bak").write_text(safe_read_text(p), encoding="utf-8")
        p.write_text(content, encoding="utf-8")
```

- [ ] **Step 4: Run, expect 5 PASS**

```bash
.venv/Scripts/pytest tests/test_memory_ops.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/agent/memory_ops.py backend/tests/test_memory_ops.py
git commit -m "feat(backend): SOUL/MEMORY file ops with .bak protection"
```

---

### Task 2.4: Skills scanner + loaded-skills tracker

**Files:**
- Create: `FF-OpenHermes/backend/agent/skill_ops.py`
- Create: `FF-OpenHermes/backend/tests/test_skill_ops.py`

Generates `SKILLS_SNAPSHOT.md` and tracks per-session loaded skills.

- [ ] **Step 1: Write failing test**

`backend/tests/test_skill_ops.py`:

```python
"""Tests for skill scanning + loaded-skills tracker."""
from pathlib import Path

import pytest

from agent.skill_ops import SkillOps


@pytest.fixture
def ops(tmp_path: Path) -> SkillOps:
    sdir = tmp_path / "sess"
    (sdir / "skills" / "weather-query").mkdir(parents=True)
    (sdir / "skills" / "weather-query" / "SKILL.md").write_text(
        "---\nname: weather-query\ndescription: Query weather. Use when user asks about weather.\nversion: 1.0\n---\n\n# Weather Query\n",
        encoding="utf-8",
    )
    (sdir / "loaded_skills.json").write_text("[]", encoding="utf-8")
    return SkillOps(sdir)


def test_list_skills(ops: SkillOps):
    skills = ops.list_skills()
    assert len(skills) == 1
    assert skills[0]["name"] == "weather-query"
    assert skills[0]["version"] == "1.0"


def test_read_skill(ops: SkillOps):
    body = ops.read_skill("weather-query")
    assert "Weather Query" in body


def test_write_skill_creates_dir_and_history(ops: SkillOps):
    md = "---\nname: new-skill\ndescription: A new skill. Use when testing.\nversion: 1.0\n---\n\n# New Skill\n"
    ops.write_skill("new-skill", md, history_line="Initial version")
    assert (ops.skills_dir / "new-skill" / "SKILL.md").exists()
    assert "Initial version" in (ops.skills_dir / "new-skill" / "HISTORY.md").read_text(encoding="utf-8")


def test_load_unload(ops: SkillOps):
    ops.load("weather-query", level=1)
    assert ops.is_loaded("weather-query")
    loaded = ops.list_loaded()
    assert loaded[0]["name"] == "weather-query"
    assert loaded[0]["level"] == 1
    ops.unload("weather-query")
    assert not ops.is_loaded("weather-query")


def test_snapshot_renders(ops: SkillOps):
    snap = ops.rebuild_snapshot()
    assert "weather-query" in snap
    assert "Use when user asks about weather" in snap
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_skill_ops.py -v
```

- [ ] **Step 3: Implement `agent/skill_ops.py`**

```python
"""Skill operations — scan, read, write, load/unload."""
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from utils.encoding import safe_read_text

FRONTMATTER_RE = re.compile(r"^---\n(.+?)\n---\n", re.DOTALL)


def parse_frontmatter(md: str) -> dict[str, str]:
    """Naive YAML frontmatter parser — sufficient for our SKILL.md format."""
    m = FRONTMATTER_RE.match(md)
    if not m:
        return {}
    data: dict[str, str] = {}
    for line in m.group(1).splitlines():
        if ":" in line:
            k, _, v = line.partition(":")
            data[k.strip()] = v.strip().strip('"').strip("'")
    return data


class SkillOps:
    def __init__(self, session_dir: Path) -> None:
        self.session_dir = Path(session_dir)
        self.skills_dir = self.session_dir / "skills"
        self.skills_dir.mkdir(parents=True, exist_ok=True)
        self.loaded_path = self.session_dir / "loaded_skills.json"

    # ── list / read ────────────────────────────────────────

    def list_skills(self) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for sd in sorted(self.skills_dir.iterdir()):
            if not sd.is_dir():
                continue
            md = sd / "SKILL.md"
            if not md.exists():
                continue
            content = safe_read_text(md)
            fm = parse_frontmatter(content)
            out.append({
                "name": sd.name,
                "description": fm.get("description", ""),
                "version": fm.get("version", "1.0"),
                "generated_by": fm.get("generated_by", "manual"),
                "created_at": fm.get("created_at", ""),
            })
        return out

    def read_skill(self, name: str) -> str:
        md = self.skills_dir / name / "SKILL.md"
        if not md.exists():
            raise FileNotFoundError(f"skill {name} not found")
        return safe_read_text(md)

    def read_history(self, name: str) -> str:
        h = self.skills_dir / name / "HISTORY.md"
        return safe_read_text(h) if h.exists() else ""

    # ── write ──────────────────────────────────────────────

    def write_skill(self, name: str, content: str, history_line: str | None = None) -> None:
        sdir = self.skills_dir / name
        sdir.mkdir(parents=True, exist_ok=True)
        (sdir / "SKILL.md").write_text(content, encoding="utf-8")
        if history_line:
            self._append_history(name, history_line)
        self.rebuild_snapshot()

    def delete_skill(self, name: str) -> None:
        import shutil
        d = self.skills_dir / name
        if d.exists():
            shutil.rmtree(d)
        self.unload(name)
        self.rebuild_snapshot()

    def _append_history(self, name: str, line: str) -> None:
        h = self.skills_dir / name / "HISTORY.md"
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M")
        entry = f"\n## {ts}\n{line}\n"
        if h.exists():
            existing = safe_read_text(h)
            h.write_text(existing + entry, encoding="utf-8")
        else:
            h.write_text(f"# Evolution History · {name}\n{entry}", encoding="utf-8")

    # ── snapshot ───────────────────────────────────────────

    def rebuild_snapshot(self) -> str:
        skills = self.list_skills()
        lines = ["# Skills Snapshot\n"]
        if not skills:
            lines.append("\nNo skills yet.\n")
        else:
            lines.append("\nAvailable skills (use `read_skill('<name>')` to load full content):\n")
            for s in skills:
                lines.append(f"- **{s['name']}** (v{s['version']}) — {s['description']}")
        snap = "\n".join(lines) + "\n"
        (self.skills_dir / "SKILLS_SNAPSHOT.md").write_text(snap, encoding="utf-8")
        return snap

    # ── loaded tracker ─────────────────────────────────────

    def list_loaded(self) -> list[dict[str, Any]]:
        if not self.loaded_path.exists():
            return []
        try:
            return json.loads(safe_read_text(self.loaded_path))
        except json.JSONDecodeError:
            return []

    def is_loaded(self, name: str) -> bool:
        return any(it["name"] == name for it in self.list_loaded())

    def load(self, name: str, level: int = 1) -> None:
        loaded = self.list_loaded()
        loaded = [it for it in loaded if it["name"] != name]
        loaded.append({"name": name, "level": level})
        self.loaded_path.write_text(json.dumps(loaded, ensure_ascii=False, indent=2), encoding="utf-8")

    def unload(self, name: str) -> None:
        loaded = [it for it in self.list_loaded() if it["name"] != name]
        self.loaded_path.write_text(json.dumps(loaded, ensure_ascii=False, indent=2), encoding="utf-8")
```

- [ ] **Step 4: Run, expect 5 PASS**

```bash
.venv/Scripts/pytest tests/test_skill_ops.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/agent/skill_ops.py backend/tests/test_skill_ops.py
git commit -m "feat(backend): skill scanner, snapshot builder, loaded-skills tracker"
```

---

## Phase 3 — Tools Migration & Workspace Binding

### Task 3.1: Port terminal_tool with workspace cwd

**Files:**
- Create: `FF-OpenHermes/backend/tools/terminal_tool.py`
- Create: `FF-OpenHermes/backend/tests/test_terminal_tool.py`

Port mini-OpenClaw's `tools/terminal_tool.py` but accept a per-call `cwd` (the session's workspace_path) rather than baking it at construction time. The blacklist stays the same.

- [ ] **Step 1: Write failing test**

`backend/tests/test_terminal_tool.py`:

```python
"""Tests for terminal tool with workspace cwd."""
import sys
from pathlib import Path

import pytest

from tools.terminal_tool import create_terminal_tool


def test_terminal_runs_in_cwd(tmp_path: Path):
    (tmp_path / "marker.txt").write_text("yes", encoding="utf-8")
    tool = create_terminal_tool(workspace=tmp_path)
    if sys.platform == "win32":
        out = tool.invoke({"command": "dir"})
    else:
        out = tool.invoke({"command": "ls"})
    assert "marker.txt" in out


def test_blacklist_blocks(tmp_path: Path):
    tool = create_terminal_tool(workspace=tmp_path)
    out = tool.invoke({"command": "rm -rf /"})
    assert "blocked" in out.lower()


def test_timeout_returns_message(tmp_path: Path):
    tool = create_terminal_tool(workspace=tmp_path)
    if sys.platform == "win32":
        out = tool.invoke({"command": "ping -n 60 127.0.0.1"})
    else:
        out = tool.invoke({"command": "sleep 60"})
    # Either timed out or completed (in some CI envs ping is fast)
    assert "timed out" in out.lower() or "127.0.0.1" in out.lower()
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_terminal_tool.py -v
```

- [ ] **Step 3: Implement `tools/terminal_tool.py`**

```python
"""SafeTerminalTool — port of mini-OpenClaw with per-session workspace cwd."""
import subprocess
import sys
from pathlib import Path
from typing import Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field, ConfigDict

BLACKLISTED = [
    "rm -rf /", "rm -rf /*", "mkfs", "dd if=", ":(){:|:&};:",
    "chmod -R 777 /", "shutdown", "reboot", "halt", "poweroff",
    "format c:", "del /f /s /q c:",
]


class TerminalInput(BaseModel):
    command: str = Field(description="The shell command to execute")


class SafeTerminalTool(BaseTool):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    name: str = "terminal"
    description: str = (
        "Execute shell commands. Working directory is the current session's workspace. "
        "On Windows, runs in cmd.exe with chcp 65001 for UTF-8 output."
    )
    args_schema: Type[BaseModel] = TerminalInput
    workspace: Path

    def _is_safe(self, cmd: str) -> bool:
        low = cmd.lower().strip()
        return not any(b in low for b in BLACKLISTED)

    def _run(self, command: str) -> str:
        if not self._is_safe(command):
            return f"Command blocked for safety: {command}"
        try:
            is_win = sys.platform == "win32"
            if is_win:
                wrapped = f"chcp 65001 >nul 2>&1 && {command}"
                r = subprocess.run(wrapped, shell=True, cwd=str(self.workspace),
                                   capture_output=True, timeout=30)
                stdout = self._decode(r.stdout)
                stderr = self._decode(r.stderr)
            else:
                r = subprocess.run(command, shell=True, cwd=str(self.workspace),
                                   capture_output=True, text=True, timeout=30,
                                   encoding="utf-8", errors="replace")
                stdout, stderr = r.stdout, r.stderr
            out = stdout
            if stderr:
                out += f"\n[stderr]: {stderr}"
            if not out.strip():
                out = "(command completed with no output)"
            if len(out) > 5000:
                out = out[:5000] + "\n...[truncated]"
            return out
        except subprocess.TimeoutExpired:
            return "Command timed out (30s limit)"
        except Exception as e:
            return f"Error: {e}"

    @staticmethod
    def _decode(raw: bytes) -> str:
        if not raw:
            return ""
        for enc in ("utf-8", "gbk"):
            try:
                return raw.decode(enc)
            except UnicodeDecodeError:
                continue
        return raw.decode("latin-1", errors="replace")


def create_terminal_tool(workspace: Path) -> SafeTerminalTool:
    return SafeTerminalTool(workspace=Path(workspace))
```

- [ ] **Step 4: Run, expect 3 PASS**

```bash
.venv/Scripts/pytest tests/test_terminal_tool.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/tools/terminal_tool.py backend/tests/test_terminal_tool.py
git commit -m "feat(backend): terminal tool with workspace cwd binding"
```

---

### Task 3.2: Port python_repl, fetch_url, search tools

**Files:**
- Create: `FF-OpenHermes/backend/tools/python_repl_tool.py` (copy verbatim from mini-OpenClaw — no workspace binding needed since it's an in-process REPL)
- Create: `FF-OpenHermes/backend/tools/fetch_url_tool.py`
- Create: `FF-OpenHermes/backend/tools/search_tool.py`

- [ ] **Step 1: Copy `python_repl_tool.py`** from `260205mini-OpenClaw开发实战/mini-OpenClaw/backend/tools/python_repl_tool.py` verbatim. No changes.

- [ ] **Step 2: Implement `fetch_url_tool.py`**

```python
"""FetchUrlTool — fetch a URL and return Markdown."""
from typing import Type

import html2text
import requests
from bs4 import BeautifulSoup
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field


class FetchUrlInput(BaseModel):
    url: str = Field(description="The URL to fetch")


class FetchUrlTool(BaseTool):
    name: str = "fetch_url"
    description: str = "Fetch a URL and return its content as Markdown."
    args_schema: Type[BaseModel] = FetchUrlInput

    def _run(self, url: str) -> str:
        try:
            r = requests.get(url, timeout=15, headers={"User-Agent": "FF-OpenHermes/0.1"})
            r.raise_for_status()
            soup = BeautifulSoup(r.text, "html.parser")
            for tag in soup(["script", "style", "noscript"]):
                tag.decompose()
            h = html2text.HTML2Text()
            h.ignore_links = False
            h.body_width = 0
            md = h.handle(str(soup))
            return md[:8000] + ("\n...[truncated]" if len(md) > 8000 else "")
        except Exception as e:
            return f"Error fetching {url}: {e}"


def create_fetch_url_tool() -> FetchUrlTool:
    return FetchUrlTool()
```

- [ ] **Step 3: Implement `search_tool.py`** (port mini-OpenClaw's tavily wrapper, gated on `TAVILY_API_KEY`)

```python
"""Web search tool via Tavily — gated on TAVILY_API_KEY env var."""
import os
from typing import Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field


class SearchInput(BaseModel):
    query: str = Field(description="Search query")


class WebSearchTool(BaseTool):
    name: str = "search_web"
    description: str = (
        "Search the web for up-to-date information. Returns top 5 results with title, URL, snippet."
    )
    args_schema: Type[BaseModel] = SearchInput

    def _run(self, query: str) -> str:
        api_key = os.getenv("TAVILY_API_KEY")
        if not api_key:
            return "TAVILY_API_KEY not configured. Web search unavailable in this session."
        try:
            from tavily import TavilyClient
            client = TavilyClient(api_key=api_key)
            res = client.search(query, max_results=5)
            lines = [f"Search results for: {query}\n"]
            for i, item in enumerate(res.get("results", []), 1):
                lines.append(f"{i}. {item.get('title', '')}")
                lines.append(f"   {item.get('url', '')}")
                lines.append(f"   {item.get('content', '')[:300]}\n")
            return "\n".join(lines) if len(lines) > 1 else "No results."
        except Exception as e:
            return f"Search error: {e}"


def create_search_tool() -> WebSearchTool:
    return WebSearchTool()
```

- [ ] **Step 4: Smoke-test fetch_url**

```bash
.venv/Scripts/python -c "from tools.fetch_url_tool import create_fetch_url_tool; t = create_fetch_url_tool(); print(t.invoke({'url': 'https://example.com'})[:200])"
```

Expected: ~200 chars of example.com markdown. If network fails, that's acceptable in offline tests — the unit tests cover it.

- [ ] **Step 5: Commit**

```bash
git add backend/tools/python_repl_tool.py backend/tools/fetch_url_tool.py backend/tools/search_tool.py
git commit -m "feat(backend): port python_repl, fetch_url, search tools"
```

---

### Task 3.3: read_file / write_file tools bound to workspace

**Files:**
- Create: `FF-OpenHermes/backend/tools/file_tool.py`
- Create: `FF-OpenHermes/backend/tests/test_file_tool.py`

- [ ] **Step 1: Write failing test**

`backend/tests/test_file_tool.py`:

```python
"""Tests for file_tool bound to workspace."""
from pathlib import Path

import pytest

from tools.file_tool import create_read_file_tool, create_write_file_tool


def test_read_in_workspace(tmp_path: Path):
    (tmp_path / "a.txt").write_text("hello", encoding="utf-8")
    tool = create_read_file_tool(workspace=tmp_path)
    out = tool.invoke({"file_path": "a.txt"})
    assert out == "hello"


def test_read_blocks_escape(tmp_path: Path):
    (tmp_path.parent / "outside.txt").write_text("nope", encoding="utf-8")
    tool = create_read_file_tool(workspace=tmp_path)
    out = tool.invoke({"file_path": "../outside.txt"})
    assert "Access denied" in out or "escapes" in out


def test_write_creates_dirs(tmp_path: Path):
    tool = create_write_file_tool(workspace=tmp_path)
    tool.invoke({"file_path": "a/b/c.txt", "content": "yo"})
    assert (tmp_path / "a" / "b" / "c.txt").read_text(encoding="utf-8") == "yo"


def test_write_blocks_escape(tmp_path: Path):
    tool = create_write_file_tool(workspace=tmp_path)
    out = tool.invoke({"file_path": "../bad.txt", "content": "x"})
    assert "Access denied" in out or "escapes" in out
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_file_tool.py -v
```

- [ ] **Step 3: Implement `tools/file_tool.py`**

```python
"""File read/write tools sandboxed to a workspace path."""
from pathlib import Path
from typing import Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field, ConfigDict

from utils.encoding import safe_read_text
from utils.paths import resolve_in


class ReadInput(BaseModel):
    file_path: str = Field(description="Path relative to the workspace root")


class WriteInput(BaseModel):
    file_path: str = Field(description="Path relative to the workspace root")
    content: str = Field(description="Full text content to write")


class WorkspaceReadFileTool(BaseTool):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    name: str = "read_file"
    description: str = "Read a file from the current session's workspace. Path is relative to the workspace root."
    args_schema: Type[BaseModel] = ReadInput
    workspace: Path

    def _run(self, file_path: str) -> str:
        try:
            target = resolve_in(self.workspace, file_path)
        except ValueError:
            return f"Access denied: path escapes workspace root"
        if not target.exists():
            return f"File not found: {file_path}"
        if not target.is_file():
            return f"Not a file: {file_path}"
        c = safe_read_text(target)
        if len(c) > 10000:
            c = c[:10000] + "\n...[truncated]"
        return c


class WorkspaceWriteFileTool(BaseTool):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    name: str = "write_file"
    description: str = "Write text content to a file in the current session's workspace. Creates parent dirs as needed."
    args_schema: Type[BaseModel] = WriteInput
    workspace: Path

    def _run(self, file_path: str, content: str) -> str:
        try:
            target = resolve_in(self.workspace, file_path)
        except ValueError:
            return f"Access denied: path escapes workspace root"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return f"Wrote {len(content)} chars to {file_path}"


def create_read_file_tool(workspace: Path) -> WorkspaceReadFileTool:
    return WorkspaceReadFileTool(workspace=Path(workspace))


def create_write_file_tool(workspace: Path) -> WorkspaceWriteFileTool:
    return WorkspaceWriteFileTool(workspace=Path(workspace))
```

- [ ] **Step 4: Run, expect 4 PASS**

```bash
.venv/Scripts/pytest tests/test_file_tool.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/tools/file_tool.py backend/tests/test_file_tool.py
git commit -m "feat(backend): read_file/write_file tools sandboxed to workspace"
```

---

### Task 3.4: read_memory / write_memory tools

**Files:**
- Create: `FF-OpenHermes/backend/tools/memory_tool.py`
- Create: `FF-OpenHermes/backend/tests/test_memory_tool.py`

These operate on `sessions/{sid}/MEMORY.md` (NOT the workspace).

- [ ] **Step 1: Write failing test**

`backend/tests/test_memory_tool.py`:

```python
"""Tests for memory tools bound to session dir."""
from pathlib import Path

import pytest

from tools.memory_tool import create_read_memory_tool, create_write_memory_tool


def test_read_memory_returns_content(tmp_path: Path):
    (tmp_path / "MEMORY.md").write_text("# Memory\nfacts here", encoding="utf-8")
    tool = create_read_memory_tool(session_dir=tmp_path)
    out = tool.invoke({})
    assert "facts here" in out


def test_write_memory_appends(tmp_path: Path):
    (tmp_path / "MEMORY.md").write_text("# Memory\n", encoding="utf-8")
    tool = create_write_memory_tool(session_dir=tmp_path)
    tool.invoke({"entry": "User prefers concise answers."})
    content = (tmp_path / "MEMORY.md").read_text(encoding="utf-8")
    assert "User prefers concise answers." in content


def test_write_memory_creates_backup(tmp_path: Path):
    (tmp_path / "MEMORY.md").write_text("v1", encoding="utf-8")
    tool = create_write_memory_tool(session_dir=tmp_path)
    tool.invoke({"entry": "new entry"})
    assert (tmp_path / "MEMORY.md.bak").exists()
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_memory_tool.py -v
```

- [ ] **Step 3: Implement `tools/memory_tool.py`**

```python
"""Memory read/write tools — operate on the current session's MEMORY.md."""
from pathlib import Path
from typing import Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field, ConfigDict

from agent.memory_ops import MemoryOps


class WriteMemoryInput(BaseModel):
    entry: str = Field(description="Concise fact or instruction to remember (1-3 lines)")


class ReadMemoryInput(BaseModel):
    pass


class ReadMemoryTool(BaseTool):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    name: str = "read_memory"
    description: str = "Read the long-term memory (MEMORY.md) of the current session."
    args_schema: Type[BaseModel] = ReadMemoryInput
    session_dir: Path

    def _run(self) -> str:  # type: ignore[override]
        return MemoryOps(self.session_dir).read_memory()


class WriteMemoryTool(BaseTool):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    name: str = "write_memory"
    description: str = (
        "Append a new entry to MEMORY.md. Use this to remember user preferences, "
        "important facts, or context that future turns should know."
    )
    args_schema: Type[BaseModel] = WriteMemoryInput
    session_dir: Path

    def _run(self, entry: str) -> str:
        ops = MemoryOps(self.session_dir)
        cur = ops.read_memory()
        new = cur.rstrip() + f"\n- {entry.strip()}\n"
        ops.write_memory(new)
        return f"Memory updated (+{len(entry)} chars)"


def create_read_memory_tool(session_dir: Path) -> ReadMemoryTool:
    return ReadMemoryTool(session_dir=Path(session_dir))


def create_write_memory_tool(session_dir: Path) -> WriteMemoryTool:
    return WriteMemoryTool(session_dir=Path(session_dir))
```

- [ ] **Step 4: Run, expect 3 PASS**

```bash
.venv/Scripts/pytest tests/test_memory_tool.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/tools/memory_tool.py backend/tests/test_memory_tool.py
git commit -m "feat(backend): read_memory/write_memory tools"
```

---

### Task 3.5: read_skill tool + tools factory

**Files:**
- Create: `FF-OpenHermes/backend/tools/skill_tool.py`
- Create: `FF-OpenHermes/backend/tools/__init__.py` (overwrite the empty stub from Task 0.1)
- Create: `FF-OpenHermes/backend/tests/test_tools_factory.py`

- [ ] **Step 1: Write failing test**

`backend/tests/test_tools_factory.py`:

```python
"""Tests for the tools factory `get_session_tools`."""
from pathlib import Path

import pytest

from tools import get_session_tools


@pytest.fixture
def session_dirs(tmp_path: Path):
    sd = tmp_path / "sess"
    sd.mkdir()
    (sd / "MEMORY.md").write_text("# Memory", encoding="utf-8")
    (sd / "skills").mkdir()
    ws = tmp_path / "ws"
    ws.mkdir()
    return sd, ws


def test_factory_returns_expected_tools(session_dirs):
    sd, ws = session_dirs
    tools = get_session_tools(session_dir=sd, workspace=ws)
    names = sorted(t.name for t in tools)
    assert names == [
        "fetch_url", "python_repl", "read_file", "read_memory", "read_skill",
        "search_web", "terminal", "write_file", "write_memory",
    ]


def test_read_skill_tool_works(session_dirs):
    sd, ws = session_dirs
    (sd / "skills" / "demo").mkdir()
    (sd / "skills" / "demo" / "SKILL.md").write_text(
        "---\nname: demo\ndescription: demo skill\nversion: 1.0\n---\n# Demo\nbody",
        encoding="utf-8",
    )
    tools = get_session_tools(session_dir=sd, workspace=ws)
    rs = next(t for t in tools if t.name == "read_skill")
    out = rs.invoke({"name": "demo"})
    assert "Demo" in out


def test_read_skill_unknown_returns_message(session_dirs):
    sd, ws = session_dirs
    tools = get_session_tools(session_dir=sd, workspace=ws)
    rs = next(t for t in tools if t.name == "read_skill")
    out = rs.invoke({"name": "ghost"})
    assert "not found" in out.lower()
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_tools_factory.py -v
```

- [ ] **Step 3: Implement `tools/skill_tool.py`**

```python
"""read_skill tool — load a skill's full SKILL.md by name."""
from pathlib import Path
from typing import Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field, ConfigDict

from agent.skill_ops import SkillOps


class ReadSkillInput(BaseModel):
    name: str = Field(description="The skill name (folder name under skills/)")


class ReadSkillTool(BaseTool):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    name: str = "read_skill"
    description: str = (
        "Load the full content of a skill (SKILL.md). Use this when SKILLS_SNAPSHOT.md "
        "shows a skill that looks relevant to the current task."
    )
    args_schema: Type[BaseModel] = ReadSkillInput
    session_dir: Path

    def _run(self, name: str) -> str:
        try:
            return SkillOps(self.session_dir).read_skill(name)
        except FileNotFoundError:
            return f"Skill '{name}' not found in this session."


def create_read_skill_tool(session_dir: Path) -> ReadSkillTool:
    return ReadSkillTool(session_dir=Path(session_dir))
```

- [ ] **Step 4: Implement `tools/__init__.py`**

```python
"""Tools factory — returns all 9 tools bound to a session + workspace."""
from pathlib import Path
from typing import List

from langchain_core.tools import BaseTool

from .terminal_tool import create_terminal_tool
from .python_repl_tool import create_python_repl_tool
from .fetch_url_tool import create_fetch_url_tool
from .search_tool import create_search_tool
from .file_tool import create_read_file_tool, create_write_file_tool
from .memory_tool import create_read_memory_tool, create_write_memory_tool
from .skill_tool import create_read_skill_tool


def get_session_tools(session_dir: Path, workspace: Path) -> List[BaseTool]:
    """Create all 9 tools bound to a specific session + workspace."""
    return [
        create_terminal_tool(workspace=workspace),
        create_python_repl_tool(),
        create_fetch_url_tool(),
        create_search_tool(),
        create_read_file_tool(workspace=workspace),
        create_write_file_tool(workspace=workspace),
        create_read_memory_tool(session_dir=session_dir),
        create_write_memory_tool(session_dir=session_dir),
        create_read_skill_tool(session_dir=session_dir),
    ]
```

- [ ] **Step 5: Run, expect 3 PASS**

```bash
.venv/Scripts/pytest tests/test_tools_factory.py -v
```

- [ ] **Step 6: Run all tests so far**

```bash
.venv/Scripts/pytest -v
```

Expected: all green so far.

- [ ] **Step 7: Commit**

```bash
git add backend/tools/skill_tool.py backend/tools/__init__.py backend/tests/test_tools_factory.py
git commit -m "feat(backend): read_skill tool + per-session tools factory"
```

---

## Phase 4 — LangChain 1.x Agent Runtime

This is the highest-risk phase (per PRD §12). LangChain 1.x's `create_agent` API + `AsyncSqliteSaver` is not as well-documented as the 0.x ReAct executor — verify against `agent.astream(stream_mode=["messages","updates"])` events as you build.

### Task 4.1: LLM provider (OpenRouter via langchain-openai)

**Files:**
- Create: `FF-OpenHermes/backend/agent/llm.py`
- Create: `FF-OpenHermes/backend/tests/test_llm.py`

We use `langchain-openai`'s `ChatOpenAI` pointed at OpenRouter — this is simpler than `langchain-deepseek` and lets us swap models via env. **Critical:** for this user's region, use `deepseek/deepseek-chat-v3.1` (memory `openrouter_region_block`).

- [ ] **Step 1: Write failing test (offline — no API call)**

`backend/tests/test_llm.py`:

```python
"""Test LLM factory configures OpenRouter correctly without making network calls."""
from agent.llm import build_llm


def test_build_llm_uses_openrouter_base_url(monkeypatch):
    monkeypatch.setenv("OPENROUTER_API_KEY", "sk-test-xxx")
    monkeypatch.setenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1")
    monkeypatch.setenv("OPENROUTER_MODEL", "deepseek/deepseek-chat-v3.1")
    # Reload settings
    import importlib, config
    importlib.reload(config)

    from agent.llm import build_llm  # re-import so it picks new settings
    llm = build_llm()
    # ChatOpenAI exposes openai_api_base / model
    assert "openrouter.ai" in str(llm.openai_api_base)
    assert llm.model_name == "deepseek/deepseek-chat-v3.1"


def test_build_llm_raises_without_key(monkeypatch):
    monkeypatch.setenv("OPENROUTER_API_KEY", "")
    import importlib, config
    importlib.reload(config)
    from agent.llm import build_llm
    import pytest
    with pytest.raises(RuntimeError, match="OPENROUTER_API_KEY"):
        build_llm()
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_llm.py -v
```

- [ ] **Step 3: Implement `agent/llm.py`**

```python
"""LLM factory — OpenRouter via langchain-openai ChatOpenAI."""
from langchain_openai import ChatOpenAI

from config import settings


def build_llm(model: str | None = None, temperature: float = 0.7, streaming: bool = True) -> ChatOpenAI:
    """Build a LangChain ChatOpenAI configured for OpenRouter."""
    if not settings.OPENROUTER_API_KEY:
        raise RuntimeError("OPENROUTER_API_KEY is not set in .env")
    return ChatOpenAI(
        model=model or settings.OPENROUTER_MODEL,
        api_key=settings.OPENROUTER_API_KEY,
        base_url=settings.OPENROUTER_BASE_URL,
        temperature=temperature,
        streaming=streaming,
        default_headers={
            "HTTP-Referer": "http://localhost:3000",
            "X-Title": "FF-OpenHermes",
        },
    )
```

- [ ] **Step 4: Run, expect 2 PASS**

```bash
.venv/Scripts/pytest tests/test_llm.py -v
```

- [ ] **Step 5: Live smoke test (requires real key in .env)**

```bash
.venv/Scripts/python -c "
from agent.llm import build_llm
from langchain_core.messages import HumanMessage
llm = build_llm(streaming=False)
r = llm.invoke([HumanMessage(content='Say hi in 5 words')])
print(r.content)
"
```

Expected: a 5-word reply. If you get HTTP 403 — the model is region-blocked, switch `OPENROUTER_MODEL` to another one from the `openrouter_region_block` memory's working list.

- [ ] **Step 6: Commit**

```bash
git add backend/agent/llm.py backend/tests/test_llm.py
git commit -m "feat(backend): LLM factory via OpenRouter (deepseek-chat-v3.1)"
```

---

### Task 4.2: prompt_builder for per-session multi-layer system prompt

**Files:**
- Create: `FF-OpenHermes/backend/agent/prompt_builder.py`
- Create: `FF-OpenHermes/backend/tests/test_prompt_builder.py`

Layers (in order): `SOUL.md` → `MEMORY.md` → `SKILLS_SNAPSHOT.md` → loaded skills' full content → built-in protocol footer.

- [ ] **Step 1: Write failing test**

`backend/tests/test_prompt_builder.py`:

```python
"""Tests for prompt_builder."""
import json
from pathlib import Path

import pytest

from agent.prompt_builder import build_system_prompt


@pytest.fixture
def sdir(tmp_path: Path) -> Path:
    sd = tmp_path / "sess"
    sd.mkdir()
    (sd / "SOUL.md").write_text("SOUL CONTENT", encoding="utf-8")
    (sd / "MEMORY.md").write_text("MEMORY CONTENT", encoding="utf-8")
    (sd / "skills").mkdir()
    (sd / "skills" / "SKILLS_SNAPSHOT.md").write_text("SNAPSHOT CONTENT", encoding="utf-8")
    (sd / "skills" / "demo").mkdir()
    (sd / "skills" / "demo" / "SKILL.md").write_text("DEMO SKILL FULL CONTENT", encoding="utf-8")
    (sd / "loaded_skills.json").write_text(json.dumps([{"name": "demo", "level": 1}]), encoding="utf-8")
    return sd


def test_includes_all_layers(sdir: Path):
    p = build_system_prompt(sdir)
    assert "SOUL CONTENT" in p
    assert "MEMORY CONTENT" in p
    assert "SNAPSHOT CONTENT" in p
    assert "DEMO SKILL FULL CONTENT" in p


def test_layer_order(sdir: Path):
    p = build_system_prompt(sdir)
    soul_idx = p.index("SOUL CONTENT")
    mem_idx = p.index("MEMORY CONTENT")
    snap_idx = p.index("SNAPSHOT CONTENT")
    demo_idx = p.index("DEMO SKILL FULL CONTENT")
    assert soul_idx < mem_idx < snap_idx < demo_idx


def test_omits_skill_when_only_level_0(tmp_path: Path):
    sd = tmp_path / "sess"
    sd.mkdir()
    (sd / "SOUL.md").write_text("SOUL", encoding="utf-8")
    (sd / "MEMORY.md").write_text("MEM", encoding="utf-8")
    (sd / "skills").mkdir()
    (sd / "skills" / "SKILLS_SNAPSHOT.md").write_text("SNAP", encoding="utf-8")
    (sd / "skills" / "demo").mkdir()
    (sd / "skills" / "demo" / "SKILL.md").write_text("FULL", encoding="utf-8")
    (sd / "loaded_skills.json").write_text(json.dumps([{"name": "demo", "level": 0}]), encoding="utf-8")
    p = build_system_prompt(sd)
    assert "FULL" not in p  # level-0 doesn't inject full body


def test_protocol_footer_present(sdir: Path):
    p = build_system_prompt(sdir)
    assert "## Protocol" in p or "Protocol" in p
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_prompt_builder.py -v
```

- [ ] **Step 3: Implement `agent/prompt_builder.py`**

```python
"""Build the multi-layer system prompt for a session."""
import json
from pathlib import Path

from utils.encoding import safe_read_text

MAX_LAYER_CHARS = 20_000

PROTOCOL_FOOTER = """
## Protocol

- The user's working directory is the **workspace**. `terminal`, `python_repl`,
  `read_file`, `write_file` operate inside it.
- `MEMORY.md` is your long-term notebook. Use `write_memory` for facts that
  should survive across turns.
- `SKILLS_SNAPSHOT.md` lists available skills. If one looks relevant, call
  `read_skill('<name>')` to load its full content.
- Be concise. Cite tool results, don't paraphrase them.
"""


def _read(p: Path) -> str:
    if not p.exists():
        return ""
    c = safe_read_text(p)
    if len(c) > MAX_LAYER_CHARS:
        c = c[:MAX_LAYER_CHARS] + "\n...[truncated]"
    return c


def build_system_prompt(session_dir: Path) -> str:
    """Layered prompt: SOUL -> MEMORY -> SKILLS_SNAPSHOT -> loaded skills -> protocol."""
    sd = Path(session_dir)
    parts: list[str] = []

    soul = _read(sd / "SOUL.md")
    if soul:
        parts.append(f"<!-- Soul -->\n{soul}")

    memory = _read(sd / "MEMORY.md")
    if memory:
        parts.append(f"<!-- Memory -->\n{memory}")

    snap = _read(sd / "skills" / "SKILLS_SNAPSHOT.md")
    if snap:
        parts.append(f"<!-- Skills Snapshot (Level 0) -->\n{snap}")

    # Loaded skills at Level 1 — inject full content
    loaded_path = sd / "loaded_skills.json"
    if loaded_path.exists():
        try:
            loaded = json.loads(safe_read_text(loaded_path))
        except json.JSONDecodeError:
            loaded = []
        for item in loaded:
            if item.get("level") != 1:
                continue
            full = _read(sd / "skills" / item["name"] / "SKILL.md")
            if full:
                parts.append(f"<!-- Loaded Skill: {item['name']} (Level 1) -->\n{full}")

    parts.append(PROTOCOL_FOOTER.strip())
    return "\n\n".join(parts)
```

- [ ] **Step 4: Run, expect 4 PASS**

```bash
.venv/Scripts/pytest tests/test_prompt_builder.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/agent/prompt_builder.py backend/tests/test_prompt_builder.py
git commit -m "feat(backend): multi-layer prompt builder (Soul/Memory/Snapshot/Loaded skills)"
```

---

### Task 4.3: AgentManager — create_agent + AsyncSqliteSaver

**Files:**
- Create: `FF-OpenHermes/backend/agent/agent_manager.py`
- Create: `FF-OpenHermes/backend/tests/test_agent_manager.py`

Per the PRD architecture: each session has its own `state.db`. The agent is rebuilt on every chat call so we always read the latest SOUL/MEMORY/SKILL files.

- [ ] **Step 1: Write failing test using a fake LLM**

`backend/tests/test_agent_manager.py`:

```python
"""Tests for AgentManager runtime — uses a fake LLM."""
import json
from pathlib import Path

import pytest
from langchain_core.language_models.fake_chat_models import FakeListChatModel

from agent.agent_manager import AgentManager
from agent.session_manager import SessionManager


@pytest.fixture
def setup(tmp_path: Path):
    workspace = tmp_path / "ws"
    workspace.mkdir()
    sessions_dir = tmp_path / "sessions"
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    (templates_dir / "SOUL.md").write_text("# Soul\nYou are a test assistant.", encoding="utf-8")
    (templates_dir / "MEMORY.md").write_text("# Memory\n", encoding="utf-8")
    sm = SessionManager(sessions_dir=sessions_dir, templates_dir=templates_dir)
    meta = sm.create("Test", str(workspace), model="fake")
    return sm, meta


class ToolBindableFakeListChatModel(FakeListChatModel):
    """create_agent calls model.bind_tools(...) when tools list is non-empty.
    FakeListChatModel raises NotImplementedError for that — provide a no-op."""
    def bind_tools(self, tools, **kwargs):
        return self


@pytest.mark.asyncio
async def test_streaming_emits_token_and_done(setup):
    sm, meta = setup
    fake = ToolBindableFakeListChatModel(responses=["Hello user, this is a fake response."])
    mgr = AgentManager(session_manager=sm, llm_factory=lambda: fake)

    events: list[dict] = []
    async for ev in mgr.astream(meta.id, "Hi"):
        events.append(ev)

    types = [e["type"] for e in events]
    assert "turn_start" in types
    assert "turn_end" in types
    full = "".join(e["content"] for e in events if e["type"] == "assistant_token")
    assert "fake response" in full
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_agent_manager.py -v
```

- [ ] **Step 3: Implement `agent/agent_manager.py`**

```python
"""AgentManager — wraps LangChain create_agent + AsyncSqliteSaver per session."""
import uuid
from pathlib import Path
from typing import Any, AsyncGenerator, Callable

from langchain.agents import create_agent
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import HumanMessage
from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver

from agent.llm import build_llm
from agent.prompt_builder import build_system_prompt
from agent.session_manager import SessionManager
from tools import get_session_tools


class AgentManager:
    """Per-call agent builder. Each chat() builds a fresh agent so SOUL/MEMORY/SKILLS are re-read."""

    def __init__(
        self,
        session_manager: SessionManager,
        llm_factory: Callable[[], BaseChatModel] | None = None,
    ) -> None:
        self.sessions = session_manager
        self.llm_factory = llm_factory or build_llm

    async def astream(self, session_id: str, user_message: str) -> AsyncGenerator[dict[str, Any], None]:
        """Stream agent events for a single user turn."""
        meta = self.sessions.get(session_id)
        sdir = self.sessions.session_dir(session_id)
        workspace = Path(meta.workspace_path)

        turn_id = uuid.uuid4().hex[:8]
        yield {"type": "turn_start", "turn_id": turn_id}

        system_prompt = build_system_prompt(sdir)
        tools = get_session_tools(session_dir=sdir, workspace=workspace)
        llm = self.llm_factory()

        full_text = ""
        tool_id_counter = 0

        db_path = sdir / "state.db"
        async with AsyncSqliteSaver.from_conn_string(str(db_path)) as cp:
            # NOTE: LangChain 1.2.x renamed `prompt=` → `system_prompt=` for create_agent.
            agent = create_agent(
                model=llm,
                tools=tools,
                system_prompt=system_prompt,
                checkpointer=cp,
            )

            try:
                async for mode, data in agent.astream(
                    {"messages": [HumanMessage(content=user_message)]},
                    config={"configurable": {"thread_id": session_id}},
                    stream_mode=["messages", "updates"],
                ):
                    if mode == "messages":
                        msg, metadata = data
                        # Token-level streaming from the LLM
                        if hasattr(msg, "content") and msg.content and getattr(msg, "type", "") in ("AIMessageChunk", "ai"):
                            if not getattr(msg, "tool_calls", None):
                                full_text += msg.content
                                yield {"type": "assistant_token", "content": msg.content}

                    elif mode == "updates":
                        if not isinstance(data, dict):
                            continue
                        for node, payload in data.items():
                            if node == "model" and isinstance(payload, dict):
                                for m in payload.get("messages", []):
                                    for tc in getattr(m, "tool_calls", []) or []:
                                        tool_id_counter += 1
                                        yield {
                                            "type": "tool_start",
                                            "tool_call_id": tc.get("id", f"tc_{tool_id_counter}"),
                                            "name": tc.get("name"),
                                            "input": tc.get("args", {}),
                                        }
                            elif node == "tools" and isinstance(payload, dict):
                                for m in payload.get("messages", []):
                                    yield {
                                        "type": "tool_end",
                                        "tool_call_id": getattr(m, "tool_call_id", ""),
                                        "name": getattr(m, "name", ""),
                                        "output": str(getattr(m, "content", ""))[:5000],
                                        "is_error": False,
                                    }

            except Exception as e:
                yield {"type": "error", "code": "agent_error", "message": str(e)}

        yield {"type": "turn_end", "turn_id": turn_id, "full_response": full_text}
        self.sessions.update_stats(session_id, turns=1)
```

- [ ] **Step 4: Run, expect 1 PASS**

```bash
.venv/Scripts/pytest tests/test_agent_manager.py -v
```

If FakeListChatModel doesn't drive `create_agent` correctly, the test may behave differently across LangChain versions. As a fallback, you may need to adapt the test to assert only on `turn_start` + `turn_end` events being present. Document any deviation in a comment in the test.

- [ ] **Step 5: Commit**

```bash
git add backend/agent/agent_manager.py backend/tests/test_agent_manager.py
git commit -m "feat(backend): AgentManager with create_agent + AsyncSqliteSaver per session"
```

---

### Task 4.4: Session-history extractor (read state.db turns)

**Files:**
- Create: `FF-OpenHermes/backend/agent/history.py`
- Create: `FF-OpenHermes/backend/tests/test_history.py`

Memory page Layer-3 needs to display turns from `state.db`. We use `AsyncSqliteSaver.alist()` to walk checkpoints.

- [ ] **Step 1: Write failing test**

`backend/tests/test_history.py`:

```python
"""Tests for session-history extractor."""
from pathlib import Path

import pytest
from langchain_core.messages import HumanMessage, AIMessage
from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver

from agent.history import extract_turns


@pytest.mark.asyncio
async def test_empty_db_returns_empty(tmp_path: Path):
    db = tmp_path / "state.db"
    async with AsyncSqliteSaver.from_conn_string(str(db)) as cp:
        await cp.setup()
    turns = await extract_turns(db)
    assert turns == []


@pytest.mark.asyncio
async def test_returns_user_assistant_pairs(tmp_path: Path):
    """Insert a fake checkpoint with messages and verify extract_turns reads them."""
    db = tmp_path / "state.db"
    async with AsyncSqliteSaver.from_conn_string(str(db)) as cp:
        await cp.setup()
        # NOTE: langgraph-checkpoint-sqlite 3.x requires `checkpoint_ns` in cfg.
        cfg = {"configurable": {"thread_id": "t1", "checkpoint_ns": ""}}
        ckpt = {
            "v": 1,
            "id": "ck1",
            "ts": "2026-04-29T10:00:00Z",
            "channel_values": {
                "messages": [
                    HumanMessage(content="hello"),
                    AIMessage(content="hi"),
                ]
            },
            "channel_versions": {},
            "versions_seen": {},
            "pending_sends": [],
        }
        await cp.aput(cfg, ckpt, {}, {})
    turns = await extract_turns(db)
    assert len(turns) >= 1
    assert turns[0]["user"] == "hello"
    assert turns[0]["assistant"] == "hi"
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_history.py -v
```

- [ ] **Step 3: Implement `agent/history.py`**

```python
"""Extract conversation turns from a session's state.db checkpoint store."""
from pathlib import Path
from typing import Any

from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver


async def extract_turns(db_path: Path) -> list[dict[str, Any]]:
    """Walk all checkpoints and pair user → assistant messages into turns."""
    if not db_path.exists():
        return []
    turns: list[dict[str, Any]] = []
    async with AsyncSqliteSaver.from_conn_string(str(db_path)) as cp:
        latest_messages: list[Any] = []
        async for tup in cp.alist(None):
            ckpt = tup.checkpoint
            if ckpt and "channel_values" in ckpt:
                msgs = ckpt["channel_values"].get("messages", []) or []
                # Latest checkpoint usually has the longest message list — keep it
                if len(msgs) > len(latest_messages):
                    latest_messages = msgs

    # Pair user → next assistant text (skip tool messages)
    cur_user = None
    cur_tools: list[dict[str, Any]] = []
    for m in latest_messages:
        role = getattr(m, "type", None)
        content = getattr(m, "content", "") or ""
        if role == "human":
            if cur_user is not None:
                turns.append({"user": cur_user, "assistant": "", "tool_calls": cur_tools})
            cur_user = content
            cur_tools = []
        elif role == "ai":
            tcs = getattr(m, "tool_calls", []) or []
            for tc in tcs:
                cur_tools.append({"name": tc.get("name", ""), "args": tc.get("args", {})})
            if content and cur_user is not None:
                turns.append({"user": cur_user, "assistant": content, "tool_calls": cur_tools})
                cur_user = None
                cur_tools = []
    if cur_user is not None:
        turns.append({"user": cur_user, "assistant": "", "tool_calls": cur_tools})
    return turns
```

- [ ] **Step 4: Run, expect 2 PASS**

```bash
.venv/Scripts/pytest tests/test_history.py -v
```

If the checkpoint API has slightly different shape in your installed langgraph version, adapt the test fixture's checkpoint dict — the production `cp.alist()` walk in `extract_turns` is the part that must work end-to-end.

- [ ] **Step 5: Commit**

```bash
git add backend/agent/history.py backend/tests/test_history.py
git commit -m "feat(backend): extract conversation turns from SqliteSaver checkpoint store"
```

---

## Phase 5 — SSE Chat API

### Task 5.1: SSE event protocol + chat router

**Files:**
- Create: `FF-OpenHermes/backend/api/chat.py`
- Modify: `FF-OpenHermes/backend/app.py` (register router)
- Create: `FF-OpenHermes/backend/tests/test_chat_api.py`

- [ ] **Step 1: Write failing test using a fake agent_manager**

`backend/tests/test_chat_api.py`:

```python
"""Tests for /api/chat SSE endpoint."""
from pathlib import Path

import pytest
from httpx import ASGITransport, AsyncClient
from langchain_core.language_models.fake_chat_models import FakeListChatModel

import app as app_module
from agent.agent_manager import AgentManager
from agent.session_manager import SessionManager


@pytest.mark.asyncio
async def test_chat_streams_events(tmp_path: Path, monkeypatch):
    workspace = tmp_path / "ws"
    workspace.mkdir()
    sessions_dir = tmp_path / "sessions"
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    (templates_dir / "SOUL.md").write_text("# Soul", encoding="utf-8")
    (templates_dir / "MEMORY.md").write_text("# Memory", encoding="utf-8")

    sm = SessionManager(sessions_dir=sessions_dir, templates_dir=templates_dir)
    meta = sm.create("T", str(workspace), model="fake")

    # Same bind_tools workaround as test_agent_manager.py
    class ToolBindableFakeListChatModel(FakeListChatModel):
        def bind_tools(self, tools, **kwargs):
            return self

    fake = ToolBindableFakeListChatModel(responses=["fake reply text"])
    mgr = AgentManager(session_manager=sm, llm_factory=lambda: fake)

    # Inject test deps into app
    app_module.app.state.session_manager = sm
    app_module.app.state.agent_manager = mgr

    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        async with ac.stream("POST", "/api/chat", json={"session_id": meta.id, "message": "hi"}) as resp:
            assert resp.status_code == 200
            chunks = []
            async for line in resp.aiter_lines():
                chunks.append(line)
    body = "\n".join(chunks)
    assert "turn_start" in body
    assert "turn_end" in body
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_chat_api.py -v
```

- [ ] **Step 3: Implement `api/chat.py`**

```python
"""POST /api/chat — SSE streaming chat with the agent."""
import json
from typing import AsyncGenerator

from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel
from sse_starlette.sse import EventSourceResponse

router = APIRouter()


class ChatRequest(BaseModel):
    session_id: str
    message: str
    model: str | None = None


@router.post("/chat")
async def chat(req: ChatRequest, request: Request):
    mgr = request.app.state.agent_manager
    sm = request.app.state.session_manager
    try:
        sm.get(req.session_id)  # 404 fast
    except FileNotFoundError:
        raise HTTPException(404, "session not found")

    async def event_gen() -> AsyncGenerator[dict, None]:
        try:
            async for ev in mgr.astream(req.session_id, req.message):
                ev_type = ev.pop("type")
                yield {"event": ev_type, "data": json.dumps(ev, ensure_ascii=False)}
        except Exception as e:
            yield {"event": "error", "data": json.dumps({"message": str(e)}, ensure_ascii=False)}

    return EventSourceResponse(event_gen())
```

- [ ] **Step 4: Wire app dependencies in `app.py` lifespan**

Replace the lifespan in `backend/app.py`:

```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
    from agent.session_manager import SessionManager
    from agent.agent_manager import AgentManager
    sm = SessionManager(sessions_dir=SESSIONS_DIR, templates_dir=TEMPLATES_DIR)
    app.state.session_manager = sm
    app.state.agent_manager = AgentManager(session_manager=sm)
    print(f"FF-OpenHermes backend ready · sessions={SESSIONS_DIR}")
    yield
```

Add `from config import settings, SESSIONS_DIR, TEMPLATES_DIR` at top.

Then register the router at the bottom of `app.py`:

```python
from api.chat import router as chat_router
app.include_router(chat_router, prefix="/api")
```

- [ ] **Step 5: Run, expect 1 PASS**

```bash
.venv/Scripts/pytest tests/test_chat_api.py -v
```

- [ ] **Step 6: Commit**

```bash
git add backend/api/chat.py backend/app.py backend/tests/test_chat_api.py
git commit -m "feat(backend): SSE /api/chat endpoint"
```

---

## Phase 6 — REST APIs

### Task 6.1: Sessions CRUD API

**Files:**
- Create: `FF-OpenHermes/backend/api/sessions.py`
- Modify: `FF-OpenHermes/backend/app.py` (register router)
- Create: `FF-OpenHermes/backend/tests/test_sessions_api.py`

- [ ] **Step 1: Write failing test**

`backend/tests/test_sessions_api.py`:

```python
"""Tests for /api/sessions REST endpoints."""
from pathlib import Path

import pytest
from httpx import ASGITransport, AsyncClient

import app as app_module
from agent.session_manager import SessionManager


@pytest.fixture
def client_setup(tmp_path: Path):
    workspace = tmp_path / "ws"
    workspace.mkdir()
    sessions_dir = tmp_path / "sessions"
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    (templates_dir / "SOUL.md").write_text("# Soul", encoding="utf-8")
    (templates_dir / "MEMORY.md").write_text("# Memory", encoding="utf-8")
    sm = SessionManager(sessions_dir=sessions_dir, templates_dir=templates_dir)
    app_module.app.state.session_manager = sm
    return workspace


@pytest.mark.asyncio
async def test_create_list_get_rename_delete(client_setup):
    workspace = client_setup
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        # Create
        r = await ac.post("/api/sessions", json={
            "title": "First", "workspace_path": str(workspace),
            "model": "deepseek/deepseek-chat-v3.1",
        })
        assert r.status_code == 200
        sid = r.json()["id"]

        # List
        r = await ac.get("/api/sessions")
        assert r.status_code == 200
        assert any(s["id"] == sid for s in r.json()["sessions"])

        # Get
        r = await ac.get(f"/api/sessions/{sid}")
        assert r.status_code == 200
        assert r.json()["title"] == "First"

        # Rename
        r = await ac.put(f"/api/sessions/{sid}", json={"title": "Renamed"})
        assert r.status_code == 200
        assert r.json()["title"] == "Renamed"

        # Delete
        r = await ac.delete(f"/api/sessions/{sid}")
        assert r.status_code == 200

        # Confirm gone
        r = await ac.get(f"/api/sessions/{sid}")
        assert r.status_code == 404


@pytest.mark.asyncio
async def test_create_rejects_missing_workspace(client_setup):
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.post("/api/sessions", json={
            "title": "X", "workspace_path": "C:/does/not/exist",
            "model": "deepseek/deepseek-chat-v3.1",
        })
        assert r.status_code == 400
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_sessions_api.py -v
```

- [ ] **Step 3: Implement `api/sessions.py`**

```python
"""Sessions CRUD endpoints."""
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from agent.models import CreateSessionRequest, RenameSessionRequest, SessionMeta
from config import settings

router = APIRouter()


@router.get("/sessions")
async def list_sessions(request: Request):
    sm = request.app.state.session_manager
    return {"sessions": [m.model_dump() for m in sm.list()]}


@router.post("/sessions")
async def create_session(req: CreateSessionRequest, request: Request):
    sm = request.app.state.session_manager
    try:
        meta = sm.create(
            title=req.title,
            workspace_path=req.workspace_path,
            model=req.model or settings.OPENROUTER_MODEL,
        )
    except ValueError as e:
        raise HTTPException(400, str(e))
    return meta.model_dump()


@router.get("/sessions/{sid}")
async def get_session(sid: str, request: Request):
    sm = request.app.state.session_manager
    try:
        return sm.get(sid).model_dump()
    except FileNotFoundError:
        raise HTTPException(404, "session not found")


@router.put("/sessions/{sid}")
async def rename_session(sid: str, req: RenameSessionRequest, request: Request):
    sm = request.app.state.session_manager
    try:
        return sm.rename(sid, req.title).model_dump()
    except FileNotFoundError:
        raise HTTPException(404, "session not found")


@router.delete("/sessions/{sid}")
async def delete_session(sid: str, request: Request):
    sm = request.app.state.session_manager
    sm.delete(sid)
    return {"status": "deleted", "id": sid}
```

- [ ] **Step 4: Register router in `app.py`**

```python
from api.sessions import router as sessions_router
app.include_router(sessions_router, prefix="/api")
```

- [ ] **Step 5: Run, expect 2 PASS**

```bash
.venv/Scripts/pytest tests/test_sessions_api.py -v
```

- [ ] **Step 6: Commit**

```bash
git add backend/api/sessions.py backend/app.py backend/tests/test_sessions_api.py
git commit -m "feat(backend): /api/sessions CRUD endpoints"
```

---

### Task 6.2: Workspace endpoints

**Files:**
- Create: `FF-OpenHermes/backend/api/workspace.py`
- Modify: `FF-OpenHermes/backend/app.py`
- Create: `FF-OpenHermes/backend/tests/test_workspace_api.py`

- [ ] **Step 1: Write failing test**

`backend/tests/test_workspace_api.py`:

```python
"""Tests for /api/sessions/{sid}/workspace/* endpoints."""
from pathlib import Path

import pytest
from httpx import ASGITransport, AsyncClient

import app as app_module
from agent.session_manager import SessionManager


@pytest.fixture
def setup(tmp_path: Path):
    ws = tmp_path / "proj"
    ws.mkdir()
    (ws / "src").mkdir()
    (ws / "src" / "main.py").write_text("print('hi')\n", encoding="utf-8")
    sessions_dir = tmp_path / "sessions"
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    (templates_dir / "SOUL.md").write_text("# Soul", encoding="utf-8")
    (templates_dir / "MEMORY.md").write_text("# Memory", encoding="utf-8")
    sm = SessionManager(sessions_dir=sessions_dir, templates_dir=templates_dir)
    app_module.app.state.session_manager = sm
    meta = sm.create("T", str(ws), model="m")
    return meta, ws


@pytest.mark.asyncio
async def test_tree_returns_files(setup):
    meta, ws = setup
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.get(f"/api/sessions/{meta.id}/workspace/tree")
    assert r.status_code == 200
    body = r.json()
    names = [c["name"] for c in body["children"]]
    assert "src" in names


@pytest.mark.asyncio
async def test_read_write_roundtrip(setup):
    meta, ws = setup
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.put(f"/api/sessions/{meta.id}/workspace/file",
                          json={"path": "notes.txt", "content": "hello"})
        assert r.status_code == 200
        r = await ac.get(f"/api/sessions/{meta.id}/workspace/file", params={"path": "notes.txt"})
        assert r.status_code == 200
        assert r.json()["content"] == "hello"


@pytest.mark.asyncio
async def test_mkdir_rename_delete(setup):
    meta, ws = setup
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        await ac.post(f"/api/sessions/{meta.id}/workspace/mkdir", json={"path": "a"})
        await ac.post(f"/api/sessions/{meta.id}/workspace/rename",
                      json={"from_path": "a", "to_path": "b"})
        r = await ac.delete(f"/api/sessions/{meta.id}/workspace/file", params={"path": "b"})
        assert r.status_code == 200
        assert not (ws / "a").exists()
        assert not (ws / "b").exists()
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_workspace_api.py -v
```

- [ ] **Step 3: Implement `api/workspace.py`**

```python
"""Workspace file ops bound to a session's workspace_path."""
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request, Query
from pydantic import BaseModel

from agent.workspace import WorkspaceOps

router = APIRouter()


def _get_ops(request: Request, sid: str) -> WorkspaceOps:
    sm = request.app.state.session_manager
    try:
        meta = sm.get(sid)
    except FileNotFoundError:
        raise HTTPException(404, "session not found")
    return WorkspaceOps(Path(meta.workspace_path))


class WriteFileBody(BaseModel):
    path: str
    content: str


class MkdirBody(BaseModel):
    path: str


class RenameBody(BaseModel):
    from_path: str
    to_path: str


@router.get("/sessions/{sid}/workspace/tree")
async def tree(sid: str, request: Request, path: str = ".", depth: int = 3):
    ops = _get_ops(request, sid)
    try:
        return ops.tree(path, max_depth=depth)
    except (ValueError, FileNotFoundError) as e:
        raise HTTPException(400, str(e))


@router.get("/sessions/{sid}/workspace/file")
async def read_file(sid: str, request: Request, path: str = Query(...)):
    ops = _get_ops(request, sid)
    try:
        return ops.read_file(path)
    except (ValueError, FileNotFoundError) as e:
        raise HTTPException(400, str(e))


@router.put("/sessions/{sid}/workspace/file")
async def write_file(sid: str, body: WriteFileBody, request: Request):
    ops = _get_ops(request, sid)
    try:
        ops.write_file(body.path, body.content)
        return {"status": "ok"}
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.post("/sessions/{sid}/workspace/mkdir")
async def mkdir(sid: str, body: MkdirBody, request: Request):
    ops = _get_ops(request, sid)
    ops.mkdir(body.path)
    return {"status": "ok"}


@router.post("/sessions/{sid}/workspace/rename")
async def rename(sid: str, body: RenameBody, request: Request):
    ops = _get_ops(request, sid)
    ops.rename(body.from_path, body.to_path)
    return {"status": "ok"}


@router.delete("/sessions/{sid}/workspace/file")
async def delete_path(sid: str, request: Request, path: str = Query(...)):
    ops = _get_ops(request, sid)
    ops.delete(path)
    return {"status": "ok"}
```

- [ ] **Step 4: Register router in `app.py`**

```python
from api.workspace import router as workspace_router
app.include_router(workspace_router, prefix="/api")
```

- [ ] **Step 5: Run, expect 3 PASS**

```bash
.venv/Scripts/pytest tests/test_workspace_api.py -v
```

- [ ] **Step 6: Commit**

```bash
git add backend/api/workspace.py backend/app.py backend/tests/test_workspace_api.py
git commit -m "feat(backend): /api/sessions/{sid}/workspace/* file CRUD"
```

---

### Task 6.3: fs/browse + fs/drives endpoints

**Files:**
- Create: `FF-OpenHermes/backend/api/fs.py`
- Modify: `FF-OpenHermes/backend/app.py`
- Create: `FF-OpenHermes/backend/tests/test_fs_api.py`

- [ ] **Step 1: Write failing test**

`backend/tests/test_fs_api.py`:

```python
"""Tests for /api/fs/* directory picker endpoints."""
import sys
from pathlib import Path

import pytest
from httpx import ASGITransport, AsyncClient

import app as app_module


@pytest.mark.asyncio
async def test_browse_lists_dirs(tmp_path: Path):
    (tmp_path / "a").mkdir()
    (tmp_path / "f.txt").write_text("x")
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.get("/api/fs/browse", params={"path": str(tmp_path)})
    assert r.status_code == 200
    names = [e["name"] for e in r.json()["entries"]]
    assert "a" in names
    assert "f.txt" not in names


@pytest.mark.asyncio
async def test_drives_endpoint():
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.get("/api/fs/drives")
    assert r.status_code == 200
    assert isinstance(r.json()["drives"], list)
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_fs_api.py -v
```

- [ ] **Step 3: Implement `api/fs.py`**

```python
"""Filesystem browser for the new-session directory picker."""
from fastapi import APIRouter, HTTPException, Query

from agent.fs_browse import browse, list_drives

router = APIRouter()


@router.get("/fs/browse")
async def browse_endpoint(path: str = Query(...)):
    try:
        return browse(path)
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.get("/fs/drives")
async def drives_endpoint():
    return {"drives": list_drives()}
```

- [ ] **Step 4: Register router in `app.py`**

```python
from api.fs import router as fs_router
app.include_router(fs_router, prefix="/api")
```

- [ ] **Step 5: Run, expect 2 PASS**

```bash
.venv/Scripts/pytest tests/test_fs_api.py -v
```

- [ ] **Step 6: Commit**

```bash
git add backend/api/fs.py backend/app.py backend/tests/test_fs_api.py
git commit -m "feat(backend): /api/fs/browse and /api/fs/drives for directory picker"
```

---

### Task 6.4: Memory endpoints (SOUL/MEMORY/history)

**Files:**
- Create: `FF-OpenHermes/backend/api/memory.py`
- Modify: `FF-OpenHermes/backend/app.py`
- Create: `FF-OpenHermes/backend/tests/test_memory_api.py`

- [ ] **Step 1: Write failing test**

`backend/tests/test_memory_api.py`:

```python
"""Tests for /api/sessions/{sid}/{soul,memory,history}."""
from pathlib import Path

import pytest
from httpx import ASGITransport, AsyncClient

import app as app_module
from agent.session_manager import SessionManager


@pytest.fixture
def setup(tmp_path: Path):
    ws = tmp_path / "ws"; ws.mkdir()
    sd = tmp_path / "sessions"
    td = tmp_path / "templates"; td.mkdir()
    (td / "SOUL.md").write_text("# default soul", encoding="utf-8")
    (td / "MEMORY.md").write_text("# default memory", encoding="utf-8")
    sm = SessionManager(sessions_dir=sd, templates_dir=td)
    app_module.app.state.session_manager = sm
    meta = sm.create("T", str(ws), model="m")
    return meta


@pytest.mark.asyncio
async def test_get_put_soul(setup):
    meta = setup
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.get(f"/api/sessions/{meta.id}/soul")
        assert r.status_code == 200
        assert "default soul" in r.json()["content"]
        r = await ac.put(f"/api/sessions/{meta.id}/soul", json={"content": "new soul"})
        assert r.status_code == 200
        r = await ac.get(f"/api/sessions/{meta.id}/soul")
        assert r.json()["content"] == "new soul"


@pytest.mark.asyncio
async def test_memory_stats(setup):
    meta = setup
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.get(f"/api/sessions/{meta.id}/memory/stats")
        assert r.status_code == 200
        body = r.json()
        assert "soul_tokens" in body
        assert "memory_tokens" in body


@pytest.mark.asyncio
async def test_history_empty(setup):
    meta = setup
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        r = await ac.get(f"/api/sessions/{meta.id}/history")
        assert r.status_code == 200
        assert r.json()["turns"] == []
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_memory_api.py -v
```

- [ ] **Step 3: Implement `api/memory.py`**

```python
"""SOUL / MEMORY / Session History endpoints."""
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from agent.history import extract_turns
from agent.memory_ops import MemoryOps

router = APIRouter()


class WriteContentBody(BaseModel):
    content: str


def _get_session_dir(request: Request, sid: str):
    sm = request.app.state.session_manager
    try:
        sm.get(sid)
    except FileNotFoundError:
        raise HTTPException(404, "session not found")
    return sm.session_dir(sid)


@router.get("/sessions/{sid}/soul")
async def get_soul(sid: str, request: Request):
    sd = _get_session_dir(request, sid)
    return {"content": MemoryOps(sd).read_soul()}


@router.put("/sessions/{sid}/soul")
async def put_soul(sid: str, body: WriteContentBody, request: Request):
    sd = _get_session_dir(request, sid)
    MemoryOps(sd).write_soul(body.content)
    return {"status": "ok"}


@router.get("/sessions/{sid}/memory")
async def get_memory(sid: str, request: Request):
    sd = _get_session_dir(request, sid)
    return {"content": MemoryOps(sd).read_memory()}


@router.put("/sessions/{sid}/memory")
async def put_memory(sid: str, body: WriteContentBody, request: Request):
    sd = _get_session_dir(request, sid)
    MemoryOps(sd).write_memory(body.content)
    return {"status": "ok"}


@router.get("/sessions/{sid}/memory/stats")
async def memory_stats(sid: str, request: Request):
    sd = _get_session_dir(request, sid)
    return MemoryOps(sd).stats()


@router.get("/sessions/{sid}/history")
async def session_history(sid: str, request: Request):
    sd = _get_session_dir(request, sid)
    db_path = sd / "state.db"
    turns = await extract_turns(db_path)
    return {"turns": turns}
```

- [ ] **Step 4: Register router**

```python
from api.memory import router as memory_router
app.include_router(memory_router, prefix="/api")
```

- [ ] **Step 5: Run, expect 3 PASS**

```bash
.venv/Scripts/pytest tests/test_memory_api.py -v
```

- [ ] **Step 6: Commit**

```bash
git add backend/api/memory.py backend/app.py backend/tests/test_memory_api.py
git commit -m "feat(backend): SOUL/MEMORY/history endpoints"
```

---

### Task 6.5: Skills endpoints (CRUD + load/unload)

**Files:**
- Create: `FF-OpenHermes/backend/api/skills.py`
- Modify: `FF-OpenHermes/backend/app.py`
- Create: `FF-OpenHermes/backend/tests/test_skills_api.py`

- [ ] **Step 1: Write failing test**

`backend/tests/test_skills_api.py`:

```python
"""Tests for /api/sessions/{sid}/skills/* endpoints."""
from pathlib import Path

import pytest
from httpx import ASGITransport, AsyncClient

import app as app_module
from agent.session_manager import SessionManager


@pytest.fixture
def setup(tmp_path: Path):
    ws = tmp_path / "ws"; ws.mkdir()
    sd = tmp_path / "sessions"
    td = tmp_path / "templates"; td.mkdir()
    (td / "SOUL.md").write_text("# soul", encoding="utf-8")
    (td / "MEMORY.md").write_text("# memory", encoding="utf-8")
    sm = SessionManager(sessions_dir=sd, templates_dir=td)
    app_module.app.state.session_manager = sm
    meta = sm.create("T", str(ws), model="m")
    return meta


@pytest.mark.asyncio
async def test_skill_crud_and_load(setup):
    meta = setup
    md = "---\nname: demo\ndescription: demo. Use when testing.\nversion: 1.0\n---\n\n# Demo\nbody"
    async with AsyncClient(transport=ASGITransport(app=app_module.app), base_url="http://test") as ac:
        # Create
        r = await ac.post(f"/api/sessions/{meta.id}/skills",
                          json={"name": "demo", "content": md})
        assert r.status_code == 200

        # List
        r = await ac.get(f"/api/sessions/{meta.id}/skills")
        assert r.status_code == 200
        assert any(s["name"] == "demo" for s in r.json()["skills"])

        # Get detail
        r = await ac.get(f"/api/sessions/{meta.id}/skills/demo")
        assert "Demo" in r.json()["content"]

        # Load level 1
        r = await ac.post(f"/api/sessions/{meta.id}/skills/demo/load", json={"level": 1})
        assert r.status_code == 200

        # Loaded
        r = await ac.get(f"/api/sessions/{meta.id}/skills/loaded")
        assert any(it["name"] == "demo" for it in r.json()["loaded"])

        # Unload
        r = await ac.post(f"/api/sessions/{meta.id}/skills/demo/unload")
        assert r.status_code == 200

        # Delete
        r = await ac.delete(f"/api/sessions/{meta.id}/skills/demo")
        assert r.status_code == 200
        r = await ac.get(f"/api/sessions/{meta.id}/skills/demo")
        assert r.status_code == 404
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_skills_api.py -v
```

- [ ] **Step 3: Implement `api/skills.py`**

```python
"""Skill management endpoints (manual CRUD + load/unload)."""
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from agent.skill_ops import SkillOps

router = APIRouter()


class WriteSkillBody(BaseModel):
    name: str | None = None
    content: str


class LoadBody(BaseModel):
    level: int = 1


def _get_ops(request: Request, sid: str) -> SkillOps:
    sm = request.app.state.session_manager
    try:
        sm.get(sid)
    except FileNotFoundError:
        raise HTTPException(404, "session not found")
    return SkillOps(sm.session_dir(sid))


@router.get("/sessions/{sid}/skills")
async def list_skills(sid: str, request: Request):
    return {"skills": _get_ops(request, sid).list_skills()}


@router.post("/sessions/{sid}/skills")
async def create_skill(sid: str, body: WriteSkillBody, request: Request):
    ops = _get_ops(request, sid)
    name = body.name
    if not name:
        raise HTTPException(400, "name required for new skill")
    ops.write_skill(name, body.content, history_line=f"Manual create at v1.0")
    return {"status": "ok", "name": name}


@router.get("/sessions/{sid}/skills/loaded")
async def list_loaded(sid: str, request: Request):
    return {"loaded": _get_ops(request, sid).list_loaded()}


@router.get("/sessions/{sid}/skills/{name}")
async def get_skill(sid: str, name: str, request: Request):
    ops = _get_ops(request, sid)
    try:
        return {"name": name, "content": ops.read_skill(name)}
    except FileNotFoundError:
        raise HTTPException(404, "skill not found")


@router.put("/sessions/{sid}/skills/{name}")
async def update_skill(sid: str, name: str, body: WriteSkillBody, request: Request):
    ops = _get_ops(request, sid)
    ops.write_skill(name, body.content, history_line="Manual edit")
    return {"status": "ok"}


@router.delete("/sessions/{sid}/skills/{name}")
async def delete_skill(sid: str, name: str, request: Request):
    _get_ops(request, sid).delete_skill(name)
    return {"status": "ok"}


@router.get("/sessions/{sid}/skills/{name}/history")
async def get_history(sid: str, name: str, request: Request):
    return {"history": _get_ops(request, sid).read_history(name)}


@router.post("/sessions/{sid}/skills/{name}/load")
async def load(sid: str, name: str, body: LoadBody, request: Request):
    ops = _get_ops(request, sid)
    if name not in {s["name"] for s in ops.list_skills()}:
        raise HTTPException(404, "skill not found")
    ops.load(name, level=body.level)
    return {"status": "ok"}


@router.post("/sessions/{sid}/skills/{name}/unload")
async def unload(sid: str, name: str, request: Request):
    _get_ops(request, sid).unload(name)
    return {"status": "ok"}
```

- [ ] **Step 4: Register router**

```python
from api.skills import router as skills_router
app.include_router(skills_router, prefix="/api")
```

- [ ] **Step 5: Run, expect 1 PASS**

```bash
.venv/Scripts/pytest tests/test_skills_api.py -v
```

- [ ] **Step 6: Run full backend test suite**

```bash
.venv/Scripts/pytest -v
```

Expected: all tests pass. If LangChain agent test is flaky in your installed version, mark with `@pytest.mark.skip(reason="langchain version drift")` and document.

- [ ] **Step 7: Commit**

```bash
git add backend/api/skills.py backend/app.py backend/tests/test_skills_api.py
git commit -m "feat(backend): /api/sessions/{sid}/skills/* CRUD + load/unload"
```

---

## Phase 7 — Frontend Scaffold

### Task 7.1: Theme tokens + Tailwind config

**Files:**
- Modify: `FF-OpenHermes/frontend/tailwind.config.ts`
- Modify: `FF-OpenHermes/frontend/src/app/globals.css`

- [ ] **Step 1: Replace `tailwind.config.ts`**

```ts
import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./src/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        bg: {
          primary: "var(--bg-primary)",
          surface: "var(--bg-surface)",
          elevated: "var(--bg-elevated)",
        },
        border: {
          subtle: "var(--border-subtle)",
        },
        text: {
          primary: "var(--text-primary)",
          secondary: "var(--text-secondary)",
          muted: "var(--text-muted)",
        },
        accent: {
          primary: "var(--accent-primary)",
          hover: "var(--accent-hover)",
          deep: "var(--accent-deep)",
        },
        bubble: {
          user: "var(--bubble-user)",
        },
        ok: "var(--ok)",
        warn: "var(--warn)",
        danger: "var(--danger)",
      },
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui"],
        mono: ["JetBrains Mono", "ui-monospace", "monospace"],
      },
    },
  },
  plugins: [],
};

export default config;
```

- [ ] **Step 2: Replace `src/app/globals.css`**

```css
@tailwind base;
@tailwind components;
@tailwind utilities;

:root {
  --bg-primary: #FAF9FE;
  --bg-surface: #FFFFFF;
  --bg-elevated: #F4F1FB;
  --border-subtle: #E8E4F3;
  --text-primary: #1E1B2E;
  --text-secondary: #5C4E80;
  --text-muted: #8C7FAE;
  --accent-primary: #7C3AED;
  --accent-hover: #6D28D9;
  --accent-deep: #5B21B6;
  --bubble-user: #EDE9FE;
  --ok: #059669;
  --warn: #D97706;
  --danger: #DC2626;
}

.dark {
  --bg-primary: #0B0818;
  --bg-surface: #15102A;
  --bg-elevated: #1E1738;
  --border-subtle: #2A2145;
  --text-primary: #F0EBFA;
  --text-secondary: #B8A9D9;
  --text-muted: #766B96;
  --accent-primary: #A78BFA;
  --accent-hover: #C4B5FD;
  --accent-deep: #7C3AED;
  --bubble-user: #3B2F5E;
  --ok: #34D399;
  --warn: #FBBF24;
  --danger: #F87171;
}

html, body {
  background: var(--bg-primary);
  color: var(--text-primary);
  font-family: Inter, ui-sans-serif, system-ui, sans-serif;
}

* { box-sizing: border-box; }
```

- [ ] **Step 3: Verify build**

```bash
cd frontend
npm run dev
```

Open http://localhost:3000 — page should load with the new background. Stop server.

- [ ] **Step 4: Commit**

```bash
git add frontend/tailwind.config.ts frontend/src/app/globals.css
git commit -m "feat(frontend): violet theme tokens (light + dark)"
```

---

### Task 7.2: API client + SSE hook

**Files:**
- Create: `FF-OpenHermes/frontend/src/services/api.ts`
- Create: `FF-OpenHermes/frontend/src/hooks/useSseStream.ts`
- Create: `FF-OpenHermes/frontend/src/types/api.ts`

- [ ] **Step 1: Create `src/types/api.ts`**

```ts
export interface SessionStats {
  turns: number;
  total_tokens: number;
  skills_generated: number;
  skills_enhanced: number;
}

export interface SessionMeta {
  id: string;
  title: string;
  workspace_path: string;
  model: string;
  created_at: string;
  updated_at: string;
  stats: SessionStats;
}

export interface FileNode {
  name: string;
  path: string;
  type: "file" | "directory";
  size?: number;
  children?: FileNode[];
}

export interface SkillSummary {
  name: string;
  description: string;
  version: string;
  generated_by: string;
  created_at: string;
}

export interface LoadedSkill {
  name: string;
  level: number;
}

export interface Turn {
  user: string;
  assistant: string;
  tool_calls: { name: string; args: Record<string, unknown> }[];
}

export type SseEvent =
  | { event: "turn_start"; data: { turn_id: string } }
  | { event: "assistant_token"; data: { content: string } }
  | { event: "tool_start"; data: { tool_call_id: string; name: string; input: unknown } }
  | { event: "tool_end"; data: { tool_call_id: string; name: string; output: string; is_error: boolean } }
  | { event: "turn_end"; data: { turn_id: string; full_response: string } }
  | { event: "error"; data: { message: string } };
```

- [ ] **Step 2: Create `src/services/api.ts`**

```ts
import type {
  SessionMeta, FileNode, SkillSummary, LoadedSkill, Turn,
} from "@/types/api";

const BASE = process.env.NEXT_PUBLIC_API_BASE ?? "http://127.0.0.1:8003";

async function http<T>(path: string, init?: RequestInit): Promise<T> {
  const r = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
    ...init,
  });
  if (!r.ok) throw new Error(`${r.status}: ${await r.text()}`);
  return r.json() as Promise<T>;
}

export const api = {
  // Sessions
  listSessions: () => http<{ sessions: SessionMeta[] }>("/api/sessions"),
  createSession: (body: { title: string; workspace_path: string; model?: string }) =>
    http<SessionMeta>("/api/sessions", { method: "POST", body: JSON.stringify(body) }),
  getSession: (sid: string) => http<SessionMeta>(`/api/sessions/${sid}`),
  renameSession: (sid: string, title: string) =>
    http<SessionMeta>(`/api/sessions/${sid}`, { method: "PUT", body: JSON.stringify({ title }) }),
  deleteSession: (sid: string) =>
    http<{ status: string }>(`/api/sessions/${sid}`, { method: "DELETE" }),

  // Workspace
  workspaceTree: (sid: string, path = ".") =>
    http<FileNode>(`/api/sessions/${sid}/workspace/tree?path=${encodeURIComponent(path)}`),
  workspaceReadFile: (sid: string, path: string) =>
    http<{ content: string; language: string }>(`/api/sessions/${sid}/workspace/file?path=${encodeURIComponent(path)}`),
  workspaceWriteFile: (sid: string, path: string, content: string) =>
    http(`/api/sessions/${sid}/workspace/file`, { method: "PUT", body: JSON.stringify({ path, content }) }),
  workspaceMkdir: (sid: string, path: string) =>
    http(`/api/sessions/${sid}/workspace/mkdir`, { method: "POST", body: JSON.stringify({ path }) }),
  workspaceRename: (sid: string, from: string, to: string) =>
    http(`/api/sessions/${sid}/workspace/rename`, { method: "POST", body: JSON.stringify({ from_path: from, to_path: to }) }),
  workspaceDelete: (sid: string, path: string) =>
    http(`/api/sessions/${sid}/workspace/file?path=${encodeURIComponent(path)}`, { method: "DELETE" }),

  // FS browser
  fsBrowse: (path: string) =>
    http<{ cwd: string; parent: string | null; entries: { name: string; path: string }[] }>(
      `/api/fs/browse?path=${encodeURIComponent(path)}`,
    ),
  fsDrives: () => http<{ drives: string[] }>("/api/fs/drives"),

  // Memory
  getSoul: (sid: string) => http<{ content: string }>(`/api/sessions/${sid}/soul`),
  putSoul: (sid: string, content: string) =>
    http(`/api/sessions/${sid}/soul`, { method: "PUT", body: JSON.stringify({ content }) }),
  getMemory: (sid: string) => http<{ content: string }>(`/api/sessions/${sid}/memory`),
  putMemory: (sid: string, content: string) =>
    http(`/api/sessions/${sid}/memory`, { method: "PUT", body: JSON.stringify({ content }) }),
  memoryStats: (sid: string) =>
    http<{ soul_tokens: number; memory_tokens: number }>(`/api/sessions/${sid}/memory/stats`),
  history: (sid: string) => http<{ turns: Turn[] }>(`/api/sessions/${sid}/history`),

  // Skills
  listSkills: (sid: string) => http<{ skills: SkillSummary[] }>(`/api/sessions/${sid}/skills`),
  createSkill: (sid: string, name: string, content: string) =>
    http(`/api/sessions/${sid}/skills`, { method: "POST", body: JSON.stringify({ name, content }) }),
  getSkill: (sid: string, name: string) =>
    http<{ name: string; content: string }>(`/api/sessions/${sid}/skills/${name}`),
  updateSkill: (sid: string, name: string, content: string) =>
    http(`/api/sessions/${sid}/skills/${name}`, { method: "PUT", body: JSON.stringify({ content }) }),
  deleteSkill: (sid: string, name: string) =>
    http(`/api/sessions/${sid}/skills/${name}`, { method: "DELETE" }),
  skillHistory: (sid: string, name: string) =>
    http<{ history: string }>(`/api/sessions/${sid}/skills/${name}/history`),
  loadSkill: (sid: string, name: string, level: number) =>
    http(`/api/sessions/${sid}/skills/${name}/load`, { method: "POST", body: JSON.stringify({ level }) }),
  unloadSkill: (sid: string, name: string) =>
    http(`/api/sessions/${sid}/skills/${name}/unload`, { method: "POST" }),
  listLoaded: (sid: string) => http<{ loaded: LoadedSkill[] }>(`/api/sessions/${sid}/skills/loaded`),
};

export const SSE_BASE = BASE;
```

- [ ] **Step 3: Create `src/hooks/useSseStream.ts`**

```ts
"use client";
import { useCallback, useRef, useState } from "react";
import { SSE_BASE } from "@/services/api";

type EventHandler = (event: string, data: unknown) => void;

export function useSseStream(onEvent: EventHandler) {
  const [running, setRunning] = useState(false);
  const abortRef = useRef<AbortController | null>(null);

  const send = useCallback(async (sessionId: string, message: string) => {
    setRunning(true);
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    try {
      const resp = await fetch(`${SSE_BASE}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ session_id: sessionId, message }),
        signal: ctrl.signal,
      });
      if (!resp.ok || !resp.body) {
        onEvent("error", { message: `HTTP ${resp.status}` });
        return;
      }
      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buf = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        // SSE frames are separated by a blank line. sse-starlette emits CRLF
        // (\r\n) line endings, so we accept both \n\n and \r\n\r\n via regex.
        let m: RegExpExecArray | null;
        const frameSep = /\r?\n\r?\n/;
        while ((m = frameSep.exec(buf))) {
          const frame = buf.slice(0, m.index);
          buf = buf.slice(m.index + m[0].length);
          let event = "";
          const dataLines: string[] = [];
          for (const line of frame.split(/\r?\n/)) {
            if (line.startsWith("event:")) event = line.slice(6).trim();
            else if (line.startsWith("data:")) dataLines.push(line.slice(5).trim());
          }
          if (!event) continue;
          let data: unknown = null;
          try { data = JSON.parse(dataLines.join("\n")); } catch { /* ignore */ }
          onEvent(event, data);
        }
      }
    } catch (e) {
      if ((e as { name?: string }).name !== "AbortError") {
        onEvent("error", { message: String(e) });
      }
    } finally {
      setRunning(false);
      abortRef.current = null;
    }
  }, [onEvent]);

  const abort = useCallback(() => abortRef.current?.abort(), []);

  return { send, abort, running };
}
```

- [ ] **Step 4: Commit**

```bash
git add frontend/src/types frontend/src/services frontend/src/hooks
git commit -m "feat(frontend): API client + SSE stream hook"
```

---

### Task 7.3: App layout (Header + NavSidebar shell)

**Files:**
- Modify: `FF-OpenHermes/frontend/src/app/layout.tsx`
- Create: `FF-OpenHermes/frontend/src/components/layout/Header.tsx`
- Create: `FF-OpenHermes/frontend/src/components/layout/NavSidebar.tsx`

- [ ] **Step 1: Replace `src/app/layout.tsx`**

```tsx
import "./globals.css";
import type { Metadata } from "next";
import Header from "@/components/layout/Header";
import NavSidebar from "@/components/layout/NavSidebar";

export const metadata: Metadata = {
  title: "FF-OpenHermes",
  description: "Self-evolving Agent · Chat + Memory + Skills",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="zh-CN" className="dark">
      <body className="h-screen flex flex-col bg-bg-primary text-text-primary">
        <Header />
        <div className="flex-1 flex overflow-hidden">
          <NavSidebar />
          <main className="flex-1 overflow-auto">{children}</main>
        </div>
      </body>
    </html>
  );
}
```

- [ ] **Step 2: Create `src/components/layout/Header.tsx`** (selector wired in Phase 8 — empty placeholder for now)

```tsx
"use client";
import { Sparkles } from "lucide-react";

export default function Header() {
  return (
    <header className="h-14 px-4 flex items-center gap-4 border-b border-border-subtle bg-bg-surface">
      <div className="flex items-center gap-2 text-accent-primary">
        <Sparkles className="w-5 h-5" />
        <span className="font-semibold">FF-OpenHermes</span>
      </div>
      {/* SessionSelector placeholder — wired up in Task 8.2 */}
      <div id="session-selector-slot" className="flex-1" />
    </header>
  );
}
```

- [ ] **Step 3: Create `src/components/layout/NavSidebar.tsx`** (workspace tree wired in Phase 12)

```tsx
"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { MessageSquare, Brain, Zap } from "lucide-react";
import clsx from "clsx";

const items = [
  { href: "/", icon: MessageSquare, label: "Chat" },
  { href: "/memory", icon: Brain, label: "Memory" },
  { href: "/skills", icon: Zap, label: "Skills" },
];

export default function NavSidebar() {
  const pathname = usePathname();
  return (
    <aside className="w-56 border-r border-border-subtle bg-bg-surface flex flex-col">
      <nav className="py-2">
        {items.map(({ href, icon: Icon, label }) => {
          const active = pathname === href;
          return (
            <Link
              key={href}
              href={href}
              className={clsx(
                "flex items-center gap-3 px-4 py-2 text-sm border-l-2",
                active
                  ? "border-accent-primary bg-bg-elevated text-text-primary"
                  : "border-transparent text-text-secondary hover:bg-bg-elevated"
              )}
            >
              <Icon className="w-4 h-4" />
              {label}
            </Link>
          );
        })}
      </nav>
      <div className="border-t border-border-subtle flex-1 overflow-hidden flex flex-col">
        {/* WorkspaceTree placeholder — wired in Task 12.1 */}
        <div id="workspace-tree-slot" className="flex-1 p-2 text-xs text-text-muted">
          Workspace · select a session to view
        </div>
      </div>
    </aside>
  );
}
```

- [ ] **Step 4: Add empty stub pages**

`src/app/page.tsx`:

```tsx
export default function ChatPage() {
  return <div className="p-6">Chat page (Phase 9)</div>;
}
```

`src/app/memory/page.tsx`:

```tsx
export default function MemoryPage() {
  return <div className="p-6">Memory page (Phase 10)</div>;
}
```

`src/app/skills/page.tsx`:

```tsx
export default function SkillsPage() {
  return <div className="p-6">Skills page (Phase 11)</div>;
}
```

- [ ] **Step 5: Verify**

```bash
cd frontend
npm run dev
```

Visit http://localhost:3000, /memory, /skills. Each shows the layout with the active nav item highlighted in violet. Stop server.

- [ ] **Step 6: Commit**

```bash
git add frontend/src/app frontend/src/components/layout
git commit -m "feat(frontend): app layout shell with NavSidebar + 3 stub pages"
```

---

## Phase 8 — Session State + Selector

### Task 8.1: sessionStore (Zustand)

**Files:**
- Create: `FF-OpenHermes/frontend/src/stores/sessionStore.ts`

- [ ] **Step 1: Implement**

```ts
"use client";
import { create } from "zustand";
import type { SessionMeta } from "@/types/api";
import { api } from "@/services/api";

interface State {
  sessions: SessionMeta[];
  activeSid: string | null;
  loading: boolean;
  refresh(): Promise<void>;
  setActive(sid: string | null): void;
  create(input: { title: string; workspace_path: string; model?: string }): Promise<SessionMeta>;
  rename(sid: string, title: string): Promise<void>;
  remove(sid: string): Promise<void>;
}

export const useSessionStore = create<State>((set, get) => ({
  sessions: [],
  activeSid: null,
  loading: false,

  async refresh() {
    set({ loading: true });
    try {
      const { sessions } = await api.listSessions();
      // Persist last active in localStorage
      const stored = typeof window !== "undefined" ? localStorage.getItem("ff-active-sid") : null;
      const active = get().activeSid ?? (stored && sessions.find(s => s.id === stored) ? stored : null);
      set({ sessions, activeSid: active ?? sessions[0]?.id ?? null });
    } finally {
      set({ loading: false });
    }
  },

  setActive(sid) {
    set({ activeSid: sid });
    if (typeof window !== "undefined" && sid) localStorage.setItem("ff-active-sid", sid);
  },

  async create(input) {
    const meta = await api.createSession(input);
    await get().refresh();
    get().setActive(meta.id);
    return meta;
  },

  async rename(sid, title) {
    await api.renameSession(sid, title);
    await get().refresh();
  },

  async remove(sid) {
    await api.deleteSession(sid);
    if (get().activeSid === sid) get().setActive(null);
    await get().refresh();
  },
}));
```

- [ ] **Step 2: Commit**

```bash
git add frontend/src/stores/sessionStore.ts
git commit -m "feat(frontend): sessionStore (Zustand) with localStorage persistence"
```

---

### Task 8.2: SessionSelector dropdown

**Files:**
- Create: `FF-OpenHermes/frontend/src/components/layout/SessionSelector.tsx`
- Modify: `FF-OpenHermes/frontend/src/components/layout/Header.tsx`

- [ ] **Step 1: Create `SessionSelector.tsx`**

```tsx
"use client";
import { useEffect, useState } from "react";
import { ChevronDown, Plus, Check } from "lucide-react";
import clsx from "clsx";
import { useSessionStore } from "@/stores/sessionStore";

export default function SessionSelector({ onCreateClick }: { onCreateClick: () => void }) {
  const { sessions, activeSid, refresh, setActive } = useSessionStore();
  const [open, setOpen] = useState(false);
  useEffect(() => { void refresh(); }, [refresh]);

  const active = sessions.find(s => s.id === activeSid);

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(o => !o)}
        className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-bg-elevated hover:bg-accent-deep/20 text-sm"
      >
        <span className="truncate max-w-[280px]">
          {active ? active.title : "(no session)"}
        </span>
        <ChevronDown className="w-4 h-4 text-text-muted" />
      </button>
      {open && (
        <>
          <div className="fixed inset-0" onClick={() => setOpen(false)} />
          <div className="absolute top-full mt-1 left-0 w-80 max-h-96 overflow-auto bg-bg-elevated border border-border-subtle rounded-lg shadow-lg z-50">
            {sessions.length === 0 && (
              <div className="px-3 py-4 text-sm text-text-muted">No sessions yet</div>
            )}
            {sessions.map(s => (
              <button
                key={s.id}
                onClick={() => { setActive(s.id); setOpen(false); }}
                className={clsx(
                  "w-full flex items-start gap-2 px-3 py-2 text-left hover:bg-bg-surface",
                  s.id === activeSid && "bg-bg-surface"
                )}
              >
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">{s.title}</div>
                  <div className="text-xs text-text-muted truncate">{s.workspace_path}</div>
                </div>
                {s.id === activeSid && <Check className="w-4 h-4 text-accent-primary mt-1" />}
              </button>
            ))}
            <div className="border-t border-border-subtle">
              <button
                onClick={() => { setOpen(false); onCreateClick(); }}
                className="w-full flex items-center gap-2 px-3 py-2 text-sm text-accent-primary hover:bg-bg-surface"
              >
                <Plus className="w-4 h-4" /> Create new session
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
```

- [ ] **Step 2: Update `Header.tsx`** to include selector + "+New" button (modal will be added in Phase 13)

```tsx
"use client";
import { useState } from "react";
import { Sparkles, Plus } from "lucide-react";
import SessionSelector from "./SessionSelector";

export default function Header() {
  const [newOpen, setNewOpen] = useState(false);
  return (
    <header className="h-14 px-4 flex items-center gap-4 border-b border-border-subtle bg-bg-surface">
      <div className="flex items-center gap-2 text-accent-primary">
        <Sparkles className="w-5 h-5" />
        <span className="font-semibold">FF-OpenHermes</span>
      </div>
      <SessionSelector onCreateClick={() => setNewOpen(true)} />
      <button
        onClick={() => setNewOpen(true)}
        className="px-2 py-1 rounded-md bg-bg-elevated hover:bg-accent-deep/20 text-sm flex items-center gap-1"
      >
        <Plus className="w-4 h-4" /> New
      </button>
      <div className="flex-1" />
      {/* NewSessionModal mounted in Phase 13 */}
      {newOpen && (
        <div id="new-session-modal-slot" data-open onClick={() => setNewOpen(false)} />
      )}
    </header>
  );
}
```

(In Phase 13 we'll replace the `<div id="new-session-modal-slot">` with a real modal component.)

- [ ] **Step 3: Verify**

```bash
cd frontend
npm run dev
```

Click the dropdown — should show "(no session)" + "Create new session" button. Stop server.

- [ ] **Step 4: Commit**

```bash
git add frontend/src/components/layout
git commit -m "feat(frontend): SessionSelector dropdown wired to sessionStore"
```

---

## Phase 9 — Chat Page

### Task 9.1: chatStore + ChatPanel skeleton

**Files:**
- Create: `FF-OpenHermes/frontend/src/stores/chatStore.ts`
- Create: `FF-OpenHermes/frontend/src/components/chat/ChatPanel.tsx`
- Modify: `FF-OpenHermes/frontend/src/app/page.tsx`

- [ ] **Step 1: Create `chatStore.ts`**

```ts
"use client";
import { create } from "zustand";

export interface ToolCall {
  tool_call_id: string;
  name: string;
  input?: unknown;
  output?: string;
  is_error?: boolean;
  status: "running" | "done" | "error";
}

export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  toolCalls?: ToolCall[];
}

interface State {
  messages: Message[];
  pendingAssistant: Message | null;
  running: boolean;
  reset(): void;
  pushUser(content: string): void;
  startAssistant(turnId: string): void;
  appendToken(token: string): void;
  toolStart(tc: { tool_call_id: string; name: string; input: unknown }): void;
  toolEnd(tc: { tool_call_id: string; name: string; output: string; is_error: boolean }): void;
  finishAssistant(): void;
  setRunning(v: boolean): void;
}

export const useChatStore = create<State>((set, get) => ({
  messages: [],
  pendingAssistant: null,
  running: false,

  reset: () => set({ messages: [], pendingAssistant: null, running: false }),

  pushUser: (content) => set((s) => ({
    messages: [...s.messages, { id: `u_${Date.now()}`, role: "user", content }],
  })),

  startAssistant: (turnId) => set({
    pendingAssistant: { id: `a_${turnId}`, role: "assistant", content: "", toolCalls: [] },
  }),

  appendToken: (token) => {
    const cur = get().pendingAssistant;
    if (!cur) return;
    set({ pendingAssistant: { ...cur, content: cur.content + token } });
  },

  toolStart: (tc) => {
    const cur = get().pendingAssistant;
    if (!cur) return;
    const calls = cur.toolCalls ?? [];
    set({ pendingAssistant: { ...cur, toolCalls: [...calls, { ...tc, status: "running" }] } });
  },

  toolEnd: (tc) => {
    const cur = get().pendingAssistant;
    if (!cur) return;
    const calls = (cur.toolCalls ?? []).map(c =>
      c.tool_call_id === tc.tool_call_id
        ? { ...c, output: tc.output, is_error: tc.is_error, status: (tc.is_error ? "error" : "done") as ToolCall["status"] }
        : c
    );
    set({ pendingAssistant: { ...cur, toolCalls: calls } });
  },

  finishAssistant: () => set((s) => ({
    messages: s.pendingAssistant ? [...s.messages, s.pendingAssistant] : s.messages,
    pendingAssistant: null,
  })),

  setRunning: (v) => set({ running: v }),
}));
```

- [ ] **Step 2: Create `ChatPanel.tsx`**

```tsx
"use client";
import { useEffect, useMemo, useRef } from "react";
import { useSessionStore } from "@/stores/sessionStore";
import { useChatStore } from "@/stores/chatStore";
import { useSseStream } from "@/hooks/useSseStream";
import ChatMessage from "./ChatMessage";
import ChatInput from "./ChatInput";

export default function ChatPanel() {
  const sid = useSessionStore((s) => s.activeSid);
  const messages = useChatStore((s) => s.messages);
  const pending = useChatStore((s) => s.pendingAssistant);
  const reset = useChatStore((s) => s.reset);
  const pushUser = useChatStore((s) => s.pushUser);
  const startAssistant = useChatStore((s) => s.startAssistant);
  const appendToken = useChatStore((s) => s.appendToken);
  const toolStart = useChatStore((s) => s.toolStart);
  const toolEnd = useChatStore((s) => s.toolEnd);
  const finishAssistant = useChatStore((s) => s.finishAssistant);
  const setRunning = useChatStore((s) => s.setRunning);

  // Reset chat on session switch
  useEffect(() => { reset(); }, [sid, reset]);

  const handler = useMemo(() => (event: string, data: unknown) => {
    const d = data as Record<string, unknown>;
    if (event === "turn_start") startAssistant(String(d.turn_id ?? ""));
    else if (event === "assistant_token") appendToken(String(d.content ?? ""));
    else if (event === "tool_start") toolStart(d as never);
    else if (event === "tool_end") toolEnd(d as never);
    else if (event === "turn_end") finishAssistant();
    else if (event === "error") { console.error("SSE error:", d); finishAssistant(); }
  }, [startAssistant, appendToken, toolStart, toolEnd, finishAssistant]);

  const { send, running } = useSseStream(handler);
  useEffect(() => { setRunning(running); }, [running, setRunning]);

  const onSend = async (text: string) => {
    if (!sid) return;
    pushUser(text);
    await send(sid, text);
  };

  const scrollRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, pending]);

  if (!sid) {
    return (
      <div className="h-full flex items-center justify-center text-text-muted">
        Select a session or create a new one to start chatting.
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      <div ref={scrollRef} className="flex-1 overflow-auto px-6 py-4 space-y-4">
        {messages.map((m) => <ChatMessage key={m.id} message={m} />)}
        {pending && <ChatMessage message={pending} streaming />}
      </div>
      <ChatInput onSend={onSend} disabled={running} />
    </div>
  );
}
```

- [ ] **Step 3: Update `src/app/page.tsx`**

```tsx
import ChatPanel from "@/components/chat/ChatPanel";

export default function ChatPage() {
  return <ChatPanel />;
}
```

- [ ] **Step 4: Commit (will fail to render until 9.2 — but compiles)**

```bash
git add frontend/src/stores/chatStore.ts frontend/src/components/chat/ChatPanel.tsx frontend/src/app/page.tsx
git commit -m "feat(frontend): chatStore + ChatPanel scaffolding"
```

---

### Task 9.2: ChatMessage + ToolCallCard

**Files:**
- Create: `FF-OpenHermes/frontend/src/components/chat/ChatMessage.tsx`
- Create: `FF-OpenHermes/frontend/src/components/chat/ToolCallCard.tsx`
- Create: `FF-OpenHermes/frontend/src/components/chat/ChatInput.tsx`

- [ ] **Step 1: Create `ToolCallCard.tsx`**

```tsx
"use client";
import { useState } from "react";
import { Wrench, ChevronRight, ChevronDown, Check, AlertCircle, Loader2 } from "lucide-react";
import clsx from "clsx";
import type { ToolCall } from "@/stores/chatStore";

export default function ToolCallCard({ tc }: { tc: ToolCall }) {
  const [open, setOpen] = useState(false);
  const StatusIcon =
    tc.status === "running" ? Loader2 :
    tc.status === "error" ? AlertCircle : Check;
  const statusColor =
    tc.status === "running" ? "text-accent-primary animate-spin" :
    tc.status === "error" ? "text-danger" : "text-ok";

  return (
    <div className="border border-border-subtle rounded-md bg-bg-surface text-sm">
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full px-3 py-1.5 flex items-center gap-2 hover:bg-bg-elevated"
      >
        {open ? <ChevronDown className="w-4 h-4 text-text-muted" /> : <ChevronRight className="w-4 h-4 text-text-muted" />}
        <Wrench className="w-4 h-4 text-accent-primary" />
        <span className="font-mono">{tc.name}</span>
        <StatusIcon className={clsx("w-4 h-4 ml-auto", statusColor)} />
      </button>
      {open && (
        <div className="px-3 pb-3 space-y-2 text-xs font-mono">
          <div>
            <div className="text-text-muted uppercase tracking-wide mb-1">Input</div>
            <pre className="bg-bg-elevated p-2 rounded overflow-auto max-h-40">
              {JSON.stringify(tc.input, null, 2)}
            </pre>
          </div>
          {tc.output !== undefined && (
            <div>
              <div className="text-text-muted uppercase tracking-wide mb-1">Output</div>
              <pre className="bg-bg-elevated p-2 rounded overflow-auto max-h-60 whitespace-pre-wrap">
                {tc.output}
              </pre>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
```

- [ ] **Step 2: Create `ChatMessage.tsx`**

```tsx
"use client";
import clsx from "clsx";
import type { Message } from "@/stores/chatStore";
import ToolCallCard from "./ToolCallCard";

export default function ChatMessage({ message, streaming }: { message: Message; streaming?: boolean }) {
  const isUser = message.role === "user";
  return (
    <div className={clsx("flex", isUser ? "justify-end" : "justify-start")}>
      <div
        className={clsx(
          "max-w-[80%] rounded-xl px-4 py-3",
          isUser
            ? "bg-bubble-user text-text-primary"
            : "bg-bg-surface border border-border-subtle"
        )}
      >
        {message.toolCalls && message.toolCalls.length > 0 && (
          <div className="space-y-2 mb-2">
            {message.toolCalls.map((tc) => <ToolCallCard key={tc.tool_call_id} tc={tc} />)}
          </div>
        )}
        <div className="whitespace-pre-wrap text-sm">
          {message.content}
          {streaming && <span className="inline-block w-2 h-4 bg-accent-primary ml-0.5 animate-pulse" />}
        </div>
      </div>
    </div>
  );
}
```

- [ ] **Step 3: Create `ChatInput.tsx`**

```tsx
"use client";
import { useState } from "react";
import { Send } from "lucide-react";

export default function ChatInput({ onSend, disabled }: { onSend: (text: string) => void; disabled: boolean }) {
  const [text, setText] = useState("");
  const submit = () => {
    const t = text.trim();
    if (!t || disabled) return;
    onSend(t);
    setText("");
  };
  return (
    <div className="border-t border-border-subtle bg-bg-surface p-3 flex items-end gap-2">
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            submit();
          }
        }}
        placeholder="Ask anything... (Shift+Enter for newline)"
        rows={2}
        className="flex-1 bg-bg-primary text-sm rounded-md px-3 py-2 border border-border-subtle focus:border-accent-primary outline-none resize-y max-h-40"
      />
      <button
        onClick={submit}
        disabled={disabled || !text.trim()}
        className="p-2 rounded-md bg-accent-primary text-white disabled:opacity-50 hover:bg-accent-hover"
      >
        <Send className="w-4 h-4" />
      </button>
    </div>
  );
}
```

- [ ] **Step 4: Commit**

```bash
git add frontend/src/components/chat
git commit -m "feat(frontend): ChatMessage + ToolCallCard + ChatInput"
```

---

## Phase 10 — Memory Page

### Task 10.1: memoryStore + MemoryLayerCards

**Files:**
- Create: `FF-OpenHermes/frontend/src/stores/memoryStore.ts`
- Create: `FF-OpenHermes/frontend/src/components/memory/MemoryLayerCards.tsx`
- Modify: `FF-OpenHermes/frontend/src/app/memory/page.tsx`

- [ ] **Step 1: Create `memoryStore.ts`**

```ts
"use client";
import { create } from "zustand";
import { api } from "@/services/api";
import type { Turn } from "@/types/api";

type Tab = "soul" | "memory" | "history";

interface State {
  activeTab: Tab;
  soul: string;
  memory: string;
  stats: { soul_tokens: number; memory_tokens: number };
  turns: Turn[];
  loading: boolean;
  setTab(tab: Tab): void;
  loadAll(sid: string): Promise<void>;
  saveSoul(sid: string, content: string): Promise<void>;
  saveMemory(sid: string, content: string): Promise<void>;
  setSoul(content: string): void;
  setMemory(content: string): void;
}

export const useMemoryStore = create<State>((set) => ({
  activeTab: "soul",
  soul: "",
  memory: "",
  stats: { soul_tokens: 0, memory_tokens: 0 },
  turns: [],
  loading: false,

  setTab: (tab) => set({ activeTab: tab }),
  setSoul: (content) => set({ soul: content }),
  setMemory: (content) => set({ memory: content }),

  async loadAll(sid) {
    set({ loading: true });
    try {
      const [soul, memory, stats, history] = await Promise.all([
        api.getSoul(sid),
        api.getMemory(sid),
        api.memoryStats(sid),
        api.history(sid),
      ]);
      set({
        soul: soul.content,
        memory: memory.content,
        stats,
        turns: history.turns,
      });
    } finally {
      set({ loading: false });
    }
  },

  async saveSoul(sid, content) {
    await api.putSoul(sid, content);
    const stats = await api.memoryStats(sid);
    set({ soul: content, stats });
  },

  async saveMemory(sid, content) {
    await api.putMemory(sid, content);
    const stats = await api.memoryStats(sid);
    set({ memory: content, stats });
  },
}));
```

- [ ] **Step 2: Create `MemoryLayerCards.tsx`**

```tsx
"use client";
import { Brain, Database, History as HistoryIcon } from "lucide-react";
import clsx from "clsx";
import { useMemoryStore } from "@/stores/memoryStore";

export default function MemoryLayerCards() {
  const { activeTab, setTab, stats, turns } = useMemoryStore();

  const cards = [
    {
      key: "soul" as const,
      icon: Brain,
      title: "SOUL.md",
      sub: "Layer 1 · Agent Personality",
      metric: `${stats.soul_tokens} tokens`,
    },
    {
      key: "memory" as const,
      icon: Database,
      title: "MEMORY.md",
      sub: "Layer 1 · Long-term Memory",
      metric: `${stats.memory_tokens} tokens`,
    },
    {
      key: "history" as const,
      icon: HistoryIcon,
      title: "Session History",
      sub: "Layer 3 · SqliteSaver",
      metric: `${turns.length} turns`,
    },
  ];

  return (
    <div className="grid grid-cols-3 gap-4">
      {cards.map(({ key, icon: Icon, title, sub, metric }) => {
        const active = activeTab === key;
        return (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={clsx(
              "text-left p-4 rounded-lg border bg-bg-surface hover:bg-bg-elevated",
              active ? "border-accent-primary" : "border-border-subtle"
            )}
          >
            <Icon className="w-5 h-5 text-accent-primary mb-2" />
            <div className="font-medium">{title}</div>
            <div className="text-xs text-text-muted">{sub}</div>
            <div className="text-xs mt-2">{metric}</div>
          </button>
        );
      })}
    </div>
  );
}
```

- [ ] **Step 3: Update `src/app/memory/page.tsx`**

```tsx
"use client";
import { useEffect } from "react";
import { useSessionStore } from "@/stores/sessionStore";
import { useMemoryStore } from "@/stores/memoryStore";
import MemoryLayerCards from "@/components/memory/MemoryLayerCards";
import SoulMemoryEditor from "@/components/memory/SoulMemoryEditor";
import SessionHistoryView from "@/components/memory/SessionHistoryView";

export default function MemoryPage() {
  const sid = useSessionStore((s) => s.activeSid);
  const tab = useMemoryStore((s) => s.activeTab);
  const loadAll = useMemoryStore((s) => s.loadAll);

  useEffect(() => {
    if (sid) void loadAll(sid);
  }, [sid, loadAll]);

  if (!sid) return <div className="p-6 text-text-muted">Select a session.</div>;

  return (
    <div className="p-6 space-y-6">
      <MemoryLayerCards />
      {tab === "soul" && <SoulMemoryEditor field="soul" />}
      {tab === "memory" && <SoulMemoryEditor field="memory" />}
      {tab === "history" && <SessionHistoryView />}
    </div>
  );
}
```

- [ ] **Step 4: Commit (will fail to compile until 10.2/10.3 — acceptable mid-phase)**

```bash
git add frontend/src/stores/memoryStore.ts frontend/src/components/memory frontend/src/app/memory
git commit -m "feat(frontend): memoryStore + MemoryLayerCards"
```

---

### Task 10.2: SoulMemoryEditor (Monaco)

**Files:**
- Create: `FF-OpenHermes/frontend/src/components/memory/SoulMemoryEditor.tsx`

- [ ] **Step 1: Implement**

```tsx
"use client";
import { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { Save, RotateCcw } from "lucide-react";
import { useSessionStore } from "@/stores/sessionStore";
import { useMemoryStore } from "@/stores/memoryStore";

const Monaco = dynamic(() => import("@monaco-editor/react"), { ssr: false });

export default function SoulMemoryEditor({ field }: { field: "soul" | "memory" }) {
  const sid = useSessionStore((s) => s.activeSid);
  const value = useMemoryStore((s) => (field === "soul" ? s.soul : s.memory));
  const setLocal = useMemoryStore((s) => (field === "soul" ? s.setSoul : s.setMemory));
  const save = useMemoryStore((s) => (field === "soul" ? s.saveSoul : s.saveMemory));

  const [original, setOriginal] = useState(value);
  useEffect(() => { setOriginal(value); }, [value]);

  if (!sid) return null;
  const dirty = value !== original;
  const filename = field === "soul" ? "SOUL.md" : "MEMORY.md";

  return (
    <div className="rounded-lg border border-border-subtle bg-bg-surface">
      <div className="flex items-center justify-between px-3 py-2 border-b border-border-subtle">
        <span className="font-mono text-sm text-text-muted">sessions/{sid}/{filename}</span>
        <div className="flex gap-2">
          <button
            disabled={!dirty}
            onClick={() => setLocal(original)}
            className="px-2 py-1 rounded text-sm hover:bg-bg-elevated disabled:opacity-40 flex items-center gap-1"
          >
            <RotateCcw className="w-4 h-4" /> Reset
          </button>
          <button
            disabled={!dirty}
            onClick={async () => { await save(sid, value); setOriginal(value); }}
            className="px-3 py-1 rounded bg-accent-primary text-white text-sm disabled:opacity-40 flex items-center gap-1"
          >
            <Save className="w-4 h-4" /> Save
          </button>
        </div>
      </div>
      <div className="h-[480px]">
        <Monaco
          theme="vs-dark"
          defaultLanguage="markdown"
          value={value}
          onChange={(v) => setLocal(v ?? "")}
          options={{ minimap: { enabled: false }, fontSize: 13, wordWrap: "on" }}
        />
      </div>
    </div>
  );
}
```

- [ ] **Step 2: Commit**

```bash
git add frontend/src/components/memory/SoulMemoryEditor.tsx
git commit -m "feat(frontend): Monaco-based SOUL/MEMORY editor with dirty tracking"
```

---

### Task 10.3: SessionHistoryView (timeline)

**Files:**
- Create: `FF-OpenHermes/frontend/src/components/memory/SessionHistoryView.tsx`

- [ ] **Step 1: Implement**

```tsx
"use client";
import { useState } from "react";
import { ChevronRight, ChevronDown, User, Bot, Wrench } from "lucide-react";
import { useMemoryStore } from "@/stores/memoryStore";

export default function SessionHistoryView() {
  const turns = useMemoryStore((s) => s.turns);

  if (turns.length === 0) {
    return (
      <div className="p-8 rounded-lg border border-dashed border-border-subtle text-center text-text-muted">
        No turns yet. Send a message in the Chat page to populate history.
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {turns.map((t, i) => <TurnCard key={i} index={i + 1} turn={t} />)}
    </div>
  );
}

function TurnCard({ index, turn }: { index: number; turn: { user: string; assistant: string; tool_calls: { name: string; args: Record<string, unknown> }[] } }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-lg border border-border-subtle bg-bg-surface">
      <button onClick={() => setOpen(o => !o)} className="w-full flex items-center gap-2 px-3 py-2 text-sm">
        {open ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        <span className="text-text-muted">Turn {index}</span>
        <User className="w-4 h-4 text-accent-primary ml-2" />
        <span className="truncate flex-1 text-left">{turn.user.slice(0, 80)}</span>
        {turn.tool_calls.length > 0 && (
          <span className="text-xs text-text-muted">{turn.tool_calls.length} tools</span>
        )}
      </button>
      {open && (
        <div className="border-t border-border-subtle p-3 space-y-2 text-sm">
          <div>
            <div className="text-xs text-text-muted uppercase mb-1">User</div>
            <div className="whitespace-pre-wrap">{turn.user}</div>
          </div>
          {turn.tool_calls.length > 0 && (
            <div>
              <div className="text-xs text-text-muted uppercase mb-1">Tool Calls</div>
              <ul className="space-y-1">
                {turn.tool_calls.map((tc, i) => (
                  <li key={i} className="flex items-center gap-2">
                    <Wrench className="w-3.5 h-3.5 text-accent-primary" />
                    <span className="font-mono text-xs">{tc.name}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
          <div>
            <div className="text-xs text-text-muted uppercase mb-1 flex items-center gap-1">
              <Bot className="w-3.5 h-3.5" /> Assistant
            </div>
            <div className="whitespace-pre-wrap">{turn.assistant}</div>
          </div>
        </div>
      )}
    </div>
  );
}
```

- [ ] **Step 2: Verify**

```bash
cd frontend
npm run dev
```

Open `/memory` (after creating a session in Phase 13). Tabs SOUL/MEMORY/History switch. Stop server.

- [ ] **Step 3: Commit**

```bash
git add frontend/src/components/memory/SessionHistoryView.tsx
git commit -m "feat(frontend): SessionHistoryView timeline"
```

---

## Phase 11 — Skills Page

### Task 11.1: skillStore + SkillLibrary

**Files:**
- Create: `FF-OpenHermes/frontend/src/stores/skillStore.ts`
- Create: `FF-OpenHermes/frontend/src/components/skills/SkillLibrary.tsx`
- Modify: `FF-OpenHermes/frontend/src/app/skills/page.tsx`

- [ ] **Step 1: Create `skillStore.ts`**

```ts
"use client";
import { create } from "zustand";
import { api } from "@/services/api";
import type { SkillSummary, LoadedSkill } from "@/types/api";

interface State {
  skills: SkillSummary[];
  loaded: LoadedSkill[];
  selected: string | null;
  detail: string;
  history: string;
  loading: boolean;
  setSelected(name: string | null): void;
  setDetail(content: string): void;
  loadAll(sid: string): Promise<void>;
  loadDetail(sid: string, name: string): Promise<void>;
  saveDetail(sid: string, name: string, content: string): Promise<void>;
  toggleLoad(sid: string, name: string, level: number): Promise<void>;
  remove(sid: string, name: string): Promise<void>;
  create(sid: string, name: string, content: string): Promise<void>;
}

export const useSkillStore = create<State>((set, get) => ({
  skills: [], loaded: [], selected: null, detail: "", history: "", loading: false,

  setSelected: (n) => set({ selected: n, detail: "", history: "" }),
  setDetail: (c) => set({ detail: c }),

  async loadAll(sid) {
    set({ loading: true });
    try {
      const [{ skills }, { loaded }] = await Promise.all([api.listSkills(sid), api.listLoaded(sid)]);
      set({ skills, loaded });
    } finally {
      set({ loading: false });
    }
  },

  async loadDetail(sid, name) {
    const [d, h] = await Promise.all([api.getSkill(sid, name), api.skillHistory(sid, name)]);
    set({ detail: d.content, history: h.history });
  },

  async saveDetail(sid, name, content) {
    await api.updateSkill(sid, name, content);
    set({ detail: content });
    await get().loadAll(sid);
  },

  async toggleLoad(sid, name, level) {
    const isLoaded = get().loaded.some(l => l.name === name);
    if (isLoaded) await api.unloadSkill(sid, name);
    else await api.loadSkill(sid, name, level);
    await get().loadAll(sid);
  },

  async remove(sid, name) {
    await api.deleteSkill(sid, name);
    set({ selected: null, detail: "", history: "" });
    await get().loadAll(sid);
  },

  async create(sid, name, content) {
    await api.createSkill(sid, name, content);
    await get().loadAll(sid);
    set({ selected: name });
    await get().loadDetail(sid, name);
  },
}));
```

- [ ] **Step 2: Create `SkillLibrary.tsx`**

```tsx
"use client";
import { Bot, PenTool, Check } from "lucide-react";
import clsx from "clsx";
import { useSessionStore } from "@/stores/sessionStore";
import { useSkillStore } from "@/stores/skillStore";

export default function SkillLibrary() {
  const sid = useSessionStore((s) => s.activeSid);
  const { skills, loaded, selected, setSelected, loadDetail } = useSkillStore();

  return (
    <div className="w-64 border-r border-border-subtle bg-bg-surface overflow-auto">
      <div className="p-3 border-b border-border-subtle text-sm font-medium">Skills</div>
      {skills.length === 0 && (
        <div className="p-3 text-xs text-text-muted">
          No skills yet. (M2 will auto-generate from complex tasks.)
        </div>
      )}
      {skills.map(s => {
        const isLoaded = loaded.some(l => l.name === s.name);
        const active = selected === s.name;
        const Icon = s.generated_by === "agent" ? Bot : PenTool;
        return (
          <button
            key={s.name}
            onClick={() => { setSelected(s.name); if (sid) void loadDetail(sid, s.name); }}
            className={clsx(
              "w-full text-left px-3 py-2 border-l-2 text-sm hover:bg-bg-elevated",
              active ? "border-accent-primary bg-bg-elevated" : "border-transparent"
            )}
          >
            <div className="flex items-center gap-2">
              <Icon className="w-3.5 h-3.5 text-accent-primary" />
              <span className="font-mono truncate flex-1">{s.name}</span>
              {isLoaded && <Check className="w-3.5 h-3.5 text-ok" />}
            </div>
            <div className="text-xs text-text-muted truncate">v{s.version}</div>
          </button>
        );
      })}
    </div>
  );
}
```

- [ ] **Step 3: Update `src/app/skills/page.tsx`**

```tsx
"use client";
import { useEffect } from "react";
import { useSessionStore } from "@/stores/sessionStore";
import { useSkillStore } from "@/stores/skillStore";
import SkillLibrary from "@/components/skills/SkillLibrary";
import SkillDetail from "@/components/skills/SkillDetail";
import EvolutionLog from "@/components/skills/EvolutionLog";

export default function SkillsPage() {
  const sid = useSessionStore((s) => s.activeSid);
  const loadAll = useSkillStore((s) => s.loadAll);

  useEffect(() => {
    if (sid) void loadAll(sid);
  }, [sid, loadAll]);

  if (!sid) return <div className="p-6 text-text-muted">Select a session.</div>;

  return (
    <div className="h-full flex">
      <SkillLibrary />
      <SkillDetail />
      <EvolutionLog />
    </div>
  );
}
```

- [ ] **Step 4: Commit**

```bash
git add frontend/src/stores/skillStore.ts frontend/src/components/skills/SkillLibrary.tsx frontend/src/app/skills
git commit -m "feat(frontend): skillStore + SkillLibrary"
```

---

### Task 11.2: SkillDetail with Monaco + load/unload + delete

**Files:**
- Create: `FF-OpenHermes/frontend/src/components/skills/SkillDetail.tsx`

- [ ] **Step 1: Implement**

```tsx
"use client";
import { useState, useEffect } from "react";
import dynamic from "next/dynamic";
import { Save, Trash2 } from "lucide-react";
import { useSessionStore } from "@/stores/sessionStore";
import { useSkillStore } from "@/stores/skillStore";

const Monaco = dynamic(() => import("@monaco-editor/react"), { ssr: false });

export default function SkillDetail() {
  const sid = useSessionStore((s) => s.activeSid);
  const { selected, detail, setDetail, saveDetail, remove, loaded, toggleLoad } = useSkillStore();
  const [original, setOriginal] = useState(detail);
  useEffect(() => { setOriginal(detail); }, [detail]);

  if (!sid) return <div className="flex-1 p-6 text-text-muted">Select a session.</div>;
  if (!selected) return <div className="flex-1 p-6 text-text-muted">Select a skill from the library.</div>;

  const dirty = detail !== original;
  const isLoaded = loaded.some(l => l.name === selected);

  return (
    <div className="flex-1 flex flex-col">
      <div className="px-4 py-2 border-b border-border-subtle bg-bg-surface flex items-center gap-2">
        <span className="font-mono text-sm">{selected}</span>
        <span className="text-xs text-text-muted">SKILL.md</span>
        <div className="ml-auto flex gap-2">
          <button
            onClick={() => toggleLoad(sid, selected, 1)}
            className={isLoaded
              ? "px-3 py-1 rounded bg-bg-elevated text-text-secondary text-sm hover:bg-bg-surface"
              : "px-3 py-1 rounded bg-accent-primary text-white text-sm hover:bg-accent-hover"}
          >
            {isLoaded ? "Unload" : "Load (Level 1)"}
          </button>
          <button
            disabled={!dirty}
            onClick={async () => { await saveDetail(sid, selected, detail); setOriginal(detail); }}
            className="px-3 py-1 rounded bg-accent-primary text-white text-sm disabled:opacity-40 flex items-center gap-1"
          >
            <Save className="w-4 h-4" /> Save
          </button>
          <button
            onClick={() => { if (confirm(`Delete skill "${selected}"?`)) remove(sid, selected); }}
            className="px-2 py-1 rounded text-danger hover:bg-danger/10 flex items-center gap-1"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
      <div className="flex-1">
        <Monaco
          theme="vs-dark"
          defaultLanguage="markdown"
          value={detail}
          onChange={(v) => setDetail(v ?? "")}
          options={{ minimap: { enabled: false }, fontSize: 13, wordWrap: "on" }}
        />
      </div>
    </div>
  );
}
```

- [ ] **Step 2: Commit**

```bash
git add frontend/src/components/skills/SkillDetail.tsx
git commit -m "feat(frontend): SkillDetail with Monaco + load/unload/delete"
```

---

### Task 11.3: EvolutionLog

**Files:**
- Create: `FF-OpenHermes/frontend/src/components/skills/EvolutionLog.tsx`

- [ ] **Step 1: Implement**

```tsx
"use client";
import { Activity } from "lucide-react";
import { useSkillStore } from "@/stores/skillStore";

export default function EvolutionLog() {
  const { selected, history } = useSkillStore();
  return (
    <aside className="w-72 border-l border-border-subtle bg-bg-surface overflow-auto">
      <div className="p-3 border-b border-border-subtle flex items-center gap-2 text-sm font-medium">
        <Activity className="w-4 h-4 text-accent-primary" />
        Evolution Log
      </div>
      {!selected && (
        <div className="p-3 text-xs text-text-muted">Select a skill to see version history.</div>
      )}
      {selected && (
        <pre className="p-3 text-xs whitespace-pre-wrap font-mono">{history || "(no history yet)"}</pre>
      )}
    </aside>
  );
}
```

- [ ] **Step 2: Commit**

```bash
git add frontend/src/components/skills/EvolutionLog.tsx
git commit -m "feat(frontend): EvolutionLog right panel"
```

---

### Task 11.4: NewSkillModal (manual creation)

**Files:**
- Create: `FF-OpenHermes/frontend/src/components/skills/NewSkillModal.tsx`
- Modify: `FF-OpenHermes/frontend/src/components/skills/SkillLibrary.tsx` (add "+ Create" button)

- [ ] **Step 1: Implement `NewSkillModal.tsx`**

```tsx
"use client";
import { useState } from "react";
import { useSessionStore } from "@/stores/sessionStore";
import { useSkillStore } from "@/stores/skillStore";

const TEMPLATE = `---
name: __NAME__
description: "Describe when to use this skill. Mention 'use when ...'."
version: 1.0
generated_by: manual
---

# __NAME__

## Overview

## Triggers

## Steps

## Edge Cases

## Verification
`;

export default function NewSkillModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const sid = useSessionStore((s) => s.activeSid);
  const create = useSkillStore((s) => s.create);
  const [name, setName] = useState("");

  if (!open) return null;

  const valid = /^[a-z][a-z0-9-]{1,40}$/.test(name);

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="bg-bg-elevated rounded-lg w-[420px] p-4 space-y-3 border border-border-subtle">
        <h2 className="text-lg font-semibold">Create New Skill</h2>
        <label className="block text-sm">
          Name (kebab-case)
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. extract-web-table"
            className="w-full mt-1 px-2 py-1 rounded bg-bg-surface border border-border-subtle"
          />
          {!valid && name && <span className="text-xs text-danger">Use lowercase letters, digits, hyphens (start with letter, 2-40 chars).</span>}
        </label>
        <div className="flex justify-end gap-2 pt-2">
          <button onClick={onClose} className="px-3 py-1 text-sm rounded hover:bg-bg-surface">Cancel</button>
          <button
            disabled={!valid || !sid}
            onClick={async () => {
              if (!sid || !valid) return;
              await create(sid, name, TEMPLATE.replaceAll("__NAME__", name));
              setName("");
              onClose();
            }}
            className="px-3 py-1 text-sm rounded bg-accent-primary text-white disabled:opacity-40"
          >
            Create
          </button>
        </div>
      </div>
    </div>
  );
}
```

- [ ] **Step 2: Update `SkillLibrary.tsx`** to add a "+ Create" button at the bottom

Add at the very end of the component, before `</div>`:

```tsx
        <button
          onClick={() => {
            // Modal mounted in skills/page.tsx — emit a custom event
            window.dispatchEvent(new CustomEvent("ff-open-new-skill"));
          }}
          className="w-full text-left px-3 py-2 text-sm text-accent-primary hover:bg-bg-elevated border-t border-border-subtle"
        >
          + Create skill
        </button>
```

Update `src/app/skills/page.tsx`:

```tsx
"use client";
import { useEffect, useState } from "react";
import { useSessionStore } from "@/stores/sessionStore";
import { useSkillStore } from "@/stores/skillStore";
import SkillLibrary from "@/components/skills/SkillLibrary";
import SkillDetail from "@/components/skills/SkillDetail";
import EvolutionLog from "@/components/skills/EvolutionLog";
import NewSkillModal from "@/components/skills/NewSkillModal";

export default function SkillsPage() {
  const sid = useSessionStore((s) => s.activeSid);
  const loadAll = useSkillStore((s) => s.loadAll);
  const [newOpen, setNewOpen] = useState(false);

  useEffect(() => {
    if (sid) void loadAll(sid);
  }, [sid, loadAll]);

  useEffect(() => {
    const h = () => setNewOpen(true);
    window.addEventListener("ff-open-new-skill", h);
    return () => window.removeEventListener("ff-open-new-skill", h);
  }, []);

  if (!sid) return <div className="p-6 text-text-muted">Select a session.</div>;

  return (
    <div className="h-full flex">
      <SkillLibrary />
      <SkillDetail />
      <EvolutionLog />
      <NewSkillModal open={newOpen} onClose={() => setNewOpen(false)} />
    </div>
  );
}
```

- [ ] **Step 3: Commit**

```bash
git add frontend/src/components/skills frontend/src/app/skills
git commit -m "feat(frontend): NewSkillModal for manual skill creation"
```

---

## Phase 12 — Workspace File Tree (NavSidebar bottom)

### Task 12.1: workspaceStore + WorkspaceTree component

**Files:**
- Create: `FF-OpenHermes/frontend/src/stores/workspaceStore.ts`
- Create: `FF-OpenHermes/frontend/src/components/layout/WorkspaceTree.tsx`
- Modify: `FF-OpenHermes/frontend/src/components/layout/NavSidebar.tsx`

- [ ] **Step 1: Create `workspaceStore.ts`**

```ts
"use client";
import { create } from "zustand";
import { api } from "@/services/api";
import type { FileNode } from "@/types/api";

interface State {
  tree: FileNode | null;
  expanded: Set<string>;
  loading: boolean;
  refresh(sid: string): Promise<void>;
  toggle(path: string): void;
}

export const useWorkspaceStore = create<State>((set, get) => ({
  tree: null,
  expanded: new Set(),
  loading: false,

  async refresh(sid) {
    set({ loading: true });
    try {
      const tree = await api.workspaceTree(sid, ".");
      set({ tree });
    } catch (e) {
      console.error("workspace tree load failed:", e);
      set({ tree: null });
    } finally {
      set({ loading: false });
    }
  },

  toggle(path) {
    const e = new Set(get().expanded);
    if (e.has(path)) e.delete(path);
    else e.add(path);
    set({ expanded: e });
  },
}));
```

- [ ] **Step 2: Create `WorkspaceTree.tsx`**

```tsx
"use client";
import { useEffect } from "react";
import { Folder, FolderOpen, FileText, ChevronRight, ChevronDown, RefreshCw } from "lucide-react";
import { useSessionStore } from "@/stores/sessionStore";
import { useWorkspaceStore } from "@/stores/workspaceStore";
import type { FileNode } from "@/types/api";

export default function WorkspaceTree() {
  const sid = useSessionStore((s) => s.activeSid);
  const session = useSessionStore((s) => s.sessions.find((x) => x.id === s.activeSid));
  const { tree, expanded, refresh, toggle } = useWorkspaceStore();

  useEffect(() => {
    if (sid) void refresh(sid);
  }, [sid, refresh]);

  if (!sid) return <div className="p-3 text-xs text-text-muted">No session selected.</div>;

  return (
    <div className="flex flex-col h-full">
      <div className="px-2 py-1 flex items-center gap-2 border-b border-border-subtle">
        <Folder className="w-3.5 h-3.5 text-accent-primary" />
        <span className="text-xs font-mono truncate flex-1">{session?.workspace_path ?? ""}</span>
        <button onClick={() => sid && refresh(sid)} className="p-1 hover:bg-bg-elevated rounded">
          <RefreshCw className="w-3.5 h-3.5" />
        </button>
      </div>
      <div className="flex-1 overflow-auto py-1">
        {tree ? <Node node={tree} depth={0} expanded={expanded} onToggle={toggle} /> : (
          <div className="px-3 text-xs text-text-muted">Loading…</div>
        )}
      </div>
    </div>
  );
}

function Node({ node, depth, expanded, onToggle }: {
  node: FileNode; depth: number;
  expanded: Set<string>; onToggle: (p: string) => void;
}) {
  if (node.type === "file") {
    return (
      <div className="flex items-center gap-1 px-2 py-0.5 text-xs hover:bg-bg-elevated cursor-pointer"
           style={{ paddingLeft: `${depth * 12 + 8}px` }}>
        <FileText className="w-3.5 h-3.5 text-text-muted" />
        <span className="truncate">{node.name}</span>
      </div>
    );
  }
  const isOpen = depth === 0 || expanded.has(node.path);
  const Icon = isOpen ? FolderOpen : Folder;
  const Chevron = isOpen ? ChevronDown : ChevronRight;
  return (
    <>
      <div
        onClick={() => depth > 0 && onToggle(node.path)}
        className="flex items-center gap-1 px-2 py-0.5 text-xs hover:bg-bg-elevated cursor-pointer"
        style={{ paddingLeft: `${depth * 12 + 4}px` }}
      >
        {depth > 0 && <Chevron className="w-3.5 h-3.5 text-text-muted" />}
        <Icon className="w-3.5 h-3.5 text-accent-primary" />
        <span className="truncate font-medium">{node.name}</span>
      </div>
      {isOpen && node.children?.map((c) => (
        <Node key={c.path || c.name} node={c} depth={depth + 1} expanded={expanded} onToggle={onToggle} />
      ))}
    </>
  );
}
```

- [ ] **Step 3: Update `NavSidebar.tsx`** to mount the tree at the bottom

Replace the `<div id="workspace-tree-slot">…</div>` with:

```tsx
<WorkspaceTree />
```

And add `import WorkspaceTree from "./WorkspaceTree";` at the top.

- [ ] **Step 4: Commit**

```bash
git add frontend/src/stores/workspaceStore.ts frontend/src/components/layout/WorkspaceTree.tsx frontend/src/components/layout/NavSidebar.tsx
git commit -m "feat(frontend): workspace file tree in NavSidebar bottom"
```

---

### Task 12.2: Auto-refresh tree on tool_end (write_file/terminal)

**Files:**
- Modify: `FF-OpenHermes/frontend/src/components/chat/ChatPanel.tsx`

- [ ] **Step 1: Add auto-refresh logic to ChatPanel handler**

In `ChatPanel.tsx`, import `useWorkspaceStore` and refresh on relevant tool_end events:

```tsx
import { useWorkspaceStore } from "@/stores/workspaceStore";

// inside ChatPanel:
const refreshWorkspace = useWorkspaceStore((s) => s.refresh);

const handler = useMemo(() => (event: string, data: unknown) => {
  const d = data as Record<string, unknown>;
  if (event === "turn_start") startAssistant(String(d.turn_id ?? ""));
  else if (event === "assistant_token") appendToken(String(d.content ?? ""));
  else if (event === "tool_start") toolStart(d as never);
  else if (event === "tool_end") {
    toolEnd(d as never);
    // If a file-mutating tool ran, refresh the workspace tree
    const toolName = String((d as { name?: string }).name ?? "");
    if (sid && (toolName === "write_file" || toolName === "terminal")) {
      void refreshWorkspace(sid);
    }
  }
  else if (event === "turn_end") finishAssistant();
  else if (event === "error") { console.error("SSE error:", d); finishAssistant(); }
}, [startAssistant, appendToken, toolStart, toolEnd, finishAssistant, sid, refreshWorkspace]);
```

- [ ] **Step 2: Commit**

```bash
git add frontend/src/components/chat/ChatPanel.tsx
git commit -m "feat(frontend): auto-refresh workspace tree on file-mutating tools"
```

---

## Phase 13 — NewSessionModal + DirectoryPicker

### Task 13.1: DirectoryPicker

**Files:**
- Create: `FF-OpenHermes/frontend/src/components/layout/DirectoryPicker.tsx`

- [ ] **Step 1: Implement**

```tsx
"use client";
import { useEffect, useState } from "react";
import { Folder, ArrowUp, FolderPlus } from "lucide-react";
import { api } from "@/services/api";

export default function DirectoryPicker({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const [cwd, setCwd] = useState<string>(value || "");
  const [parent, setParent] = useState<string | null>(null);
  const [entries, setEntries] = useState<{ name: string; path: string }[]>([]);
  const [drives, setDrives] = useState<string[]>([]);
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState("");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => { void api.fsDrives().then((d) => setDrives(d.drives)); }, []);
  useEffect(() => {
    if (!cwd) {
      // start at first drive
      if (drives.length > 0) setCwd(drives[0]);
      return;
    }
    api.fsBrowse(cwd).then((r) => {
      setEntries(r.entries);
      setParent(r.parent);
      setCwd(r.cwd);
      onChange(r.cwd);
      setError(null);
    }).catch((e) => setError(String(e)));
  }, [cwd, drives, onChange]);

  return (
    <div className="border border-border-subtle rounded-md bg-bg-surface text-sm">
      <div className="px-3 py-2 border-b border-border-subtle flex items-center gap-2">
        <button onClick={() => parent && setCwd(parent)} disabled={!parent}
                className="p-1 rounded hover:bg-bg-elevated disabled:opacity-30">
          <ArrowUp className="w-4 h-4" />
        </button>
        <span className="font-mono text-xs flex-1 truncate">{cwd}</span>
        {drives.length > 1 && (
          <select
            value={drives.find((d) => cwd.startsWith(d)) ?? ""}
            onChange={(e) => setCwd(e.target.value)}
            className="text-xs bg-bg-elevated rounded px-1 py-0.5 border border-border-subtle"
          >
            {drives.map((d) => <option key={d} value={d}>{d}</option>)}
          </select>
        )}
      </div>
      <div className="max-h-56 overflow-auto">
        {entries.length === 0 && (
          <div className="px-3 py-6 text-center text-xs text-text-muted">(empty)</div>
        )}
        {entries.map((e) => (
          <button
            key={e.path}
            onClick={() => setCwd(e.path)}
            className="w-full flex items-center gap-2 px-3 py-1.5 text-left hover:bg-bg-elevated"
          >
            <Folder className="w-4 h-4 text-accent-primary" />
            <span className="truncate text-xs">{e.name}</span>
          </button>
        ))}
      </div>
      {error && <div className="px-3 py-2 text-xs text-danger">{error}</div>}
      <div className="border-t border-border-subtle p-2">
        {!creating && (
          <button onClick={() => setCreating(true)} className="text-xs text-accent-primary flex items-center gap-1">
            <FolderPlus className="w-4 h-4" /> Create new sub-folder here
          </button>
        )}
        {creating && (
          <div className="flex gap-2">
            <input
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="folder name"
              className="flex-1 px-2 py-1 text-xs bg-bg-elevated rounded border border-border-subtle"
            />
            <button
              onClick={async () => {
                if (!newName.trim()) return;
                // We can't mkdir without a session — instead just navigate to a hypothetical path
                // and let the backend create it on first session creation. Simpler UX: tell user
                // to create the directory via the OS, or use a mkdir POST against the parent.
                // For M1: emit the chosen path via onChange; user is responsible.
                onChange(`${cwd.replace(/\/+$/, "")}/${newName.trim()}`);
                setCreating(false);
                setNewName("");
              }}
              className="px-2 py-1 text-xs rounded bg-accent-primary text-white"
            >
              Use
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
```

> **Note:** The "create new folder here" button in M1 just constructs a path string — backend will reject session creation if it doesn't exist. A real `mkdir` endpoint at root level is out of scope for M1 (don't expose unrestricted filesystem mkdir).

- [ ] **Step 2: Commit**

```bash
git add frontend/src/components/layout/DirectoryPicker.tsx
git commit -m "feat(frontend): DirectoryPicker for new-session workspace selection"
```

---

### Task 13.2: NewSessionModal wired into Header

**Files:**
- Create: `FF-OpenHermes/frontend/src/components/layout/NewSessionModal.tsx`
- Modify: `FF-OpenHermes/frontend/src/components/layout/Header.tsx`

- [ ] **Step 1: Create `NewSessionModal.tsx`**

```tsx
"use client";
import { useState } from "react";
import { useSessionStore } from "@/stores/sessionStore";
import DirectoryPicker from "./DirectoryPicker";

export default function NewSessionModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const create = useSessionStore((s) => s.create);
  const [title, setTitle] = useState("New Session");
  const [workspacePath, setWorkspacePath] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()}
           className="w-[520px] bg-bg-elevated rounded-lg border border-border-subtle p-4 space-y-3">
        <h2 className="text-lg font-semibold">Create New Session</h2>
        <label className="block text-sm">
          Session title
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full mt-1 px-2 py-1 rounded bg-bg-surface border border-border-subtle"
          />
        </label>
        <div>
          <div className="text-sm mb-1">Workspace directory</div>
          <DirectoryPicker value={workspacePath} onChange={setWorkspacePath} />
          <div className="text-xs text-text-muted mt-1 truncate">Selected: {workspacePath || "(none)"}</div>
        </div>
        {error && <div className="text-xs text-danger">{error}</div>}
        <div className="flex justify-end gap-2 pt-2">
          <button onClick={onClose} className="px-3 py-1 text-sm rounded hover:bg-bg-surface">Cancel</button>
          <button
            disabled={busy || !workspacePath || !title.trim()}
            onClick={async () => {
              setBusy(true);
              setError(null);
              try {
                await create({ title: title.trim(), workspace_path: workspacePath });
                onClose();
              } catch (e) {
                setError(String(e));
              } finally {
                setBusy(false);
              }
            }}
            className="px-4 py-1 text-sm rounded bg-accent-primary text-white disabled:opacity-40"
          >
            {busy ? "Creating..." : "Create"}
          </button>
        </div>
      </div>
    </div>
  );
}
```

- [ ] **Step 2: Update `Header.tsx`** to mount the real modal

Replace the placeholder modal slot with the real component:

```tsx
"use client";
import { useState } from "react";
import { Sparkles, Plus } from "lucide-react";
import SessionSelector from "./SessionSelector";
import NewSessionModal from "./NewSessionModal";

export default function Header() {
  const [newOpen, setNewOpen] = useState(false);
  return (
    <header className="h-14 px-4 flex items-center gap-4 border-b border-border-subtle bg-bg-surface">
      <div className="flex items-center gap-2 text-accent-primary">
        <Sparkles className="w-5 h-5" />
        <span className="font-semibold">FF-OpenHermes</span>
      </div>
      <SessionSelector onCreateClick={() => setNewOpen(true)} />
      <button
        onClick={() => setNewOpen(true)}
        className="px-2 py-1 rounded-md bg-bg-elevated hover:bg-accent-deep/20 text-sm flex items-center gap-1"
      >
        <Plus className="w-4 h-4" /> New
      </button>
      <div className="flex-1" />
      <NewSessionModal open={newOpen} onClose={() => setNewOpen(false)} />
    </header>
  );
}
```

- [ ] **Step 3: Verify**

```bash
cd frontend
npm run dev
```

Click "+ New" — modal opens. Pick a directory, type a title, click Create. The session appears in the dropdown. Stop server.

- [ ] **Step 4: Commit**

```bash
git add frontend/src/components/layout/NewSessionModal.tsx frontend/src/components/layout/Header.tsx
git commit -m "feat(frontend): NewSessionModal with DirectoryPicker"
```

---

## Phase 14 — End-to-End Smoke

### Task 14.1: Start both servers, walk through scenario A

**Files:** No new code. Manual verification.

- [ ] **Step 1: Start backend**

```bash
cd FF-OpenHermes/backend
.venv/Scripts/uvicorn app:app --port 8003 --reload
```

Expected: `FF-OpenHermes backend ready · sessions=...`

- [ ] **Step 2: Start frontend in another terminal**

```bash
cd FF-OpenHermes/frontend
npm run dev
```

Open http://localhost:3000.

- [ ] **Step 3: Create a session**

Click "+ New". Pick any directory you have under `C:/` (e.g. create `C:/tmp/ff-smoke-test` first via OS file manager, since M1 doesn't expose unrestricted mkdir). Title: "Smoke Test". Click Create.

Expected:
- Session appears in dropdown, becomes active
- Left sidebar bottom shows the directory tree
- Chat page is empty + ready

- [ ] **Step 4: Send a message**

Type: "Create a file called hello.txt with the content 'Hello FF-OpenHermes'."

Expected:
- ThoughtChain shows `write_file` running → done
- Workspace tree on the left auto-refreshes, `hello.txt` appears
- Final agent text confirms the action
- Open the actual file at `C:/tmp/ff-smoke-test/hello.txt` in your OS — content matches

- [ ] **Step 5: Send another message that uses memory**

Type: "Remember that I prefer Chinese for replies."

Expected:
- `write_memory` tool runs
- Switch to Memory page → MEMORY.md card shows updated tokens; click MEMORY card → editor shows the new entry

- [ ] **Step 6: Manually create a skill**

Skills page → "+ Create skill" → name `demo` → Create. Edit the SKILL.md content. Click "Load (Level 1)". Click Save.

Expected:
- Skill appears in library with ✅ badge
- HISTORY.md shows "Manual create at v1.0"

- [ ] **Step 7: Switch sessions to verify isolation**

Create a second session bound to a different directory. Switch to it via the dropdown.

Expected:
- Workspace tree updates to the new directory
- Chat is empty
- Memory page tabs show empty/template SOUL/MEMORY
- Skills page shows the templates without the `demo` skill from the first session

- [ ] **Step 8: Restart backend, verify persistence**

Stop both servers. Restart backend.

```bash
.venv/Scripts/uvicorn app:app --port 8003 --reload
```

Reload the page. Both sessions still appear in the dropdown. Open the first session — chat is empty (no UI replay yet — that's expected for M1, history is in Memory page Layer 3), but Memory page → Session History shows the previous turns.

- [ ] **Step 9: Commit smoke checklist as a doc**

Create `FF-OpenHermes/docs/M1-smoke-checklist.md`:

```markdown
# M1 Smoke Checklist

Backend: `uvicorn app:app --port 8003`
Frontend: `npm run dev` (port 3000)

1. [ ] Create session A bound to `~/tmp/proj-a` — appears in dropdown
2. [ ] Send "create hello.txt" — file appears in workspace tree
3. [ ] Workspace tree auto-refreshes after `write_file`/`terminal` tool_end
4. [ ] `write_memory` updates MEMORY.md
5. [ ] Manually create skill `demo`, edit, load Level 1
6. [ ] Switch to session B (different workspace) — tree changes, skills empty
7. [ ] Restart backend — sessions persist; Memory > History shows past turns
8. [ ] Delete session A — `sessions/{sid}/` removed, but `~/tmp/proj-a` untouched
```

- [ ] **Step 10: Commit**

```bash
git add docs/M1-smoke-checklist.md
git commit -m "docs: M1 smoke checklist for end-to-end verification"
```

---

### Task 14.2: Run the full backend test suite as final gate

- [ ] **Step 1: Run all backend tests**

```bash
cd FF-OpenHermes/backend
.venv/Scripts/pytest -v
```

Expected: every test from Phases 0-6 passes. If any fail, fix before declaring M1 complete.

- [ ] **Step 2: Tag M1 release**

```bash
cd FF-OpenHermes
git tag -a v0.1.0-m1 -m "M1: Runtime + 3-layer memory + workspace + manual skill loading"
```

- [ ] **Step 3: Update PRD §10 M1 task list**

Edit `PRD.md` and check off all completed M1 boxes. Commit:

```bash
git add PRD.md
git commit -m "docs: mark M1 milestone complete in PRD"
```

---

## Self-Review Notes (skim before declaring plan complete)

**Spec coverage check** (cross-reference PRD §10 M1 task list):

| PRD M1 task | Plan task(s) | Status |
|---|---|---|
| FastAPI 骨架 + 8 个工具迁移 | 0.3, 3.1–3.5 | covered |
| LangChain 1.x `create_agent` + AsyncSqliteSaver | 4.1, 4.3 | covered |
| prompt_builder 按 session 拼接 | 4.2 | covered |
| SSE 流式 + 基础事件 | 5.1 | covered |
| Sessions CRUD API | 6.1 | covered |
| 工作空间文件树 API | 6.2, 6.3 | covered |
| 工具 cwd 注入 + isSubPath | 1.1, 3.1, 3.3 | covered |
| 前端骨架 (Header + NavSidebar + 三页) | 7.1–7.3, 12.1 | covered |
| 对话页 (ChatPanel + ToolCallCard + ChatInput) | 9.1, 9.2 | covered |
| 记忆页 (MemoryLayerCards + SOUL/MEMORY 编辑) | 10.1, 10.2, 10.3 | covered |
| 技能页 (Library + Detail + 手动加载) | 11.1, 11.2, 11.3, 11.4 | covered |
| NewSessionModal (含目录浏览器) | 13.1, 13.2 | covered |
| 文件树自动刷新 | 12.2 | covered |
| 端到端冒烟 | 14.1, 14.2 | covered |

**Type / signature consistency:**
- `SessionMeta.workspace_path` is `str` everywhere (Pydantic in Python, `string` in TS)
- `WorkspaceOps` uses `tree(rel_path=".")` consistently (matches API path param)
- `SkillOps.list_skills()` returns dicts with `{name, description, version, generated_by, created_at}` matching `SkillSummary` TS type
- SSE event names match between backend (`agent_manager.astream` yields) and frontend handler (`useSseStream` consumer): `turn_start`, `assistant_token`, `tool_start`, `tool_end`, `turn_end`, `error`

**Known caveats inherited from PRD §12 risks:**
- LangChain 1.x middleware API drift — Task 4.3 has a fallback note for FakeListChatModel test
- `with_structured_output` not used in M1 (it's an M2 thing for skill generator); deepseek instability there is deferred

---

## Execution Handoff

**Plan complete and saved to `FF-OpenHermes/docs/M1-plan.md`. Two execution options:**

1. **Subagent-Driven (recommended)** — Dispatch a fresh subagent per task, review between tasks, fast iteration. Best for this plan's scope (~50 tasks across 14 phases).
2. **Inline Execution** — Execute tasks in this session using `superpowers:executing-plans`, batch with checkpoints for review.

**Which approach?**

If subagent-driven: I'll invoke `superpowers:subagent-driven-development` and dispatch tasks one phase at a time, reviewing each subagent's output before proceeding.

If inline: I'll invoke `superpowers:executing-plans` and walk through tasks with you here in batches.
