# FF-OpenHermes M3 Implementation Plan — Skill 自主强化 + M2 cleanup

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add the M3 milestone — when a turn used an existing skill (`read_skill` was called), the Agent runs an Actor + Curator two-stage LLM reflection asynchronously, patches `SKILL.md` to a new version (v1.0 → v1.1), appends an entry to `HISTORY.md` with an inline unified diff, and surfaces the change to the frontend via two new side-channel events (`skill_enhancement_started` + `skill_enhanced`). Plus: fold in 4 small M2 cleanup items.

**Architecture:** The existing `SkillEngineMiddleware.run_for_session` currently has a "skill was used → return early" branch. M3 converts that into a "skill was used → dispatch enhancer" branch. Enhancer is a new `skill_engine/enhancer.py` calling Actor LLM (reflection) → Curator LLM (patch decision + new body) sequentially via `with_structured_output`. Diff is computed mechanically via Python's `difflib.unified_diff`. Side-channel events ride the existing `/api/events/{sid}/stream` (M2 infra). Frontend's existing `SkillEventCard` becomes a discriminated-union renderer (3 variants: generated / enhancement-in-progress / enhanced); `EvolutionLog` is upgraded from a `<pre>` text dump to a clickable per-version timeline with embedded diff.

**Tech Stack:**
- Backend: same M2 stack (Pydantic v2, LangChain 1.x `with_structured_output`, `asyncio.create_task`); add `difflib` (stdlib) for diff generation; thread-based fire-and-forget for sync `after_agent` fallback (M2 cleanup item #3).
- Frontend: extend existing `eventStore` / `useEventStream` / `SkillEventCard` / `EvolutionLog` — no new packages.
- LLM: same `OPENROUTER_MODEL=deepseek/deepseek-chat-v3.1`. M2's `with_structured_output(method="function_calling")` proven; reuse pattern.
- **No new dependencies.**

**Project root:** `E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes/`

**Prerequisites verified before M3:**
- Tag `v0.2.0-m2` checked out (or current HEAD descends from it)
- 108 backend pytest passing
- `frontend/npm run build` clean
- M2 SkillEventCard verified working in browser (skill_generated path live)
- EventBus + side-channel SSE proven (M2 Phase 4)

**Compatibility guardrails (must not break):**
1. M2's `skill_generated` path stays untouched — auto-generation continues to fire on multi-tool turns where no skill was loaded.
2. `useSseStream` (chat SSE) and `extract_turns` (history) are NOT modified.
3. `SkillEventCard`'s existing import-by-default works (we make `event` prop a union type; old call sites pass `SkillGeneratedEvent` which is still valid).
4. 108 existing pytest must continue passing; M3 adds ~22-26 new tests; final count ≥ 130.
5. `useEventStream` continues to ignore unknown events silently — only adds new dispatch branches.
6. The `/api/events/{sid}/stream` endpoint contract is unchanged; just publishes more event types.

**M2 cleanup items folded into Phase 0:**
- `skill_engine/generator.py:136` — `created_at` second-precision → microsecond ISO
- `skill_engine/generator.py:137` — `triggers` YAML escape via `json.dumps`
- `agent/middleware.py` — sync `after_agent` `asyncio.run` would block; switch to thread-based fire-and-forget
- `agent/middleware.py` — extract shared `_dispatch(state)` helper from sync + async hooks (DRY)

**Plan defects from M1+M2 to AVOID:**
- LangChain `create_agent` uses `system_prompt=` not `prompt=`
- `FakeListChatModel.bind_tools` raises `NotImplementedError` → use `ToolBindableFakeListChatModel` subclass
- `AsyncSqliteSaver.aput` test fixture needs `cfg["configurable"]["checkpoint_ns"] = ""`
- Pydantic v2: `field_validator`, `model_validator(mode="after")`, `Field(min_length=, max_length=)`
- Datetime: `timespec="microseconds"` (Windows clock granularity)
- `lstrip("./")` is charset-based; use `removeprefix` or while-loop
- Frontend `useSseStream`/`useEventStream` parse CRLF (`\r?\n\r?\n`)
- TypeScript ternary: `(cond ? "x" : "y") as Type`
- Next.js + ESLint strict: no unused imports/vars
- `httpx.ASGITransport` deadlocks on infinite SSE — use real `uvicorn.Server` in daemon thread + `trust_env=False`
- LangGraph 1.x: state dict has no `configurable` — use `langgraph.config.get_config()`
- LangChain 1.x AgentMiddleware: override BOTH `after_agent` and `aafter_agent`
- EventBus mutation safety: never `pop` shared event dict; use `get` + dict comprehension

---

## Plan Overview · 7 Phases

| Phase | Topic | Tasks |
|---|---|---|
| 0 | M2 cleanup (4 minor fixes) + baseline verification | 0.1 – 0.4 |
| 1 | Actor + Curator Pydantic schemas + diff helper + detect.extract_used_skill_names | 1.1 – 1.3 |
| 2 | Enhancer core (`skill_engine/enhancer.py`) + debounce helper | 2.1 – 2.2 |
| 3 | Middleware extension: dispatch enhancer when skill was used | 3.1 |
| 4 | Frontend types + eventStore multi-event union | 4.1 |
| 5 | Frontend UI: SkillEventCard variants + useEventStream branches + EvolutionLog diff viewer | 5.1 – 5.3 |
| 6 | E2E smoke + M3 release tag | 6.1 |

**Total**: ~14 tasks. Estimated ~22-26 new pytest. Target: ≥ 130 backend tests at M3 release.

---

## Phase 0 — M2 Cleanup + Baseline

### Task 0.1: Fix `created_at` precision in generator.py

**Files:**
- Modify: `FF-OpenHermes/backend/skill_engine/generator.py:135-136`
- Test: `FF-OpenHermes/backend/tests/test_skill_generator.py` (add 1 test)

The current code uses second-precision strftime, so two skills generated within the same wall-clock second collide on `created_at`. Switch to microsecond ISO format.

- [ ] **Step 1: Add failing test for microsecond precision**

Append to `backend/tests/test_skill_generator.py`:

```python
@pytest.mark.asyncio
async def test_generated_skill_md_has_microsecond_created_at(session_dir: Path):
    fake = StructuredFake(responses=[])
    fake.structured_response = {
        "decision": "GENERATE",
        "reasoning": "ok",
        "skill": {
            "name": "demo-skill",
            "description": "Demo. Use when testing.",
            "body": "# demo-skill\nbody content",
            "triggers": ["demo"],
        },
    }
    await generate_skill_from_turn(
        messages=_sample_turn_messages(),
        session_dir=session_dir,
        llm_factory=lambda: fake,
    )
    md = (session_dir / "skills" / "demo-skill" / "SKILL.md").read_text(encoding="utf-8")
    # Must contain microsecond fraction in created_at (e.g., "2026-...T...:....123456+00:00")
    import re
    m = re.search(r"created_at:\s*(\S+)", md)
    assert m, f"no created_at in frontmatter: {md}"
    iso = m.group(1)
    # ISO with microseconds has a "." between seconds and timezone
    assert "." in iso, f"created_at lacks microsecond fraction: {iso}"
```

- [ ] **Step 2: Run, expect FAIL (current code uses strftime without microseconds)**

```bash
cd "E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes/backend"
.venv/Scripts/pytest tests/test_skill_generator.py::test_generated_skill_md_has_microsecond_created_at -v
```

Expected: FAIL with assertion "created_at lacks microsecond fraction".

- [ ] **Step 3: Fix `generator.py:135-136`**

Replace:

```python
        # Format SKILL.md content with frontmatter
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S+00:00")
```

With:

```python
        # Format SKILL.md content with frontmatter — microsecond ISO
        # to avoid timestamp collisions when two skills generate in the same second.
        ts = datetime.now(timezone.utc).isoformat(timespec="microseconds")
```

- [ ] **Step 4: Run, expect PASS + all 5 existing generator tests still PASS**

```bash
.venv/Scripts/pytest tests/test_skill_generator.py -v
```

Expected: 6 passed (5 prior + 1 new).

- [ ] **Step 5: Commit**

```bash
git add backend/skill_engine/generator.py backend/tests/test_skill_generator.py
git commit -m "fix(backend): microsecond precision for skill created_at (M2 cleanup #1)"
```

---

### Task 0.2: Fix `triggers` YAML escaping

**Files:**
- Modify: `FF-OpenHermes/backend/skill_engine/generator.py:137`
- Test: `FF-OpenHermes/backend/tests/test_skill_generator.py` (add 1 test)

Current code uses `f'"{t}"'` to wrap trigger strings. If a trigger contains `"`, the YAML breaks. Use `json.dumps` per item — it correctly escapes embedded quotes and backslashes.

- [ ] **Step 1: Add failing test for trigger escaping**

Append to `tests/test_skill_generator.py`:

```python
@pytest.mark.asyncio
async def test_generated_skill_triggers_escape_quotes(session_dir: Path):
    fake = StructuredFake(responses=[])
    fake.structured_response = {
        "decision": "GENERATE",
        "reasoning": "ok",
        "skill": {
            "name": "quote-skill",
            "description": "Demo. Use when testing.",
            "body": "# quote-skill\nbody content for tests",  # ≥20 chars to satisfy GeneratedSkill.body min_length
            "triggers": ['say "hello"', "back\\slash", "normal trigger"],
        },
    }
    await generate_skill_from_turn(
        messages=_sample_turn_messages(),
        session_dir=session_dir,
        llm_factory=lambda: fake,
    )
    md = (session_dir / "skills" / "quote-skill" / "SKILL.md").read_text(encoding="utf-8")
    # The triggers line should contain JSON-escaped quotes for "say \"hello\""
    triggers_line = next(l for l in md.splitlines() if l.startswith("triggers:"))
    # JSON encoding of `say "hello"` is `"say \"hello\""`
    assert '\\"hello\\"' in triggers_line, f"quotes not escaped: {triggers_line}"
    # Backslash escaped too
    assert "back\\\\slash" in triggers_line, f"backslash not escaped: {triggers_line}"
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_skill_generator.py::test_generated_skill_triggers_escape_quotes -v
```

Expected: FAIL with assertion on quote escaping.

- [ ] **Step 3: Fix `generator.py:137`**

At top of file, ensure `import json` is present (the current generator.py imports json already from logging-related imports — verify; if not, add `import json`).

Replace:

```python
        triggers_yaml = ", ".join(f'"{t}"' for t in skill.triggers)
```

With:

```python
        # Use json.dumps per trigger to safely escape quotes/backslashes — YAML
        # is a strict superset of JSON for double-quoted strings.
        triggers_yaml = ", ".join(json.dumps(t, ensure_ascii=False) for t in skill.triggers)
```

- [ ] **Step 4: Run, expect 7 PASS**

```bash
.venv/Scripts/pytest tests/test_skill_generator.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/skill_engine/generator.py backend/tests/test_skill_generator.py
git commit -m "fix(backend): YAML-escape skill triggers via json.dumps (M2 cleanup #2)"
```

---

### Task 0.3: Refactor middleware — extract `_dispatch` + thread-based sync fallback

**Files:**
- Modify: `FF-OpenHermes/backend/agent/middleware.py`
- Test: `FF-OpenHermes/backend/tests/test_skill_middleware.py` (add 1 test)

The current sync `after_agent` falls back to `asyncio.run(...)` when no event loop is running, which BLOCKS until the LLM completes. Switch to a daemon thread that runs the coroutine in a fresh loop — non-blocking. Also extract the shared state-extraction logic into `_dispatch(state)` so sync + async hooks DRY.

- [ ] **Step 1: Add a test verifying sync fallback returns immediately (does not block)**

Append to `tests/test_skill_middleware.py`:

```python
def test_middleware_sync_after_agent_returns_quickly(setup, monkeypatch):
    """The sync after_agent fallback must not block on the LLM call.

    NOTE: this test is INTENTIONALLY a plain sync test (no @pytest.mark.asyncio).
    The point is to verify the NO-RUNNING-LOOP fallback path. If we put
    @pytest.mark.asyncio here, pytest creates a running event loop, the sync
    after_agent finds it via get_running_loop() and uses loop.create_task(),
    bypassing the broken asyncio.run() path entirely — making the bug invisible.

    We monkeypatch the generator to sleep 5 seconds. If the sync fallback
    used `asyncio.run(run_for_session(...))` it would block; if it spawns
    a daemon thread, it returns immediately.
    """
    sm, meta, bus = setup

    async def slow_generate(*args, **kwargs):
        await asyncio.sleep(5)
        return None

    monkeypatch.setattr("agent.middleware.generate_skill_from_turn", slow_generate)

    mw = SkillEngineMiddleware(
        session_manager=sm,
        event_bus=bus,
        llm_factory=lambda: MagicMock(),
        threshold=3,
    )

    # Patch _resolve_session_id since this test doesn't run inside a graph
    monkeypatch.setattr("agent.middleware._resolve_session_id", lambda state: meta.id)

    state = {"messages": _msgs_with_n_tools(4)}

    import time
    start = time.monotonic()
    # Call the SYNC hook directly
    mw.after_agent(state, runtime=None)
    elapsed = time.monotonic() - start

    # If sync fallback used asyncio.run, this would take >= 5s. Thread-based should be < 0.5s.
    assert elapsed < 1.0, f"sync after_agent blocked for {elapsed:.2f}s — must fire-and-forget"
```

Add `import asyncio` and `from unittest.mock import MagicMock` if not already at the top of `test_skill_middleware.py` (existing imports likely cover MagicMock).

- [ ] **Step 2: Run, expect FAIL (current code blocks on asyncio.run)**

```bash
.venv/Scripts/pytest tests/test_skill_middleware.py::test_middleware_sync_after_agent_returns_quickly -v --timeout=10
```

Expected: FAIL with `elapsed >= 1.0` assertion (or test takes 5+ seconds).

- [ ] **Step 3: Refactor `middleware.py` — extract `_dispatch` and thread-based sync fallback**

Replace the `aafter_agent` and `after_agent` methods with:

```python
    async def aafter_agent(self, state: Any, runtime: Any) -> dict[str, Any] | None:  # type: ignore[override]
        """Async hook — preferred when agent runs via ainvoke/astream."""
        try:
            self._dispatch(state)
        except Exception as e:
            logger.warning("aafter_agent dispatch failed: %s", e)
        return None

    def after_agent(self, state: Any, runtime: Any) -> dict[str, Any] | None:  # type: ignore[override]
        """Sync fallback. Fire-and-forget on a daemon thread to avoid blocking the caller.

        Why a thread instead of `asyncio.run`: if the caller is on a sync stack with no
        running loop, `asyncio.run(coro)` BLOCKS until the coroutine finishes — which for
        us means waiting on the generator/enhancer LLM (5-15s). A daemon thread spawning
        a fresh loop returns immediately and runs in the background.
        """
        try:
            self._dispatch(state)
        except Exception as e:
            logger.warning("after_agent dispatch failed: %s", e)
        return None

    def _dispatch(self, state: Any) -> None:
        """Shared state extraction + background scheduling for both sync and async hooks."""
        messages = state.get("messages", []) if isinstance(state, dict) else []
        session_id = _resolve_session_id(state)
        if not session_id or not messages:
            return
        # Try the running-loop path first (when called from async context).
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(self.run_for_session(session_id, messages))
            return
        except RuntimeError:
            pass
        # No running loop — spawn a daemon thread that runs its own loop.
        import threading
        def _run_in_thread():
            try:
                asyncio.run(self.run_for_session(session_id, messages))
            except Exception as e:
                logger.warning("background skill task crashed: %s", e)
        threading.Thread(target=_run_in_thread, daemon=True).start()
```

- [ ] **Step 4: Run, expect PASS + all 4 existing middleware tests still PASS**

```bash
.venv/Scripts/pytest tests/test_skill_middleware.py -v
```

Expected: 5 passed.

- [ ] **Step 5: Commit**

```bash
git add backend/agent/middleware.py backend/tests/test_skill_middleware.py
git commit -m "refactor(backend): middleware DRY _dispatch + thread-based sync fallback (M2 cleanup #3+#4)"
```

---

### Task 0.4: Verify full M2 baseline still green

**Files:** none (verification only)

- [ ] **Step 1: Run full backend pytest**

```bash
cd "E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes/backend"
.venv/Scripts/pytest -v
```

Expected: **111 passed** (108 prior + 3 new from cleanup tasks). If anything red, **STOP and report BLOCKED** — do not proceed to Phase 1 on a non-green base.

- [ ] **Step 2: Verify frontend build still clean**

```bash
cd "E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes/frontend"
npm run build
```

Expected: clean compile, all routes generated.

- [ ] **Step 3: No commit (verification gate only)**

---

## Phase 1 — Schemas + Diff + Detect Helpers

### Task 1.1: Actor + Curator Pydantic schemas

**Files:**
- Create: `FF-OpenHermes/backend/skill_engine/enhancer_schemas.py`
- Create: `FF-OpenHermes/backend/tests/test_enhancer_schemas.py`

Mirror case-08's two-stage flow but production-tuned: Actor reflects on the skill's actual usage, Curator decides UPDATE vs NO_UPDATE and provides the rewritten body. The diff is computed mechanically post-hoc, NOT in the LLM output (avoids fragile fuzzy match against old text).

- [ ] **Step 1: Write failing tests**

`backend/tests/test_enhancer_schemas.py`:

```python
"""Tests for enhancer Pydantic schemas (Actor + Curator)."""
import pytest
from pydantic import ValidationError

from skill_engine.enhancer_schemas import ActorReflection, CuratorPatch


def test_actor_reflection_minimal_valid():
    r = ActorReflection(
        skill_name="weather-query",
        issues_found=["Failed on JS-rendered pages"],
        new_insights=["Use browser_use for JS sites"],
        overall_assessment="Useful for static pages but needs JS fallback.",
    )
    assert r.skill_name == "weather-query"
    assert len(r.issues_found) == 1


def test_actor_reflection_lists_can_be_empty():
    """Both lists may be empty if assessment says skill is fine as-is."""
    r = ActorReflection(
        skill_name="x", issues_found=[], new_insights=[],
        overall_assessment="Worked perfectly; nothing to add.",
    )
    assert r.issues_found == []


def test_actor_reflection_caps_list_lengths():
    with pytest.raises(ValidationError):
        ActorReflection(
            skill_name="x",
            issues_found=["a"] * 10,  # max 5
            new_insights=[],
            overall_assessment="ok",
        )


def test_curator_patch_update_requires_new_body():
    with pytest.raises(ValidationError, match="new_body"):
        CuratorPatch(decision="UPDATE", new_body=None, summary="bumping version")


def test_curator_patch_no_update_must_not_include_body():
    with pytest.raises(ValidationError):
        CuratorPatch(decision="NO_UPDATE", new_body="something", summary="no change")


def test_curator_patch_update_branch_valid():
    p = CuratorPatch(
        decision="UPDATE",
        new_body="# weather-query\n\n## Steps\n1. New step",
        summary="Added JS fallback to step list",
    )
    assert p.decision == "UPDATE"


def test_curator_patch_no_update_branch_valid():
    p = CuratorPatch(
        decision="NO_UPDATE",
        new_body=None,
        summary="Skill already covers this case",
    )
    assert p.decision == "NO_UPDATE"
    assert p.new_body is None
```

- [ ] **Step 2: Run, expect FAIL (ImportError)**

```bash
.venv/Scripts/pytest tests/test_enhancer_schemas.py -v
```

- [ ] **Step 3: Implement `skill_engine/enhancer_schemas.py`**

```python
"""Pydantic schemas for the skill enhancer's two-stage LLM output (Actor + Curator)."""
from typing import Literal

from pydantic import BaseModel, Field, model_validator


class ActorReflection(BaseModel):
    """First-stage LLM output: reflection on skill usage in the just-completed turn."""

    skill_name: str = Field(
        ..., min_length=1, max_length=64,
        description="The kebab-case name of the skill being reflected upon.",
    )
    issues_found: list[str] = Field(
        default_factory=list, max_length=5,
        description="Up to 5 things that didn't work or could be better. Empty if skill worked perfectly.",
    )
    new_insights: list[str] = Field(
        default_factory=list, max_length=5,
        description="Up to 5 new edge cases / improvements discovered during this run.",
    )
    overall_assessment: str = Field(
        ..., min_length=10, max_length=600,
        description="1-3 sentences summarizing usefulness + needed changes.",
    )


class CuratorPatch(BaseModel):
    """Second-stage LLM output: patch decision + new body (when UPDATE)."""

    decision: Literal["UPDATE", "NO_UPDATE"]
    new_body: str | None = Field(
        default=None, max_length=10_000,
        description="Required when decision=UPDATE — the fully rewritten Markdown body (without frontmatter). null otherwise.",
    )
    summary: str = Field(
        ..., min_length=1, max_length=200,
        description="One-line summary for HISTORY.md (e.g. 'Added JS-rendered table fallback').",
    )

    @model_validator(mode="after")
    def _consistency(self) -> "CuratorPatch":
        if self.decision == "UPDATE" and not self.new_body:
            raise ValueError("decision=UPDATE requires new_body to be a non-empty string")
        if self.decision == "NO_UPDATE" and self.new_body is not None:
            raise ValueError("decision=NO_UPDATE must have new_body=null")
        return self
```

- [ ] **Step 4: Run, expect 7 PASS**

```bash
.venv/Scripts/pytest tests/test_enhancer_schemas.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/skill_engine/enhancer_schemas.py backend/tests/test_enhancer_schemas.py
git commit -m "feat(backend): Actor + Curator Pydantic schemas for skill enhancer"
```

---

### Task 1.2: Diff helper + version bump utility

**Files:**
- Create: `FF-OpenHermes/backend/skill_engine/diff.py`
- Create: `FF-OpenHermes/backend/tests/test_skill_diff.py`

Encapsulates: (a) producing a unified diff between old and new SKILL.md body for HISTORY.md inclusion, (b) bumping a semver minor version (1.0 → 1.1, 1.5 → 1.6), (c) replacing the `version:` line in frontmatter.

- [ ] **Step 1: Write failing tests**

`backend/tests/test_skill_diff.py`:

```python
"""Tests for diff helper + version bump."""
from skill_engine.diff import unified_diff_str, bump_minor_version, replace_frontmatter_version, replace_skill_body


def test_unified_diff_added_line():
    old = "line a\nline b\nline c\n"
    new = "line a\nline b\nline b.5\nline c\n"
    diff = unified_diff_str(old, new, label="SKILL.md")
    assert "+line b.5" in diff
    assert "@@" in diff  # hunk header present


def test_unified_diff_no_change_returns_empty_or_no_hunk():
    old = "line a\n"
    new = "line a\n"
    diff = unified_diff_str(old, new, label="SKILL.md")
    # No hunks when there are no changes
    assert "@@" not in diff


def test_bump_minor_version_simple():
    assert bump_minor_version("1.0") == "1.1"
    assert bump_minor_version("1.5") == "1.6"
    assert bump_minor_version("2.9") == "2.10"


def test_bump_minor_version_invalid_input():
    # Non-numeric falls back to "1.1"
    assert bump_minor_version("abc") == "1.1"


def test_replace_frontmatter_version():
    before = "---\nname: x\nversion: 1.0\nfoo: bar\n---\n# title"
    after = replace_frontmatter_version(before, "1.1")
    assert "version: 1.1" in after
    assert "name: x" in after  # other lines preserved
    assert "version: 1.0" not in after


def test_replace_frontmatter_version_when_missing_appends():
    """If `version:` line is missing in frontmatter, insert one."""
    before = "---\nname: x\nfoo: bar\n---\n# title"
    after = replace_frontmatter_version(before, "1.1")
    assert "version: 1.1" in after


def test_replace_skill_body_swaps_after_frontmatter():
    full_md = "---\nname: x\nversion: 1.0\n---\n\n# old body\nold content"
    new_md = replace_skill_body(full_md, "# new body\nnew content")
    assert "# new body" in new_md
    assert "# old body" not in new_md
    assert "name: x" in new_md  # frontmatter preserved
```

- [ ] **Step 2: Run, expect FAIL**

```bash
.venv/Scripts/pytest tests/test_skill_diff.py -v
```

- [ ] **Step 3: Implement `skill_engine/diff.py`**

```python
"""Diff and version-bump utilities for the skill enhancer.

Pure-Python: uses stdlib `difflib`. No new dependencies.
"""
import difflib
import re


def unified_diff_str(old: str, new: str, label: str = "skill") -> str:
    """Return unified-diff text between old and new strings. Empty result if no changes."""
    old_lines = old.splitlines(keepends=True)
    new_lines = new.splitlines(keepends=True)
    diff_lines = list(difflib.unified_diff(
        old_lines, new_lines,
        fromfile=f"a/{label}", tofile=f"b/{label}", n=2,
    ))
    return "".join(diff_lines)


def bump_minor_version(current: str) -> str:
    """Bump a 'major.minor' version string by 1 in the minor. Falls back to '1.1' on parse failure."""
    m = re.match(r"^(\d+)\.(\d+)$", current.strip())
    if not m:
        return "1.1"
    major, minor = int(m.group(1)), int(m.group(2))
    return f"{major}.{minor + 1}"


_FRONTMATTER_RE = re.compile(r"(^---\n)(.+?)(\n---\n)", re.DOTALL)
_VERSION_LINE_RE = re.compile(r"^version:\s*\S+\s*$", re.MULTILINE)


def replace_frontmatter_version(skill_md: str, new_version: str) -> str:
    """Replace (or insert) the `version:` line inside SKILL.md frontmatter.

    If the frontmatter has no `version:` line, append one before the closing `---`.
    """
    m = _FRONTMATTER_RE.match(skill_md)
    if not m:
        # No frontmatter — return as-is. (This shouldn't happen for skills written
        # by the generator/enhancer, but be defensive.)
        return skill_md
    fm_body = m.group(2)
    if _VERSION_LINE_RE.search(fm_body):
        new_fm = _VERSION_LINE_RE.sub(f"version: {new_version}", fm_body)
    else:
        new_fm = fm_body.rstrip() + f"\nversion: {new_version}"
    return m.group(1) + new_fm + m.group(3) + skill_md[m.end():]


def replace_skill_body(skill_md: str, new_body: str) -> str:
    """Replace the body (everything after the closing `---`) with new_body. Frontmatter preserved."""
    m = _FRONTMATTER_RE.match(skill_md)
    if not m:
        # No frontmatter — replace whole content with new_body (defensive)
        return new_body
    return skill_md[: m.end()] + "\n" + new_body.lstrip("\n")
```

- [ ] **Step 4: Run, expect 7 PASS**

```bash
.venv/Scripts/pytest tests/test_skill_diff.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/skill_engine/diff.py backend/tests/test_skill_diff.py
git commit -m "feat(backend): diff + version-bump helpers for enhancer (difflib-based)"
```

---

### Task 1.3: Extend `detect.py` with `extract_used_skill_names`

**Files:**
- Modify: `FF-OpenHermes/backend/skill_engine/detect.py` (add function)
- Modify: `FF-OpenHermes/backend/tests/test_skill_detect.py` (add tests)

The middleware needs to know WHICH skills were loaded in this turn so it can target them for enhancement.

- [ ] **Step 1: Add failing tests**

Append to `tests/test_skill_detect.py`:

```python
def test_extract_used_skill_names_finds_all_read_skill_calls():
    msgs = _t(
        HumanMessage(content="x"),
        AIMessage(content="loading", tool_calls=[
            {"id": "1", "name": "read_skill", "args": {"name": "weather-query"}},
            {"id": "2", "name": "terminal", "args": {}},
        ]),
        ToolMessage(content="...", tool_call_id="1"),
        ToolMessage(content="...", tool_call_id="2"),
        AIMessage(content="loading another", tool_calls=[
            {"id": "3", "name": "read_skill", "args": {"name": "data-export"}},
        ]),
    )
    from skill_engine.detect import extract_used_skill_names
    names = extract_used_skill_names(msgs)
    assert sorted(names) == ["data-export", "weather-query"]


def test_extract_used_skill_names_dedupes():
    msgs = _t(
        HumanMessage(content="x"),
        AIMessage(content="", tool_calls=[
            {"id": "1", "name": "read_skill", "args": {"name": "x"}},
            {"id": "2", "name": "read_skill", "args": {"name": "x"}},
        ]),
    )
    from skill_engine.detect import extract_used_skill_names
    assert extract_used_skill_names(msgs) == ["x"]


def test_extract_used_skill_names_returns_empty_when_no_read_skill():
    msgs = _t(
        HumanMessage(content="x"),
        AIMessage(content="", tool_calls=[
            {"id": "1", "name": "terminal", "args": {}},
        ]),
    )
    from skill_engine.detect import extract_used_skill_names
    assert extract_used_skill_names(msgs) == []


def test_extract_used_skill_names_skips_malformed_args():
    msgs = _t(
        HumanMessage(content="x"),
        AIMessage(content="", tool_calls=[
            {"id": "1", "name": "read_skill", "args": {}},  # missing name
            {"id": "2", "name": "read_skill", "args": {"name": "good-skill"}},
        ]),
    )
    from skill_engine.detect import extract_used_skill_names
    assert extract_used_skill_names(msgs) == ["good-skill"]
```

- [ ] **Step 2: Run, expect FAIL (ImportError on extract_used_skill_names)**

```bash
.venv/Scripts/pytest tests/test_skill_detect.py -v
```

- [ ] **Step 3: Add `extract_used_skill_names` to `skill_engine/detect.py`**

Append to `skill_engine/detect.py`:

```python
def extract_used_skill_names(messages: Iterable) -> list[str]:
    """Return list of distinct skill names that were loaded via `read_skill` in this turn.

    Order: first-occurrence order of distinct names. Skips malformed tool_call args
    (missing or non-string `name` field).
    """
    seen: list[str] = []
    for m in messages:
        for tc in getattr(m, "tool_calls", []) or []:
            if tc.get("name") != "read_skill":
                continue
            args = tc.get("args") or {}
            sn = args.get("name") if isinstance(args, dict) else None
            if isinstance(sn, str) and sn and sn not in seen:
                seen.append(sn)
    return seen
```

- [ ] **Step 4: Run, expect 4 new tests + 4 existing PASS = 8 total**

```bash
.venv/Scripts/pytest tests/test_skill_detect.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/skill_engine/detect.py backend/tests/test_skill_detect.py
git commit -m "feat(backend): extract_used_skill_names helper for M3 enhancer dispatch"
```

---

## Phase 2 — Enhancer Core

### Task 2.1: `skill_engine/enhancer.py` — two-stage LLM enhancement

**Files:**
- Create: `FF-OpenHermes/backend/skill_engine/enhancer.py`
- Create: `FF-OpenHermes/backend/tests/test_skill_enhancer.py`

The core enhancer: given (messages, session_dir, skill_name, llm_factory) — runs Actor → Curator → applies patch → writes new SKILL.md + appends HISTORY.md with embedded diff. Returns metadata or None on skip/failure.

- [ ] **Step 1: Write failing tests**

`backend/tests/test_skill_enhancer.py`:

```python
"""Tests for the skill enhancer (Actor + Curator + diff + persistence)."""
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest
from langchain_core.language_models.fake_chat_models import FakeListChatModel
from langchain_core.messages import HumanMessage, AIMessage, ToolMessage

from agent.skill_ops import SkillOps
from skill_engine.enhancer import enhance_skill_from_turn, was_enhanced_recently
from skill_engine.enhancer_schemas import ActorReflection, CuratorPatch


class StagedFake(FakeListChatModel):
    """Returns successive structured responses from `staged_responses` queue."""

    staged_responses: list = []

    def with_structured_output(self, schema, **kwargs):  # type: ignore[override]
        outer = self

        class StructuredRunnable:
            async def ainvoke(self, prompt):
                if not outer.staged_responses:
                    raise RuntimeError("StagedFake out of responses")
                payload = outer.staged_responses.pop(0)
                if isinstance(payload, Exception):
                    raise payload
                return schema.model_validate(payload)

        return StructuredRunnable()

    def bind_tools(self, tools, **kwargs):
        return self


@pytest.fixture
def session_dir_with_skill(tmp_path: Path) -> tuple[Path, str]:
    """Create a session dir with one skill (extract-web-table) at v1.0."""
    sd = tmp_path / "sess"
    (sd / "skills" / "extract-web-table").mkdir(parents=True)
    skill_md = (
        "---\n"
        "name: extract-web-table\n"
        'description: "Scrape HTML tables. Use when extracting tables."\n'
        "version: 1.0\n"
        "generated_by: agent\n"
        "---\n\n"
        "# extract-web-table\n\n"
        "## Overview\n"
        "Fetch HTML, parse table, write xlsx.\n\n"
        "## Steps\n"
        "1. fetch_url\n"
        "2. parse with BeautifulSoup\n"
        "3. write_file\n"
    )
    (sd / "skills" / "extract-web-table" / "SKILL.md").write_text(skill_md, encoding="utf-8")
    (sd / "skills" / "extract-web-table" / "HISTORY.md").write_text(
        "# Evolution History · extract-web-table\n\n"
        "## v1.0 · 2026-04-29 09:00 · 🤖 Auto-Generated\nInitial version.\n",
        encoding="utf-8",
    )
    (sd / "skills" / "SKILLS_SNAPSHOT.md").write_text("# snapshot\n", encoding="utf-8")
    (sd / "loaded_skills.json").write_text('[{"name":"extract-web-table","level":1}]', encoding="utf-8")
    return sd, "extract-web-table"


def _execution_trace() -> list:
    return [
        HumanMessage(content="Scrape cnbeta.com prices"),
        AIMessage(content="Loading skill", tool_calls=[
            {"id": "1", "name": "read_skill", "args": {"name": "extract-web-table"}},
        ]),
        ToolMessage(content="...skill body...", tool_call_id="1"),
        AIMessage(content="Fetching", tool_calls=[
            {"id": "2", "name": "fetch_url", "args": {"url": "https://cnbeta.com"}},
        ]),
        ToolMessage(content="<empty: js-rendered>", tool_call_id="2"),
        AIMessage(content="Hmm, JS site. Done with caveat."),
    ]


@pytest.mark.asyncio
async def test_enhancer_writes_v1_1_when_curator_says_update(session_dir_with_skill):
    sd, name = session_dir_with_skill
    fake = StagedFake(responses=[])
    fake.staged_responses = [
        # Actor reflection
        {
            "skill_name": name,
            "issues_found": ["JS-rendered tables come back empty from fetch_url"],
            "new_insights": ["Fall back to browser_use for JS sites"],
            "overall_assessment": "Skill works for static HTML; needs JS fallback.",
        },
        # Curator patch
        {
            "decision": "UPDATE",
            "new_body": (
                "# extract-web-table\n\n"
                "## Overview\n"
                "Fetch HTML, parse table, write xlsx. Falls back to browser_use for JS sites.\n\n"
                "## Steps\n"
                "1. fetch_url (or browser_use for JS-rendered pages)\n"
                "2. parse with BeautifulSoup\n"
                "3. write_file\n\n"
                "## Edge Cases\n"
                "- JS-rendered tables: use browser_use instead of fetch_url\n"
            ),
            "summary": "Added JS-rendered table fallback to browser_use",
        },
    ]

    result = await enhance_skill_from_turn(
        messages=_execution_trace(),
        session_dir=sd,
        skill_name=name,
        llm_factory=lambda: fake,
    )

    assert result is not None
    assert result["new_version"] == "1.1"
    assert result["summary"].startswith("Added JS")

    # SKILL.md should now have version 1.1 + new body
    md = (sd / "skills" / name / "SKILL.md").read_text(encoding="utf-8")
    assert "version: 1.1" in md
    assert "browser_use" in md

    # HISTORY.md should have new entry with diff
    history = (sd / "skills" / name / "HISTORY.md").read_text(encoding="utf-8")
    assert "v1.1" in history
    assert "🤖 Auto-Enhanced" in history
    assert "browser_use" in history  # diff content


@pytest.mark.asyncio
async def test_enhancer_no_update_does_not_change_skill(session_dir_with_skill):
    sd, name = session_dir_with_skill
    fake = StagedFake(responses=[])
    fake.staged_responses = [
        {
            "skill_name": name,
            "issues_found": [],
            "new_insights": [],
            "overall_assessment": "Worked perfectly.",
        },
        {
            "decision": "NO_UPDATE",
            "new_body": None,
            "summary": "Skill already covers this case",
        },
    ]
    result = await enhance_skill_from_turn(
        messages=_execution_trace(),
        session_dir=sd,
        skill_name=name,
        llm_factory=lambda: fake,
    )
    assert result is None
    md = (sd / "skills" / name / "SKILL.md").read_text(encoding="utf-8")
    assert "version: 1.0" in md  # unchanged
    history = (sd / "skills" / name / "HISTORY.md").read_text(encoding="utf-8")
    assert "v1.1" not in history


@pytest.mark.asyncio
async def test_enhancer_returns_none_on_actor_failure(session_dir_with_skill):
    sd, name = session_dir_with_skill
    fake = StagedFake(responses=[])
    fake.staged_responses = [RuntimeError("upstream blew up")]
    result = await enhance_skill_from_turn(
        messages=_execution_trace(),
        session_dir=sd,
        skill_name=name,
        llm_factory=lambda: fake,
    )
    assert result is None
    md = (sd / "skills" / name / "SKILL.md").read_text(encoding="utf-8")
    assert "version: 1.0" in md  # unchanged


@pytest.mark.asyncio
async def test_enhancer_returns_none_on_curator_failure(session_dir_with_skill):
    sd, name = session_dir_with_skill
    fake = StagedFake(responses=[])
    fake.staged_responses = [
        {
            "skill_name": name, "issues_found": [], "new_insights": [],
            "overall_assessment": "ok",
        },
        RuntimeError("curator crashed"),
    ]
    result = await enhance_skill_from_turn(
        messages=_execution_trace(),
        session_dir=sd,
        skill_name=name,
        llm_factory=lambda: fake,
    )
    assert result is None


@pytest.mark.asyncio
async def test_enhancer_returns_none_when_skill_missing(tmp_path: Path):
    sd = tmp_path / "sess"
    (sd / "skills").mkdir(parents=True)
    fake = StagedFake(responses=[])
    fake.staged_responses = []  # not consumed
    result = await enhance_skill_from_turn(
        messages=_execution_trace(),
        session_dir=sd,
        skill_name="ghost-skill",
        llm_factory=lambda: fake,
    )
    assert result is None


def test_was_enhanced_recently_true_within_window(tmp_path: Path):
    skill_dir = tmp_path / "skill"
    skill_dir.mkdir()
    now = datetime.now(timezone.utc)
    just_now = (now - timedelta(minutes=2)).strftime("%Y-%m-%d %H:%M")
    (skill_dir / "HISTORY.md").write_text(
        f"# History\n\n## v1.5 · {just_now} UTC · 🤖 Auto-Enhanced · added X\nstuff\n",
        encoding="utf-8",
    )
    assert was_enhanced_recently(skill_dir, within_minutes=5) is True


def test_was_enhanced_recently_false_outside_window(tmp_path: Path):
    skill_dir = tmp_path / "skill"
    skill_dir.mkdir()
    now = datetime.now(timezone.utc)
    long_ago = (now - timedelta(minutes=10)).strftime("%Y-%m-%d %H:%M")
    (skill_dir / "HISTORY.md").write_text(
        f"# History\n\n## v1.5 · {long_ago} UTC · 🤖 Auto-Enhanced · added X\n",
        encoding="utf-8",
    )
    assert was_enhanced_recently(skill_dir, within_minutes=5) is False


def test_was_enhanced_recently_false_when_history_missing(tmp_path: Path):
    skill_dir = tmp_path / "skill"
    skill_dir.mkdir()
    assert was_enhanced_recently(skill_dir, within_minutes=5) is False


def test_was_enhanced_recently_false_when_no_enhanced_entry(tmp_path: Path):
    skill_dir = tmp_path / "skill"
    skill_dir.mkdir()
    (skill_dir / "HISTORY.md").write_text(
        "# History\n\n## v1.0 · 2026-04-29 10:00 UTC · 🤖 Auto-Generated · initial\n",
        encoding="utf-8",
    )
    # Only Auto-Generated, no Auto-Enhanced — should be False
    assert was_enhanced_recently(skill_dir, within_minutes=5) is False
```

- [ ] **Step 2: Run, expect FAIL (ImportError)**

```bash
.venv/Scripts/pytest tests/test_skill_enhancer.py -v
```

- [ ] **Step 3: Implement `skill_engine/enhancer.py`**

```python
"""Skill enhancer — two-stage LLM (Actor + Curator) that patches an existing SKILL.md.

Triggered when a turn called `read_skill('<name>')` (i.e. the user/agent re-used a skill).
The enhancer reflects on the actual run, decides whether the skill needs updating, and if
so produces a new body + appends a HISTORY.md entry with embedded unified diff.

Like the generator, all failures are caught and swallowed (returns None). Safe to call
from a background `asyncio.create_task`.
"""
import logging
import re
import traceback
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import BaseMessage
from pydantic import ValidationError

from agent.skill_ops import SkillOps
from skill_engine.diff import (
    bump_minor_version,
    replace_frontmatter_version,
    replace_skill_body,
    unified_diff_str,
)
from skill_engine.enhancer_schemas import ActorReflection, CuratorPatch

logger = logging.getLogger("skill_engine.enhancer")

ACTOR_SYSTEM_PROMPT = """You are reflecting on a skill's just-completed usage. The agent loaded an existing SKILL.md, then ran a turn that may have revealed:

- Issues: steps that didn't work or felt clunky
- New insights: edge cases or improvements not in the original SKILL.md

Output a structured ActorReflection with:
- `skill_name`: the kebab-case name of the loaded skill
- `issues_found` (list, max 5): things that didn't work
- `new_insights` (list, max 5): improvements / edge cases discovered
- `overall_assessment` (1-3 sentences): is the skill good as-is or does it need updating?

If the skill worked perfectly, return empty lists and an assessment that says so.
"""

CURATOR_SYSTEM_PROMPT = """You are deciding whether to patch a SKILL.md based on a reflection report.

Output a CuratorPatch with:
- `decision`: "UPDATE" if changes are warranted, "NO_UPDATE" if the skill is fine as-is
- `new_body`: required when decision=UPDATE — the FULLY REWRITTEN Markdown body (without frontmatter, starting with `# {skill_name}` H1). Preserve good content; integrate fixes for issues; document new edge cases.
- `summary`: one-line description for HISTORY.md (e.g. "Added JS-rendered table fallback")

Default to NO_UPDATE when:
- Reflection's issues_found and new_insights are both empty
- Changes would be cosmetic / not actionable
- The fixes would over-fit to one specific run
"""


def _format_trace(messages: list[BaseMessage]) -> str:
    lines: list[str] = []
    for m in messages:
        role = getattr(m, "type", None)
        content = (getattr(m, "content", "") or "").strip()
        if role == "human":
            lines.append(f"USER: {content}")
        elif role == "ai":
            tcs = getattr(m, "tool_calls", []) or []
            if content:
                lines.append(f"ASSISTANT: {content}")
            for tc in tcs:
                lines.append(f"  TOOL_CALL: {tc.get('name')}({tc.get('args', {})})")
        elif role == "tool":
            short = content[:300] + ("…" if len(content) > 300 else "")
            lines.append(f"  TOOL_RESULT: {short}")
    return "\n".join(lines)


async def _invoke_with_retry(structured, prompt: str, schema_name: str, retries: int = 1):
    last_err: Exception | None = None
    for attempt in range(retries + 1):
        try:
            return await structured.ainvoke(prompt)
        except ValidationError as e:
            last_err = e
            logger.warning("%s output failed Pydantic validation (attempt %d): %s", schema_name, attempt + 1, e)
        except Exception as e:
            last_err = e
            logger.warning("%s LLM call failed (attempt %d): %s", schema_name, attempt + 1, e)
            break
    if last_err:
        logger.warning("%s gave up after retries: %s", schema_name, last_err)
    return None


def was_enhanced_recently(skill_dir: Path, within_minutes: int = 5) -> bool:
    """Check HISTORY.md for an Auto-Enhanced entry whose timestamp is within `within_minutes` of now.

    Used as a debounce: if the same skill was already enhanced very recently, skip another run.
    Format expected: `## v1.X · YYYY-MM-DD HH:MM UTC · 🤖 Auto-Enhanced · ...`
    """
    history_path = skill_dir / "HISTORY.md"
    if not history_path.exists():
        return False
    text = history_path.read_text(encoding="utf-8", errors="replace")
    # NOTE: regex is NOT anchored on `##` because SkillOps._append_history prepends
    # its own `## YYYY-MM-DD HH:MM` header before the caller's history_line. Production
    # HISTORY.md format puts the v1.X · TS · 🤖 Auto-Enhanced line on its own (without ##).
    # Pattern matches anywhere in the file.
    pattern = re.compile(
        r"v\d+\.\d+\s+·\s+(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2})(?:\s+UTC)?\s+·\s+🤖\s*Auto-Enhanced"
    )
    cutoff = datetime.now(timezone.utc) - timedelta(minutes=within_minutes)
    for m in pattern.finditer(text):
        ts_str = m.group(1)
        try:
            ts = datetime.strptime(ts_str, "%Y-%m-%d %H:%M").replace(tzinfo=timezone.utc)
            if ts >= cutoff:
                return True
        except ValueError:
            continue
    return False


async def enhance_skill_from_turn(
    messages: list[BaseMessage],
    session_dir: Path,
    skill_name: str,
    llm_factory: Callable[[], BaseChatModel],
) -> dict[str, Any] | None:
    """Top-level enhancer. Returns {new_version, summary} on UPDATE; None on skip/failure."""
    try:
        ops = SkillOps(session_dir)
        try:
            old_md = ops.read_skill(skill_name)
        except FileNotFoundError:
            logger.warning("enhance_skill_from_turn: skill %s not found", skill_name)
            return None

        # ── Actor stage ─────────────────────────────────────────
        llm = llm_factory()
        actor_runnable = llm.with_structured_output(ActorReflection, method="function_calling")
        actor_prompt = (
            ACTOR_SYSTEM_PROMPT
            + f"\n\n--- LOADED SKILL ({skill_name}) ---\n"
            + old_md
            + "\n\n--- EXECUTION TRACE ---\n"
            + _format_trace(messages)
            + "\n\nProvide your reflection now."
        )
        reflection = await _invoke_with_retry(actor_runnable, actor_prompt, "Actor", retries=1)
        if reflection is None:
            return None
        if not isinstance(reflection, ActorReflection):
            try:
                reflection = ActorReflection.model_validate(reflection)
            except ValidationError as e:
                logger.warning("Actor result failed final validation: %s", e)
                return None

        # ── Curator stage ──────────────────────────────────────
        curator_runnable = llm.with_structured_output(CuratorPatch, method="function_calling")
        curator_prompt = (
            CURATOR_SYSTEM_PROMPT
            + f"\n\n--- CURRENT SKILL ({skill_name}) ---\n"
            + old_md
            + "\n\n--- REFLECTION ---\n"
            + f"issues_found: {reflection.issues_found}\n"
            + f"new_insights: {reflection.new_insights}\n"
            + f"overall_assessment: {reflection.overall_assessment}\n"
            + "\nDecide UPDATE or NO_UPDATE now."
        )
        patch = await _invoke_with_retry(curator_runnable, curator_prompt, "Curator", retries=1)
        if patch is None:
            return None
        if not isinstance(patch, CuratorPatch):
            try:
                patch = CuratorPatch.model_validate(patch)
            except ValidationError as e:
                logger.warning("Curator result failed final validation: %s", e)
                return None

        if patch.decision == "NO_UPDATE":
            logger.info("Curator decided NO_UPDATE for %s", skill_name)
            return None

        # ── Apply patch ─────────────────────────────────────────
        # Extract current body for diff
        old_body_match = re.search(r"^---\n.+?\n---\n\n?(.*)$", old_md, flags=re.DOTALL)
        old_body = old_body_match.group(1) if old_body_match else old_md

        # Bump version
        version_match = re.search(r"^version:\s*(\S+)\s*$", old_md, flags=re.MULTILINE)
        old_version = version_match.group(1) if version_match else "1.0"
        new_version = bump_minor_version(old_version)

        # Build new SKILL.md: replace body, then bump version
        new_md = replace_skill_body(old_md, patch.new_body or "")
        new_md = replace_frontmatter_version(new_md, new_version)

        # Compute diff for HISTORY
        diff_text = unified_diff_str(old_body, patch.new_body or "", label="SKILL.md")

        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M") + " UTC"
        history_line = (
            f"v{new_version} · {ts} · 🤖 Auto-Enhanced · {patch.summary}\n\n"
            "```diff\n"
            + (diff_text if diff_text else "(no textual diff — body identical?)")
            + "\n```"
        )
        ops.write_skill(skill_name, new_md, history_line=history_line)

        logger.info("Enhanced skill %s → v%s: %s", skill_name, new_version, patch.summary)
        return {"new_version": new_version, "summary": patch.summary, "skill_name": skill_name}

    except Exception as e:
        logger.error("enhance_skill_from_turn unhandled error: %s\n%s", e, traceback.format_exc())
        return None
```

- [ ] **Step 4: Run, expect 9 PASS**

```bash
.venv/Scripts/pytest tests/test_skill_enhancer.py -v
```

- [ ] **Step 5: Commit**

```bash
git add backend/skill_engine/enhancer.py backend/tests/test_skill_enhancer.py
git commit -m "feat(backend): skill enhancer (Actor + Curator + diff + version bump + debounce)"
```

---

## Phase 3 — Middleware Extension

### Task 3.1: Wire enhancer into middleware

**Files:**
- Modify: `FF-OpenHermes/backend/agent/middleware.py`
- Modify: `FF-OpenHermes/backend/tests/test_skill_middleware.py` (add 2 tests)

The current middleware has this branch in `run_for_session`:

```python
if used_existing_skill(messages):
    logger.debug("...skipping generation (M3 will handle)", session_id)
    return
```

M3 turns this into "dispatch enhancer for each used skill". Also publish `skill_enhancement_started` immediately (before the LLM call) and `skill_enhanced` on success.

- [ ] **Step 1: Add failing tests for the new dispatch branch**

Append to `tests/test_skill_middleware.py`:

```python
@pytest.mark.asyncio
async def test_middleware_dispatches_enhancer_when_skill_was_used(setup, monkeypatch):
    """When a turn called read_skill, middleware should call enhancer (not generator)."""
    sm, meta, bus = setup

    enhance_mock = AsyncMock(return_value={"new_version": "1.1", "summary": "Added X", "skill_name": "weather-query"})
    monkeypatch.setattr("agent.middleware.enhance_skill_from_turn", enhance_mock)

    generate_mock = AsyncMock(return_value=None)
    monkeypatch.setattr("agent.middleware.generate_skill_from_turn", generate_mock)

    mw = SkillEngineMiddleware(
        session_manager=sm, event_bus=bus,
        llm_factory=lambda: MagicMock(), threshold=3,
    )

    # Turn that USED a skill — read_skill('weather-query') + 3 other tool calls
    msgs = [
        HumanMessage(content="x"),
        AIMessage(content="loading", tool_calls=[
            {"id": "1", "name": "read_skill", "args": {"name": "weather-query"}},
        ]),
        ToolMessage(content="...", tool_call_id="1"),
        AIMessage(content="working", tool_calls=[
            {"id": "2", "name": "terminal", "args": {}},
            {"id": "3", "name": "terminal", "args": {}},
            {"id": "4", "name": "terminal", "args": {}},
        ]),
    ]
    await mw.run_for_session(meta.id, msgs)

    enhance_mock.assert_called_once()
    generate_mock.assert_not_called()
    # Stats: skills_enhanced incremented
    assert sm.get(meta.id).stats.skills_enhanced == 1


@pytest.mark.asyncio
async def test_middleware_publishes_started_and_enhanced_events(setup, monkeypatch):
    sm, meta, bus = setup

    enhance_mock = AsyncMock(return_value={
        "new_version": "1.1", "summary": "Added X", "skill_name": "weather-query",
    })
    monkeypatch.setattr("agent.middleware.enhance_skill_from_turn", enhance_mock)

    received: list[dict] = []

    async def consume():
        async with bus.subscribe(meta.id) as q:
            for _ in range(2):  # expect both started and enhanced
                ev = await asyncio.wait_for(q.get(), timeout=2.0)
                received.append(ev)

    consumer_task = asyncio.create_task(consume())
    await asyncio.sleep(0.05)

    mw = SkillEngineMiddleware(
        session_manager=sm, event_bus=bus,
        llm_factory=lambda: MagicMock(), threshold=3,
    )
    msgs = [
        HumanMessage(content="x"),
        AIMessage(content="", tool_calls=[
            {"id": "1", "name": "read_skill", "args": {"name": "weather-query"}},
        ]),
        ToolMessage(content="...", tool_call_id="1"),
        AIMessage(content="", tool_calls=[
            {"id": "2", "name": "terminal", "args": {}},
            {"id": "3", "name": "terminal", "args": {}},
            {"id": "4", "name": "terminal", "args": {}},
        ]),
    ]
    await mw.run_for_session(meta.id, msgs)
    await asyncio.wait_for(consumer_task, timeout=3.0)

    types = [e["type"] for e in received]
    assert "skill_enhancement_started" in types
    assert "skill_enhanced" in types
    enhanced_event = next(e for e in received if e["type"] == "skill_enhanced")
    assert enhanced_event["skill_name"] == "weather-query"
    assert enhanced_event["version"] == "1.1"
    assert enhanced_event["summary"] == "Added X"


@pytest.mark.asyncio
async def test_middleware_skips_when_recently_enhanced(setup, monkeypatch):
    sm, meta, bus = setup

    # Pretend was_enhanced_recently returns True (within debounce window)
    monkeypatch.setattr("agent.middleware.was_enhanced_recently", lambda skill_dir, within_minutes: True)

    enhance_mock = AsyncMock()
    monkeypatch.setattr("agent.middleware.enhance_skill_from_turn", enhance_mock)

    # Pre-create a skills dir so the path exists
    sdir = sm.session_dir(meta.id)
    (sdir / "skills" / "weather-query").mkdir(parents=True, exist_ok=True)

    mw = SkillEngineMiddleware(
        session_manager=sm, event_bus=bus,
        llm_factory=lambda: MagicMock(), threshold=3,
    )
    msgs = [
        HumanMessage(content="x"),
        AIMessage(content="", tool_calls=[
            {"id": "1", "name": "read_skill", "args": {"name": "weather-query"}},
        ]),
        ToolMessage(content="...", tool_call_id="1"),
        AIMessage(content="", tool_calls=[
            {"id": "2", "name": "terminal", "args": {}},
            {"id": "3", "name": "terminal", "args": {}},
            {"id": "4", "name": "terminal", "args": {}},
        ]),
    ]
    await mw.run_for_session(meta.id, msgs)

    enhance_mock.assert_not_called()
```

- [ ] **Step 2: Run, expect FAIL on the 3 new tests**

```bash
.venv/Scripts/pytest tests/test_skill_middleware.py -v
```

- [ ] **Step 3: Update `agent/middleware.py`**

Add imports at the top of the file (alongside the existing `from skill_engine.detect import ...`):

```python
from skill_engine.detect import (
    count_tool_calls_in_turn,
    used_existing_skill,
    extract_used_skill_names,
)
from skill_engine.enhancer import enhance_skill_from_turn, was_enhanced_recently
```

Replace the `run_for_session` method with the M3 branching version:

```python
    async def run_for_session(self, session_id: str, messages: list[Any]) -> None:
        """Public entry — decides between generate (new skill) and enhance (existing skill)."""
        try:
            tc_count = count_tool_calls_in_turn(messages)
            if tc_count < self._threshold:
                return

            try:
                meta = self._sm.get(session_id)
            except FileNotFoundError:
                logger.warning("session %s not found at after_agent time", session_id)
                return
            sdir = self._sm.session_dir(session_id)

            if used_existing_skill(messages):
                # M3 path: enhance each loaded skill (debounced)
                used_names = extract_used_skill_names(messages)
                for name in used_names:
                    skill_dir = sdir / "skills" / name
                    if not skill_dir.is_dir():
                        logger.debug("skill %s not on disk; skipping enhancement", name)
                        continue
                    if was_enhanced_recently(skill_dir, within_minutes=5):
                        logger.info("skill %s enhanced recently; skipping (debounce)", name)
                        continue

                    self._bus.publish(session_id, {
                        "type": "skill_enhancement_started",
                        "skill_name": name,
                    })

                    result = await enhance_skill_from_turn(
                        messages=messages,
                        session_dir=sdir,
                        skill_name=name,
                        llm_factory=self._llm_factory,
                    )
                    if result is None:
                        # Curator said NO_UPDATE or upstream failed — silent skip.
                        # Send a "finished without update" event so frontend can drop placeholder.
                        self._bus.publish(session_id, {
                            "type": "skill_enhancement_finished",
                            "skill_name": name,
                            "updated": False,
                        })
                        continue

                    self._sm.update_stats(session_id, skills_enhanced=1)
                    self._bus.publish(session_id, {
                        "type": "skill_enhanced",
                        "skill_name": result["skill_name"],
                        "version": result["new_version"],
                        "summary": result["summary"],
                    })
                    logger.info("session %s enhanced skill %s → v%s",
                                session_id, result["skill_name"], result["new_version"])
                return

            # M2 path: no skill loaded → maybe generate a new one
            result = await generate_skill_from_turn(
                messages=messages,
                session_dir=sdir,
                llm_factory=self._llm_factory,
            )
            if result is None:
                return
            self._sm.update_stats(session_id, skills_generated=1)
            self._bus.publish(session_id, {
                "type": "skill_generated",
                "name": result["name"],
                "description": result["description"],
            })
            logger.info("session %s generated skill: %s", session_id, result["name"])

        except Exception as e:
            logger.error("run_for_session error: %s", e)
```

- [ ] **Step 4: Run, expect all middleware tests + Phase 0/1/2 still PASS**

```bash
.venv/Scripts/pytest tests/test_skill_middleware.py -v
.venv/Scripts/pytest -v
```

Expected: full suite green. Phase 3 added 3 new tests; total at this point should be 111 (Phase 0) + 7 (1.1) + 7 (1.2) + 4 (1.3 new) + 9 (2.1) + 3 (3.1) = **141**. Wait — Phase 0 tasks added 3 tests (0.1, 0.2, 0.3) so Phase 0 total is 108 + 3 = 111. Then 1.1=7, 1.2=7, 1.3=4 new (was 4, now 8 — +4 added), 2.1=9, 3.1=3. So 111 + 7 + 7 + 4 + 9 + 3 = **141 passed**.

If less, recheck.

- [ ] **Step 5: Commit**

```bash
git add backend/agent/middleware.py backend/tests/test_skill_middleware.py
git commit -m "feat(backend): middleware dispatches enhancer when used_existing_skill (with debounce + 3 SSE events)"
```

---

## Phase 4 — Frontend types + eventStore

### Task 4.1: Frontend SkillEvent union + eventStore multi-event support

**Files:**
- Modify: `FF-OpenHermes/frontend/src/types/api.ts`
- Modify: `FF-OpenHermes/frontend/src/stores/eventStore.ts`

Convert `SkillGeneratedEvent` from a single interface to a discriminated union covering 4 variants. Update store to push each kind. Important: when `skill_enhancement_started` event arrives, we push a placeholder; when `skill_enhanced` or `skill_enhancement_finished` arrives for the same skill, we REPLACE the placeholder (not push duplicate).

- [ ] **Step 1: Update `src/types/api.ts`** — replace the existing `SkillGeneratedEvent` block with a union

Replace:

```ts
export interface SkillGeneratedEvent {
  type: "skill_generated";
  name: string;
  description: string;
  receivedAt: number;
}
```

With:

```ts
export interface SkillGeneratedEvent {
  type: "skill_generated";
  name: string;
  description: string;
  receivedAt: number;
}

export interface SkillEnhancementStartedEvent {
  type: "skill_enhancement_started";
  skillName: string;
  receivedAt: number;
}

export interface SkillEnhancedEvent {
  type: "skill_enhanced";
  skillName: string;
  version: string;
  summary: string;
  receivedAt: number;
}

export interface SkillEnhancementFinishedEvent {
  type: "skill_enhancement_finished";
  skillName: string;
  updated: boolean;
  receivedAt: number;
}

/** Union of all events flowing through the side-channel. */
export type SkillEvent =
  | SkillGeneratedEvent
  | SkillEnhancementStartedEvent
  | SkillEnhancedEvent
  | SkillEnhancementFinishedEvent;
```

- [ ] **Step 2: Replace `src/stores/eventStore.ts`** entirely

```ts
"use client";
import { create } from "zustand";
import type {
  SkillEvent,
  SkillEnhancedEvent,
  SkillEnhancementStartedEvent,
} from "@/types/api";

interface State {
  /** Events the user has not yet "seen" (cleared when navigating to /skills). */
  unread: SkillEvent[];
  /** Events shown inline in the chat stream of the current session. */
  inSession: SkillEvent[];

  pushSkillGenerated(ev: { name: string; description: string }): void;
  pushEnhancementStarted(ev: { skillName: string }): void;
  pushSkillEnhanced(ev: { skillName: string; version: string; summary: string }): void;
  pushEnhancementFinished(ev: { skillName: string; updated: boolean }): void;

  markAllSeen(): void;
  resetForSession(): void;
}

export const useEventStore = create<State>((set) => ({
  unread: [],
  inSession: [],

  pushSkillGenerated(ev) {
    const full: SkillEvent = {
      type: "skill_generated",
      name: ev.name,
      description: ev.description,
      receivedAt: Date.now(),
    };
    set((s) => ({
      unread: [...s.unread, full],
      inSession: [...s.inSession, full],
    }));
  },

  pushEnhancementStarted(ev) {
    const full: SkillEnhancementStartedEvent = {
      type: "skill_enhancement_started",
      skillName: ev.skillName,
      receivedAt: Date.now(),
    };
    // Don't add to unread — placeholders shouldn't trigger nav red dot.
    // Append to inSession so the placeholder card renders immediately.
    set((s) => ({
      inSession: [...s.inSession, full],
    }));
  },

  pushSkillEnhanced(ev) {
    const full: SkillEnhancedEvent = {
      type: "skill_enhanced",
      skillName: ev.skillName,
      version: ev.version,
      summary: ev.summary,
      receivedAt: Date.now(),
    };
    set((s) => ({
      unread: [...s.unread, full],
      // Replace any matching `enhancement_started` placeholder for this skill;
      // otherwise append.
      inSession: replaceStartedOrAppend(s.inSession, full),
    }));
  },

  pushEnhancementFinished(ev) {
    // No update branch — drop the placeholder if any, do not add unread.
    set((s) => ({
      inSession: s.inSession.filter((it) =>
        !(it.type === "skill_enhancement_started" && it.skillName === ev.skillName)
      ),
    }));
  },

  markAllSeen() {
    set({ unread: [] });
  },

  resetForSession() {
    set({ unread: [], inSession: [] });
  },
}));

function replaceStartedOrAppend(list: SkillEvent[], replacement: SkillEnhancedEvent): SkillEvent[] {
  const idx = list.findIndex(
    (it) => it.type === "skill_enhancement_started" && it.skillName === replacement.skillName
  );
  if (idx === -1) return [...list, replacement];
  const next = [...list];
  next[idx] = replacement;
  return next;
}
```

- [ ] **Step 3: Verify build (no test for store yet — pure types + UI work)**

```bash
cd "E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes/frontend"
npm run build
```

Expected: clean compile (will likely surface TypeScript errors in `useEventStream.ts`, `SkillEventCard.tsx`, `ChatPanel.tsx`, `NavSidebar.tsx` if any of them reference the OLD `SkillGeneratedEvent` shape). **Note — those errors will be fixed in Phase 5 tasks.** If build fails ONLY due to those files, that's expected — proceed to Phase 5 immediately. If build fails for unrelated reasons, STOP and investigate.

- [ ] **Step 4: Commit (build may not be clean yet — frontend Phase 5 tasks complete it)**

```bash
git add frontend/src/types/api.ts frontend/src/stores/eventStore.ts
git commit -m "feat(frontend): SkillEvent union + eventStore methods for enhancement lifecycle"
```

---

## Phase 5 — Frontend UI

### Task 5.1: useEventStream — add new event branches

**Files:**
- Modify: `FF-OpenHermes/frontend/src/hooks/useEventStream.ts`

The hook currently only handles `skill_generated`. Add 3 more branches matching the new SSE event types.

- [ ] **Step 1: Replace the event-dispatch block in `useEventStream.ts`**

Find the current handler block (the `if (event === "skill_generated" && ...)` line) and replace it. The full updated dispatch logic:

Locate this section:

```ts
              if (event === "skill_generated" && data && typeof data === "object") {
                const d = data as { name?: string; description?: string };
                if (d.name) pushSkillGenerated({ name: d.name, description: d.description ?? "" });
              }
              // ready / ping / unknown events ignored
```

Replace with:

```ts
              if (data && typeof data === "object") {
                const d = data as Record<string, unknown>;
                if (event === "skill_generated") {
                  const name = String(d.name ?? "");
                  if (name) pushSkillGenerated({ name, description: String(d.description ?? "") });
                } else if (event === "skill_enhancement_started") {
                  const skillName = String(d.skill_name ?? "");
                  if (skillName) pushEnhancementStarted({ skillName });
                } else if (event === "skill_enhanced") {
                  const skillName = String(d.skill_name ?? "");
                  if (skillName) pushSkillEnhanced({
                    skillName,
                    version: String(d.version ?? ""),
                    summary: String(d.summary ?? ""),
                  });
                } else if (event === "skill_enhancement_finished") {
                  const skillName = String(d.skill_name ?? "");
                  if (skillName) pushEnhancementFinished({
                    skillName,
                    updated: Boolean(d.updated),
                  });
                }
                // ready / ping / unknown events ignored
              }
```

Also update the destructure at the top of the hook from:

```ts
  const pushSkillGenerated = useEventStore((s) => s.pushSkillGenerated);
```

to include the 3 new push methods:

```ts
  const pushSkillGenerated = useEventStore((s) => s.pushSkillGenerated);
  const pushEnhancementStarted = useEventStore((s) => s.pushEnhancementStarted);
  const pushSkillEnhanced = useEventStore((s) => s.pushSkillEnhanced);
  const pushEnhancementFinished = useEventStore((s) => s.pushEnhancementFinished);
```

And update the `useEffect` deps array to include all 4:

```ts
  }, [sessionId, pushSkillGenerated, pushEnhancementStarted, pushSkillEnhanced, pushEnhancementFinished]);
```

- [ ] **Step 2: Verify build (frontend should now compile, since eventStore + types are in)**

```bash
cd "E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes/frontend"
npm run build
```

Expected: compile FAILS only on `SkillEventCard.tsx` (and possibly `ChatPanel.tsx`) referencing the old `SkillGeneratedEvent` field on the variant — fix in 5.2 next.

- [ ] **Step 3: Commit**

```bash
git add frontend/src/hooks/useEventStream.ts
git commit -m "feat(frontend): useEventStream dispatches all 4 SkillEvent variants"
```

---

### Task 5.2: SkillEventCard — multi-variant renderer

**Files:**
- Modify: `FF-OpenHermes/frontend/src/components/chat/SkillEventCard.tsx`

The card renders 3 visible variants (the `enhancement_finished` variant doesn't render — its purpose is to clear the placeholder via the store):

- `skill_generated`: copper border, ⚡ icon, "Skill Auto-Generated" label, name + description, "View →"
- `skill_enhancement_started`: copper border with subtle pulse, Loader2 icon, "Analyzing skill…" label, skill name only
- `skill_enhanced`: copper border, Sparkles icon (different from generated to distinguish), "Skill Enhanced" label, name + version + summary, "View →"

- [ ] **Step 1: Replace `SkillEventCard.tsx` content**

```tsx
"use client";
import Link from "next/link";
import { Zap, Sparkles, Loader2, ArrowRight } from "lucide-react";
import type { SkillEvent } from "@/types/api";

export default function SkillEventCard({ event }: { event: SkillEvent }) {
  if (event.type === "skill_generated") {
    return (
      <div className="rounded-xl border-l-4 border-l-accent-primary border border-border-subtle bg-bg-surface px-4 py-3 shadow-sm max-w-[80%] animate-in fade-in slide-in-from-bottom-1">
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 rounded-lg bg-accent-primary/15 text-accent-primary flex items-center justify-center flex-shrink-0">
            <Zap className="w-4 h-4" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs uppercase tracking-wide text-accent-primary font-semibold mb-0.5">
              Skill Auto-Generated
            </div>
            <div className="font-mono text-sm font-medium text-text-primary truncate">{event.name}</div>
            {event.description && (
              <div className="text-xs text-text-secondary mt-1 line-clamp-2">{event.description}</div>
            )}
          </div>
          <Link
            href="/skills"
            className="self-center text-xs text-accent-primary hover:text-accent-hover flex items-center gap-1 flex-shrink-0"
          >
            View <ArrowRight className="w-3 h-3" />
          </Link>
        </div>
      </div>
    );
  }

  if (event.type === "skill_enhancement_started") {
    return (
      <div className="rounded-xl border-l-4 border-l-accent-primary/60 border border-border-subtle bg-bg-surface px-4 py-3 shadow-sm max-w-[80%] animate-in fade-in slide-in-from-bottom-1">
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 rounded-lg bg-accent-primary/10 text-accent-primary flex items-center justify-center flex-shrink-0">
            <Loader2 className="w-4 h-4 animate-spin" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs uppercase tracking-wide text-accent-primary font-semibold mb-0.5">
              Analyzing Skill…
            </div>
            <div className="font-mono text-sm font-medium text-text-primary truncate">{event.skillName}</div>
            <div className="text-xs text-text-muted mt-1">Reflecting on this run to see if it can improve the skill.</div>
          </div>
        </div>
      </div>
    );
  }

  if (event.type === "skill_enhanced") {
    return (
      <div className="rounded-xl border-l-4 border-l-accent-primary border border-border-subtle bg-bg-surface px-4 py-3 shadow-sm max-w-[80%] animate-in fade-in slide-in-from-bottom-1">
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 rounded-lg bg-accent-primary/15 text-accent-primary flex items-center justify-center flex-shrink-0">
            <Sparkles className="w-4 h-4" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs uppercase tracking-wide text-accent-primary font-semibold mb-0.5">
              Skill Enhanced · v{event.version}
            </div>
            <div className="font-mono text-sm font-medium text-text-primary truncate">{event.skillName}</div>
            {event.summary && (
              <div className="text-xs text-text-secondary mt-1 line-clamp-2">{event.summary}</div>
            )}
          </div>
          <Link
            href="/skills"
            className="self-center text-xs text-accent-primary hover:text-accent-hover flex items-center gap-1 flex-shrink-0"
          >
            View <ArrowRight className="w-3 h-3" />
          </Link>
        </div>
      </div>
    );
  }

  // skill_enhancement_finished is handled in the store (placeholder removal); render nothing.
  return null;
}
```

- [ ] **Step 2: Verify frontend build**

```bash
cd "E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes/frontend"
npm run build
```

Expected: clean compile, all 4 routes generated.

- [ ] **Step 3: Commit**

```bash
git add frontend/src/components/chat/SkillEventCard.tsx
git commit -m "feat(frontend): SkillEventCard handles 3 visible variants (generated / analyzing / enhanced)"
```

---

### Task 5.3: EvolutionLog — versioned timeline + diff viewer

**Files:**
- Modify: `FF-OpenHermes/frontend/src/components/skills/EvolutionLog.tsx`

Currently `EvolutionLog` dumps `history` as `<pre>` text. M3 parses it into version entries (split on `## v\d+\.\d+`) and renders each as a collapsible card with the embedded `\`\`\`diff\`\`\`` block syntax-highlighted (red for `-`, green for `+`).

- [ ] **Step 1: Replace `EvolutionLog.tsx` content**

```tsx
"use client";
import { useState } from "react";
import { Activity, ChevronRight, ChevronDown } from "lucide-react";
import clsx from "clsx";
import { useSkillStore } from "@/stores/skillStore";

interface VersionEntry {
  raw: string;
  header: string;            // e.g. "v1.1 · 2026-04-29 11:45 UTC · 🤖 Auto-Enhanced · added X"
  body: string;              // markdown after the header line
  diff?: string;             // unified diff content (sans fences)
}

function parseHistory(history: string): VersionEntry[] {
  if (!history) return [];
  // Split on "\n## " but keep section header
  const sections = history.split(/\n(?=## )/g);
  const entries: VersionEntry[] = [];
  for (const sec of sections) {
    if (!sec.startsWith("## ")) continue;
    const newlineIdx = sec.indexOf("\n");
    const header = sec.slice(3, newlineIdx === -1 ? undefined : newlineIdx).trim();
    const body = newlineIdx === -1 ? "" : sec.slice(newlineIdx + 1);
    // Extract a fenced ```diff ... ``` block if present
    const diffMatch = body.match(/```diff\n([\s\S]*?)```/);
    entries.push({
      raw: sec,
      header,
      body,
      diff: diffMatch ? diffMatch[1] : undefined,
    });
  }
  return entries;
}

function DiffBlock({ diff }: { diff: string }) {
  const lines = diff.split("\n");
  return (
    <pre className="text-xs font-mono leading-snug overflow-x-auto bg-bg-elevated rounded p-2">
      {lines.map((line, i) => {
        const cls =
          line.startsWith("+") && !line.startsWith("+++") ? "text-ok" :
          line.startsWith("-") && !line.startsWith("---") ? "text-danger" :
          line.startsWith("@@") ? "text-accent-primary" :
          "text-text-muted";
        return (
          <div key={i} className={cls}>
            {line || " "}
          </div>
        );
      })}
    </pre>
  );
}

function VersionCard({ entry, defaultOpen }: { entry: VersionEntry; defaultOpen: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border border-border-subtle rounded-lg bg-bg-surface mb-2">
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center gap-2 px-3 py-2 text-left hover:bg-bg-elevated rounded-lg transition-colors"
      >
        {open ? <ChevronDown className="w-4 h-4 text-text-muted" /> : <ChevronRight className="w-4 h-4 text-text-muted" />}
        <span className="text-xs font-medium text-text-primary truncate">{entry.header}</span>
      </button>
      {open && (
        <div className="px-3 pb-3 space-y-2">
          {/* Body without diff fence (since we render the diff specially) */}
          {entry.body && (
            <div className="text-xs text-text-secondary whitespace-pre-wrap">
              {entry.body.replace(/```diff[\s\S]*?```/g, "").trim()}
            </div>
          )}
          {entry.diff && <DiffBlock diff={entry.diff} />}
        </div>
      )}
    </div>
  );
}

export default function EvolutionLog() {
  const { selected, history } = useSkillStore();
  const entries = parseHistory(history);

  return (
    <aside className="w-72 border-l border-border-subtle bg-bg-surface overflow-auto">
      <div className="p-3 border-b border-border-subtle flex items-center gap-2 text-sm font-medium">
        <Activity className="w-4 h-4 text-accent-primary" />
        Evolution Log
      </div>
      {!selected && (
        <div className="p-3 text-xs text-text-muted">Select a skill to see version history.</div>
      )}
      {selected && entries.length === 0 && (
        <div className="p-3 text-xs text-text-muted">(no history yet)</div>
      )}
      {selected && entries.length > 0 && (
        <div className={clsx("p-2")}>
          {entries.map((e, i) => (
            <VersionCard key={i} entry={e} defaultOpen={i === 0} />
          ))}
        </div>
      )}
    </aside>
  );
}
```

- [ ] **Step 2: Verify frontend build**

```bash
cd "E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes/frontend"
npm run build
```

Expected: clean compile.

- [ ] **Step 3: Commit**

```bash
git add frontend/src/components/skills/EvolutionLog.tsx
git commit -m "feat(frontend): EvolutionLog timeline with collapsible version cards + diff viewer"
```

---

## Phase 6 — Smoke + M3 Release

### Task 6.1: Final pytest gate + smoke checklist + tag

**Files:**
- Create: `FF-OpenHermes/docs/M3-smoke-checklist.md`

- [ ] **Step 1: Run full backend pytest**

```bash
cd "E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes/backend"
.venv/Scripts/pytest -v
```

Expected: **141 passed** (108 M2 + 33 new M3: 3 from cleanup + 7 schemas + 7 diff + 4 detect-extension + 9 enhancer + 3 middleware-extension). If less, recheck.

- [ ] **Step 2: Frontend build**

```bash
cd "E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes/frontend"
npm run build
```

Expected: clean compile, all 4 routes (`/`, `/_not-found`, `/memory`, `/skills`) generated.

- [ ] **Step 3: Create `docs/M3-smoke-checklist.md`**

```markdown
# M3 Smoke Checklist · Skill 自主强化

> Run after `git checkout v0.3.0-m3`. Backend on `:8003`, frontend on `:3000`.

## Pre-flight

- [ ] `cd backend && .venv/Scripts/pytest -v` → **141 passed**
- [ ] `cd frontend && npm run build` → clean compile, all routes
- [ ] Backend `.env`: `OPENROUTER_MODEL=deepseek/deepseek-chat-v3.1`, `SKILL_GEN_THRESHOLD=3`
- [ ] At least one auto-generated skill from M2 exists in some session (run M2's Scenario A first if not)

## Scenario A — Enhancement triggers when skill is loaded

1. [ ] Open browser → http://localhost:3000
2. [ ] In a session with an existing auto-generated skill, go to /skills page
3. [ ] Click the skill, then "Load (Level 1)"
4. [ ] Switch back to chat. Send a prompt that uses that skill plus 3+ other tools, e.g.:
       _"用刚加载的技能帮我处理 https://example.com，然后用 terminal 把结果保存到 result.txt"_
5. [ ] Wait for assistant turn to complete
6. [ ] **Within 1-2 seconds: an "⚡ Analyzing Skill…" placeholder card appears with a spinner + the skill name**
7. [ ] **Within 5-15 more seconds: the placeholder is replaced with "Skill Enhanced · v1.1" card showing the summary**
8. [ ] Navigate to /skills, select the enhanced skill
9. [ ] EvolutionLog (right panel) shows TWO version cards: v1.1 (top, expanded) and v1.0
10. [ ] Click v1.1 — see the summary text + the unified diff (red - lines and green + lines)

## Scenario B — NO_UPDATE branch

1. [ ] Use a skill but for a task it handles trivially (e.g. exact same workflow as the skill's documented steps)
2. [ ] Watch for "⚡ Analyzing Skill…" placeholder
3. [ ] Within 5-15s the placeholder simply disappears (no enhanced card)
4. [ ] /skills EvolutionLog shows NO new version (still at v1.0)

## Scenario C — Debounce

1. [ ] Right after a successful enhancement (Scenario A), send another similar prompt that uses the same skill
2. [ ] No new enhancement should fire (debounced for 5 minutes)
3. [ ] Check backend log: should see `skill X enhanced recently; skipping (debounce)`

## Scenario D — M2 path still works

1. [ ] Send a complex prompt that uses ≥3 tools but does NOT load any existing skill (no `read_skill` call)
2. [ ] **The original M2 SkillEventCard "Skill Auto-Generated" still appears** (M3 didn't break it)
3. [ ] /skills shows the new auto-generated skill
4. [ ] Both nav-red-dot logic and inline event cards still work

## Known limitations

- Live notifications only — refresh the page mid-enhancement and the placeholder vanishes (the persistent state is `stats.skills_enhanced` counter + the v1.1 SKILL.md on disk).
- 5-minute debounce window is hardcoded; can be tuned in `enhancer.was_enhanced_recently`.
- Curator's `new_body` is generated holistically — no fine-grained `added`/`removed` rule list (case-08 had this for visualization; we compute the diff post-hoc via `difflib`).
- Long bodies (8k+ chars) may push the second LLM call over context limits with deepseek; we cap body at 10000 chars in Pydantic schema.

## What M4 will add (cherry-pick)

- HIL PermissionModal for risky terminal commands
- Periodic memory reflection (`before_model` middleware)
- AI-powered MEMORY.md compaction
- Model switcher + token usage indicator
- HQS Session diagnostics (case-09 port)
```

- [ ] **Step 4: Commit smoke checklist**

```bash
cd "E:/work/大模型课程课件/公开课直播项目/20260429Agent Skill开发实战/FF-OpenHermes"
git add docs/M3-smoke-checklist.md docs/M3-plan.md
git commit -m "docs: M3 plan + smoke checklist"
```

- [ ] **Step 5: Tag M3 release**

```bash
git tag -a v0.3.0-m3 -m "M3: Skill auto-enhancement (Actor + Curator + diff + 3 SSE event types) + M2 cleanup"
git tag
```

Expected `git tag` output: `v0.1.0-m1`, `v0.2.0-m2`, `v0.3.0-m3`.

- [ ] **Step 6: Update PRD §10 M3 task list to checked**

Open `PRD.md`, find the `### M3 · Skill 自主强化（P1）` section, change all `- [ ]` to `- [x]`. Commit:

```bash
git add PRD.md
git commit -m "docs: mark M3 milestone complete in PRD"
```

---

## Self-Review

**Spec coverage check:**

| Spec requirement | Plan task(s) | Status |
|---|---|---|
| Trigger when read_skill was called this turn | 3.1 (used_existing_skill branch becomes dispatch) | covered |
| Actor LLM reflection | 1.1 (schema), 2.1 (impl) | covered |
| Curator LLM patch decision (UPDATE / NO_UPDATE) | 1.1 (schema), 2.1 (impl) | covered |
| Apply diff to SKILL.md | 1.2 (replace_skill_body), 2.1 (impl) | covered |
| Bump version v1.0 → v1.1 | 1.2 (bump_minor_version + replace_frontmatter_version), 2.1 (impl) | covered |
| HISTORY.md append with embedded diff | 2.1 (impl, via SkillOps.write_skill + history_line including ```diff fence``` ) | covered |
| SSE skill_enhancement_started event | 3.1 (publish before LLM calls) + 4.1 (frontend type) + 5.1 (hook dispatch) + 5.2 (card render) | covered |
| SSE skill_enhanced event | 3.1, 4.1, 5.1, 5.2 | covered |
| Async non-blocking | reuses M2's `asyncio.create_task` in middleware | covered |
| Debounce 5 minutes | 2.1 (was_enhanced_recently), 3.1 (uses it) | covered |
| Failure tolerance | 2.1 (try/except in enhancer), 3.1 (try/except in middleware) | covered |
| EvolutionLog diff viewer | 5.3 | covered |
| M2 cleanup #1 (created_at microsecond) | 0.1 | covered |
| M2 cleanup #2 (triggers json.dumps) | 0.2 | covered |
| M2 cleanup #3 (sync fallback fire-and-forget) | 0.3 | covered |
| M2 cleanup #4 (_dispatch DRY) | 0.3 | covered |
| Don't break ChatMessage / extract_turns / useSseStream | inherent — none touched in plan | covered |
| Don't break M2 skill_generated path | 3.1 explicitly preserves M2 branch | covered |

**Type / signature consistency:**
- `enhance_skill_from_turn(messages, session_dir, skill_name, llm_factory)` — same signature in 2.1 (def), 3.1 (call), tests in 2.1 + 3.1.
- `was_enhanced_recently(skill_dir, within_minutes=5)` — same signature in 2.1 (def), 3.1 (call), tests in 2.1.
- `extract_used_skill_names(messages) -> list[str]` — same in 1.3 (def), 3.1 (call), tests in 1.3.
- `unified_diff_str(old, new, label) -> str` / `bump_minor_version(current) -> str` / `replace_frontmatter_version(md, version) -> str` / `replace_skill_body(md, body) -> str` — all consistent across 1.2 (def + tests) and 2.1 (use).
- `SkillEvent` union — 4 variants in `types/api.ts` (4.1), eventStore methods in 4.1, dispatch in 5.1, render in 5.2.
- `SSE event names` — backend publishes `skill_enhancement_started` / `skill_enhanced` / `skill_enhancement_finished` / `skill_generated` (M2 unchanged); frontend dispatches all 4.
- `SessionMeta.stats.skills_enhanced` — already in M1 model; incremented via `update_stats(session_id, skills_enhanced=1)` in 3.1.

**No placeholders or "implement later" left.** All steps have complete code blocks.

---

## Execution Handoff

**Plan complete and saved to `FF-OpenHermes/docs/M3-plan.md`. Two execution options:**

1. **Subagent-Driven (recommended)** — same flow as M1 + M2: dispatch implementer per bundle (Phases 0+1, Phases 2+3, Phases 4+5, Phase 6), review between, mark task complete. Reuses our proven pattern. ~14 tasks total.

2. **Inline Execution** — walk through tasks here in session.

**Which approach?**
