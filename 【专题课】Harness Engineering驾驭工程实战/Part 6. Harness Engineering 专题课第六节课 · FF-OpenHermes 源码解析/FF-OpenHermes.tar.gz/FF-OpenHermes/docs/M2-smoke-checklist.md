# M2 Smoke Checklist · Skill 自主生成

> Run after `git checkout v0.2.0-m2`. Backend on `:8003`, frontend on `:3000`.

## Pre-flight

- [ ] `cd backend && .venv/Scripts/pytest -v` → **108 passed** (74 M1 + 34 M2)
- [ ] `cd frontend && npm run build` → clean compile, all routes
- [ ] `backend/.env` has `OPENROUTER_MODEL=deepseek/deepseek-chat-v3.1`
- [ ] `backend/.env` has `SKILL_GEN_THRESHOLD=3` (or unset; defaults to 3)
- [ ] `backend/.env` has `TAVILY_API_KEY=<your key>` (optional, for search_web tests)

## Scenario A — Auto-generation triggers

1. [ ] Open browser → http://localhost:3000
2. [ ] Create a session bound to any existing directory
3. [ ] Send a complex prompt that uses ≥ 3 tools, e.g.:
       _"用 search_web 找一下 Python 的 dataclasses 文档地址，然后 fetch_url 抓取首页内容，最后用 python_repl 提取所有以 https 开头的链接列出来"_
4. [ ] Verify: assistant streams reply with 3+ tool call cards (ThoughtChain)
5. [ ] Wait 3-15 seconds after `turn_end` (generator runs in background via `asyncio.create_task`)
6. [ ] **A SkillEventCard with copper-bordered ⚡ icon appears below the assistant reply**
7. [ ] **NavSidebar's ⚡ Skills item shows a small pulsing copper dot**
8. [ ] Click "View →" or navigate to `/skills` — the new auto-generated skill appears
9. [ ] Skill HISTORY.md (right-panel EvolutionLog) shows `v1.0 · 🤖 Auto-Generated` with reasoning
10. [ ] After visiting `/skills`, the red dot disappears (auto-mark-seen)

## Scenario B — NO_SKILL branch (low-tool turn)

1. [ ] Send a one-tool prompt: _"用 terminal 列一下当前目录的文件"_
2. [ ] After turn_end, NO SkillEventCard appears (tool count < threshold 3)

## Scenario C — Skipped because skill was already used

1. [ ] On Skills page, manually create a skill OR use one auto-generated from Scenario A
2. [ ] Click "Load (Level 1)" to load it into the active session
3. [ ] Send a prompt that uses that skill plus 3+ other tool calls
4. [ ] Verify NO new SkillEventCard appears (M2 skips when `read_skill` was called — that's M3)

## Scenario D — Side-channel reconnect

1. [ ] In a terminal: `taskkill /PID <uvicorn-pid> /F` (or close + restart Bundle 4 monitor)
2. [ ] Restart backend: `uvicorn app:app --port 8003 --reload`
3. [ ] Send a chat that triggers auto-generation
4. [ ] Frontend `useEventStream` should auto-reconnect (1s → 2s → 4s backoff) and deliver the event
5. [ ] Reconnect happens within ~3-5 seconds; SkillEventCard still arrives

## Scenario E — Multi-subscriber safety (advanced)

1. [ ] Open the same session in TWO browser tabs
2. [ ] In one tab, send a complex prompt that triggers generation
3. [ ] BOTH tabs should receive the SkillEventCard (verifies the multi-subscriber fix in `api/events.py`)

## Known limitations of M2 (NOT bugs)

- Historical SkillEventCards do NOT appear on session reload — they're live-only. The skill itself persists in `sessions/{sid}/skills/` and is visible on the Skills page.
- The `created_at` field in SKILL.md frontmatter has second-precision (not microsecond). Two skills created in the same second would have identical timestamps but different names (conflict resolver appends `-v2`/`-v3`).
- Generator failure modes (LLM exception, Pydantic validation error twice, lint error) are silent — only logged, not surfaced to the user. Check backend logs if expected skills don't materialize.
- Trigger keywords with embedded `"` quotes could break YAML frontmatter (unlikely in practice).

## What M3 will add

- Auto-enhancement: when an EXISTING skill is used (`read_skill` called), reflect on usage and patch SKILL.md to v1.1, v1.2, ...
- Side-channel will carry `skill_enhanced` events alongside `skill_generated`.
